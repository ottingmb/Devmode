# 🛡️ AML Scanner - Web3 Compliance Platform

![AML Scanner](https://img.shields.io/badge/AML-Scanner-blue?style=for-the-badge&logo=ethereum)
![React](https://img.shields.io/badge/React-18.2.0-61DAFB?style=for-the-badge&logo=react)
![Web3](https://img.shields.io/badge/Web3-4.16.0-F16822?style=for-the-badge&logo=web3.js)
![WalletConnect](https://img.shields.io/badge/WalletConnect-v2-3B99FC?style=for-the-badge&logo=walletconnect)

> **KYC/AML and Crypto Compliance — All in One Place**  
> Real-time wallet screening and risk scoring for cryptocurrency compliance.

## 🚀 Features

### 🔗 Multi-Chain Support
- **Ethereum** (Mainnet & Testnets)
- **Tron** Network
- **Polygon** (Coming Soon)
- **BSC** (Coming Soon)

### 💼 Wallet Integrations
- **WalletConnect v2** - Mobile wallet support with QR code
- **TronLink** - Browser extension integration
- **Ledger** - Hardware wallet support
- **MetaMask** - Browser extension compatibility

### 🔍 AML Features
- Real-time wallet risk assessment
- Comprehensive compliance scoring
- Transaction history analysis
- Sanctions list screening
- Regulatory compliance reporting

### 🎨 Modern UI/UX
- Responsive design with Tailwind CSS
- Smooth animations with Framer Motion
- Professional compliance interface
- Mobile-first approach
- Dark/Light mode support

## 🛠️ Technology Stack

### Frontend
- **React 18** - Modern React with hooks
- **Tailwind CSS** - Utility-first CSS framework
- **Framer Motion** - Animation library
- **Lucide React** - Beautiful icons

### Blockchain
- **Web3.js** - Ethereum interaction
- **TronWeb** - Tron blockchain support
- **WalletConnect v2** - Cross-platform wallet connections

### Backend
- **Node.js** - Server runtime
- **Express** - Web framework
- **Socket.io** - Real-time communication
- **CORS** - Cross-origin resource sharing

## 🚀 Quick Start

### Prerequisites
- Node.js (v16 or higher)
- npm or yarn
- Git

### Installation

1. **Clone the repository**
   ```bash
   git clone https://github.com/ottingmb/w.git
   cd w
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Start development server**
   ```bash
   npm start
   ```

4. **Build for production**
   ```bash
   npm run build
   ```

## 📱 Usage

### 1. Network Selection
Choose your preferred blockchain network:
- Ethereum Mainnet
- Ethereum Testnet (Goerli, Sepolia)
- Tron Mainnet
- Tron Testnet (Shasta)

### 2. Wallet Connection
Connect your wallet using:
- **Mobile**: Scan QR code with WalletConnect
- **Browser**: Use TronLink or MetaMask extension
- **Hardware**: Connect Ledger device

### 3. AML Scanning
- Enter wallet address or use connected wallet
- Initiate compliance scan
- Review detailed risk assessment
- Export compliance reports

## 🔧 Configuration

### WalletConnect Setup
```javascript
// src/config/walletconnect-config.js
export const WALLETCONNECT_PROJECT_ID = 'your-project-id';
export const WALLETCONNECT_METADATA = {
  name: 'AML Scanner',
  description: 'Web3 AML Compliance Platform',
  url: 'https://amlscanner.org',
  icons: ['https://amlscanner.org/icon.png']
};
```

### AML API Configuration
```javascript
// src/config/amlscanner-config.js
export const AML_CONFIG = {
  api: {
    baseUrl: 'https://api.amlscanner.org',
    key: 'your-api-key'
  },
  endpoints: {
    scan: '/api/aml/scan',
    report: '/api/aml/report'
  }
};
```

## 📊 API Endpoints

### Wallet Scanning
```http
POST /api/aml/scan
Content-Type: application/json

{
  "address": "0x742d35Cc6634C0532925a3b8D098d54b5F6482D",
  "network": "ethereum",
  "includeTransactions": true
}
```

### Risk Assessment
```http
GET /api/aml/risk/{address}
X-API-Key: your-api-key
```

## 🔒 Security Features

- **Secure Wallet Connections** - No private key exposure
- **API Key Management** - Secure credential handling
- **Rate Limiting** - API abuse prevention
- **Input Validation** - Address format verification
- **HTTPS Only** - Encrypted communication

## 📈 Compliance Standards

- **FATF Guidelines** - Financial Action Task Force
- **AML/KYC Regulation** - Anti-Money Laundering
- **OFAC Sanctions** - Office of Foreign Assets Control
- **EU 5AMLD** - 5th Anti-Money Laundering Directive
- **BSA Requirements** - Bank Secrecy Act

## 🤝 Contributing

1. Fork the repository
2. Create feature branch (`git checkout -b feature/amazing-feature`)
3. Commit changes (`git commit -m 'Add amazing feature'`)
4. Push to branch (`git push origin feature/amazing-feature`)
5. Open Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🆘 Support

- **Documentation**: [Wiki](https://github.com/ottingmb/w/wiki)
- **Issues**: [GitHub Issues](https://github.com/ottingmb/w/issues)
- **Email**: support@amlscanner.org

## 🏆 Acknowledgments

- [WalletConnect](https://walletconnect.com/) - Cross-platform wallet connections
- [TronLink](https://www.tronlink.org/) - Tron wallet integration
- [React](https://reactjs.org/) - UI framework
- [Tailwind CSS](https://tailwindcss.com/) - Styling framework
- [Framer Motion](https://www.framer.com/motion/) - Animation library

---

<p align="center">
  <strong>🛡️ Built for Web3 Compliance & Security</strong>
</p>

<p align="center">
  Made with ❤️ for the blockchain community
</p>