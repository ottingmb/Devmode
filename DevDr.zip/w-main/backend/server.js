// Minimal Express + Socket.IO backend for AML Scanner
const express = require('express');
const http = require('http');
const cors = require('cors');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: [
      'https://aml.ott-investments.com',
      'http://localhost:3000',
      'http://localhost:8080',
      'http://127.0.0.1:3000',
      'http://127.0.0.1:8080'
    ],
    methods: ['GET', 'POST'],
    credentials: true
  },
  // Add settings for better connection reliability
  pingTimeout: 60000,
  pingInterval: 25000,
  connectTimeout: 10000,
  maxHttpBufferSize: 1e8
});

app.use(cors({
  origin: [
    'https://aml.ott-investments.com',
    'http://localhost:3000',
    'http://localhost:8080',
    'http://127.0.0.1:3000',
    'http://127.0.0.1:8080'
  ],
  credentials: true
}));
app.use(express.json());

// Add request logging middleware
app.use((req, res, next) => {
  const start = Date.now();
  res.on('finish', () => {
    const duration = Date.now() - start;
    console.log(`${req.method} ${req.originalUrl} - ${res.statusCode} - ${duration}ms`);
  });
  next();
});

// Log all origins to help debug CORS issues
app.use((req, res, next) => {
  const origin = req.headers.origin || req.headers.referer || 'Unknown';
  console.log(`Request from origin: ${origin}`);
  next();
});

// POST /addresses/check endpoint for AML verification
app.post('/addresses/check', (req, res) => {
  const { address, chain, token } = req.body;
  
  if (!address || !chain || !token) {
    return res.status(400).json({ 
      error: 'Missing required fields',
      required: ['address', 'chain', 'token']
    });
  }

  // Basic address format validation
  let isValidAddress = false;
  if (chain === 'ethereum' && address.match(/^0x[a-fA-F0-9]{40}$/)) {
    isValidAddress = true;
  } else if (chain === 'tron' && address.match(/^T[A-Za-z1-9]{33}$/)) {
    isValidAddress = true;
  }

  if (!isValidAddress) {
    return res.status(400).json({
      error: 'Invalid address format for the specified chain',
      address,
      chain
    });
  }

  // For now, return a simple risk assessment
  // In a real implementation, this would query actual AML databases
  const riskScore = Math.random() * 100;
  let risk = 'low';
  if (riskScore > 70) risk = 'high';
  else if (riskScore > 40) risk = 'medium';

  res.json({
    address,
    chain,
    token,
    risk,
    riskScore: Math.round(riskScore),
    message: `Address ${address} on ${chain} network has ${risk} risk profile`,
    timestamp: new Date().toISOString(),
    checks: {
      formatValid: true,
      blacklisted: riskScore > 90,
      sanctioned: riskScore > 95,
      mixerRelated: riskScore > 80
    }
  });
});

// /session WebSocket endpoint for real WalletConnect session management
io.of('/session').on('connection', (socket) => {
  console.log('Client connected to session socket:', socket.id);
  
  // Send immediate welcome message
  socket.emit('welcome', { message: 'Connected to API server', socketId: socket.id, timestamp: new Date().toISOString() });

  // Handle WalletConnect URI sharing
  socket.on('walletconnect-uri', (uri) => {
    console.log('Received WalletConnect URI:', uri);
    // Broadcast URI to other clients if needed
    socket.broadcast.emit('uri', uri);
  });

  // Handle wallet connection events
  socket.on('wallet-connected', (data) => {
    console.log('Wallet connected:', data);
    socket.emit('connection-success', data);
  });

  // Handle wallet disconnection
  socket.on('wallet-disconnected', () => {
    console.log('Wallet disconnected');
    socket.emit('disconnection-success');
  });

  // Handle transaction events
  socket.on('transaction-initiated', (data) => {
    console.log('Transaction initiated:', data);
    socket.broadcast.emit('transaction-status', { status: 'initiated', data });
  });

  socket.on('transaction-confirmed', (data) => {
    console.log('Transaction confirmed:', data);
    socket.broadcast.emit('transaction-status', { status: 'confirmed', data });
  });

  socket.on('transaction-failed', (error) => {
    console.log('Transaction failed:', error);
    socket.broadcast.emit('transaction-status', { status: 'failed', error });
  });

  // Handle AML scan results
  socket.on('aml-scan-complete', (results) => {
    console.log('AML scan complete:', results);
    socket.broadcast.emit('scan-results', results);
  });

  socket.on('disconnect', () => {
    console.log('Client disconnected from session socket');
  });
});

// Add additional error handling for Socket.IO
io.engine.on("connection_error", (err) => {
  console.log(`Connection error: ${err.code}, message: ${err.message}`);
});

const PORT = process.env.PORT || 8080;
const HOST = process.env.HOST || '0.0.0.0'; // Listen on all network interfaces

server.listen(PORT, HOST, () => {
  console.log(`Backend server listening on ${HOST}:${PORT}`);
  console.log(`Access from production: https://api.ott-investments.com`);
  console.log(`Access from development: http://localhost:${PORT}`);
});
