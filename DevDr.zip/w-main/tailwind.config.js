/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          50: '#eff6ff',
          100: '#dbeafe',
          500: '#3b82f6',
          600: '#2563eb',
          700: '#1d4ed8',
          900: '#1e3a8a',
        },
        aml: {
          blue: '#3375BB',
          lightBlue: '#dbeafe',
          dark: '#1e3a8a',
          gray: '#f5f5f5',
          text: '#333333',
        }
      },
      fontFamily: {
        'inter': ['Inter', 'sans-serif'],
      },
      fontSize: {
        '22': '1.375rem',
        '16': '1rem',
      },
      fontWeight: {
        '700': '700',
        '600': '600',
        '400': '400',
      }
    },
  },
  plugins: [],
}