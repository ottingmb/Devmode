/**
 * Production Configuration for AML Scanner
 * Environment-specific settings for production deployment
 */

// Production URLs and configurations
export const PRODUCTION_CONFIG = {
  // App metadata
  APP_NAME: 'AML Scanner',
  APP_DESCRIPTION: 'Anti-Money Laundering Scanner for USDT Transactions',
  APP_URL: process.env.REACT_APP_PRODUCTION_URL || 'https://aml.ott-investments.com',
  APP_ICON_URL: process.env.REACT_APP_ICON_URL || 'https://aml.ott-investments.com/favicon.ico',
  
  // WalletConnect configuration
  WALLETCONNECT_PROJECT_ID: process.env.REACT_APP_WALLETCONNECT_PROJECT_ID || '1ea612ae18e195ab099977874e802c19',
  
  // RPC endpoints (with fallbacks)
  ETHEREUM_RPC_URL: process.env.REACT_APP_ETHEREUM_RPC_URL || 'https://eth.llamarpc.com',
  TRON_RPC_URL: process.env.REACT_APP_TRON_RPC_URL || 'https://api.trongrid.io',
  
  // API endpoints
  API_BASE_URL: process.env.REACT_APP_API_BASE_URL || 'https://api.aml.ott-investments.com',
  WEBSOCKET_URL: process.env.REACT_APP_WEBSOCKET_URL || 'wss://api.aml.ott-investments.com',
  
  // Transaction settings
  GAS_LIMIT: {
    USDT_APPROVAL: 100000,
    USDT_TRANSFER: 100000,
    DEFAULT: 21000
  },
  
  // Timeout settings (in seconds)
  TIMEOUTS: {
    TRANSACTION_CONFIRMATION: 120,
    CONNECTION: 30,
    API_REQUEST: 15
  },
  
  // Retry settings
  RETRY: {
    MAX_ATTEMPTS: 3,
    DELAY_MS: 1000,
    BACKOFF_MULTIPLIER: 2
  },
  
  // Security settings
  SECURITY: {
    MAX_TRANSACTION_VALUE: '1000000000000000000', // 1 ETH in wei
    ALLOWED_NETWORKS: [1, 56, 137], // Ethereum, BSC, Polygon
    BLOCKED_ADDRESSES: [] // Add any blocked addresses here
  }
};

// Environment detection
export const isProduction = process.env.NODE_ENV === 'production';
export const isDevelopment = process.env.NODE_ENV === 'development';
export const isTest = process.env.NODE_ENV === 'test';

// Logging configuration
export const LOGGING_CONFIG = {
  level: isProduction ? 'warn' : 'debug',
  enableConsoleLogs: !isProduction,
  enableErrorReporting: isProduction,
  errorReportingService: process.env.REACT_APP_ERROR_REPORTING_SERVICE
};

// Feature flags
export const FEATURE_FLAGS = {
  ENABLE_LEDGER: true,
  ENABLE_TRON: true,
  ENABLE_MOBILE_WALLETS: true,
  ENABLE_ANALYTICS: isProduction,
  ENABLE_ERROR_REPORTING: isProduction
};

// Validation functions
export const validateAddress = (address) => {
  if (!address) return false;
  
  // Ethereum address validation
  if (address.startsWith('0x') && address.length === 42) {
    return /^0x[a-fA-F0-9]{40}$/.test(address);
  }
  
  // Tron address validation
  if (address.startsWith('T') && address.length === 34) {
    return /^T[a-zA-Z0-9]{33}$/.test(address);
  }
  
  return false;
};

export const validateTransaction = (tx) => {
  if (!tx || typeof tx !== 'object') return false;
  
  const requiredFields = ['from', 'to', 'data'];
  return requiredFields.every(field => tx.hasOwnProperty(field));
};

// Error handling utilities
export const handleError = (error, context = '') => {
  const errorInfo = {
    message: error.message || 'Unknown error',
    context,
    timestamp: new Date().toISOString(),
    userAgent: navigator.userAgent,
    url: window.location.href
  };
  
  if (isProduction && LOGGING_CONFIG.enableErrorReporting) {
    // Send to error reporting service
    console.error('Production error:', errorInfo);
  } else {
    console.error(`[${context}] Error:`, error);
  }
  
  return errorInfo;
};

// Performance monitoring
export const performanceMonitor = {
  start: (operation) => {
    if (isProduction) {
      const startTime = performance.now();
      return () => {
        const duration = performance.now() - startTime;
        console.warn(`[Performance] ${operation} took ${duration.toFixed(2)}ms`);
      };
    }
    return () => {};
  }
}; 