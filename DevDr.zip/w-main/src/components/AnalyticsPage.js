import React from 'react';
import { motion } from 'framer-motion';

const AnalyticsPage = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-100">
      <div className="max-w-6xl mx-auto px-6 py-20">
        {/* Header Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center justify-center w-16 h-16 bg-gray-100 rounded-2xl mb-8 shadow-sm">
            <svg className="w-10 h-10 text-gray-600" fill="none" stroke="currentColor" strokeWidth="2.2" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" d="M13 3L4 14h7l-1 7 9-11h-7l1-7z" />
            </svg>
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6 tracking-tight">
            What Do We Analyze?
          </h1>
          <p className="text-xl text-gray-600 leading-relaxed max-w-3xl mx-auto">
            We analyze addresses for connections to over 20 risk sources to identify suspicious transactions and assess risk factors. These sources are categorized into three groups:
          </p>
        </motion.div>



        {/* Security & Trust Overview */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="bg-gradient-to-br from-green-50 via-white to-emerald-50 rounded-3xl shadow-lg border border-green-100 p-8 mb-16"
        >
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-3">Comprehensive Security Analysis</h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Cutting-edge blockchain intelligence with instant threat detection and comprehensive risk profiling
            </p>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Secure Transactions */}
            <div className="text-center">
              <div className="relative w-32 h-32 mx-auto mb-6">
                <svg className="w-32 h-32 transform -rotate-90" viewBox="0 0 36 36">
                  <path
                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                    fill="none"
                    stroke="#f3f4f6"
                    strokeWidth="3"
                  />
                  <path
                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                    fill="none"
                    stroke="#10b981"
                    strokeWidth="3"
                    strokeDasharray="85, 100"
                    strokeLinecap="round"
                  />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-3xl font-bold text-gray-900">85%</span>
                </div>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Secure Transactions</h3>
              <p className="text-gray-600 leading-relaxed">Clean transactions with full regulatory compliance and transparent verification protocols</p>
            </div>

            {/* Monitored Activity */}
            <div className="text-center">
              <div className="relative w-32 h-32 mx-auto mb-6">
                <svg className="w-32 h-32 transform -rotate-90" viewBox="0 0 36 36">
                  <path
                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                    fill="none"
                    stroke="#f3f4f6"
                    strokeWidth="3"
                  />
                  <path
                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                    fill="none"
                    stroke="#f59e0b"
                    strokeWidth="3"
                    strokeDasharray="57, 100"
                    strokeLinecap="round"
                  />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-3xl font-bold text-gray-900">57%</span>
                </div>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Enhanced Monitoring</h3>
              <p className="text-gray-600 leading-relaxed">Transactions requiring additional verification and enhanced due diligence procedures</p>
            </div>

            {/* Risk Detection */}
            <div className="text-center">
              <div className="relative w-32 h-32 mx-auto mb-6">
                <svg className="w-32 h-32 transform -rotate-90" viewBox="0 0 36 36">
                  <path
                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                    fill="none"
                    stroke="#f3f4f6"
                    strokeWidth="3"
                  />
                  <path
                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                    fill="none"
                    stroke="#ef4444"
                    strokeWidth="3"
                    strokeDasharray="36, 100"
                    strokeLinecap="round"
                  />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-3xl font-bold text-gray-900">36%</span>
                </div>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Risk Detection</h3>
              <p className="text-gray-600 leading-relaxed">Proactive identification of potential threats with immediate alert systems</p>
            </div>
          </div>
        </motion.div>

        {/* Categories Section */}
        <div className="space-y-16">
          {/* High-Risk Categories */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden"
          >
            <div className="bg-gradient-to-r from-red-50 to-red-100 px-8 py-6 border-b border-red-200">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-red-500 rounded-xl flex items-center justify-center">
                  <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z" />
                  </svg>
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-gray-900">High-Risk Categories</h2>
                  <p className="text-gray-600 mt-1">Critical risk sources requiring immediate attention</p>
                </div>
              </div>
            </div>
            <div className="p-8">
              <div className="grid gap-6">
                {[
                  { name: 'Child Exploitation', desc: 'Addresses associated with activities involving child exploitation' },
                  { name: 'Dark Market', desc: 'Coins linked to illegal marketplaces or activities' },
                  { name: 'Dark Service', desc: 'Coins tied to activities such as terrorism financing, drug trafficking, or child abuse' },
                  { name: 'Enforcement Action', desc: 'Entities under legal investigation or involved in judicial proceedings' },
                  { name: 'Fraudulent Exchange', desc: 'Exchanges involved in scams, illegal practices, or whose funds have been seized by authorities' },
                  { name: 'Gambling', desc: 'Coins linked to unlicensed online gambling platforms' },
                  { name: 'Illegal Service', desc: 'Addresses associated with other illegal activities' },
                  { name: 'Mixer', desc: 'Coins passed through mixers to obfuscate transaction trails, often used for money laundering' },
                  { name: 'Ransom', desc: 'Funds obtained through extortion or blackmail' },
                  { name: 'Sanctions', desc: 'Entities under international sanctions' },
                  { name: 'Scam', desc: 'Coins acquired through deceptive activities' },
                  { name: 'Stolen Coins', desc: 'Cryptocurrencies stolen from their rightful owners' },
                  { name: 'Terrorism Financing', desc: 'Entities associated with the funding of terrorism' }
                ].map((item, index) => (
                  <motion.div
                    key={item.name}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.5, delay: 0.5 + index * 0.05 }}
                    className="flex items-start space-x-4 p-4 rounded-xl hover:bg-gray-50 transition-colors duration-200"
                  >
                    <div className="w-2 h-2 bg-red-500 rounded-full mt-3 flex-shrink-0"></div>
                    <div>
                      <h3 className="font-semibold text-gray-900 mb-1">{item.name}</h3>
                      <p className="text-gray-600 text-sm leading-relaxed">{item.desc}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.div>

          {/* Suspicious Sources */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden"
          >
            <div className="bg-gradient-to-r from-yellow-50 to-yellow-100 px-8 py-6 border-b border-yellow-200">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-yellow-500 rounded-xl flex items-center justify-center">
                  <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z" />
                  </svg>
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-gray-900">Suspicious Sources</h2>
                  <p className="text-gray-600 mt-1">Sources requiring enhanced due diligence</p>
                </div>
              </div>
            </div>
            <div className="p-8">
              <div className="grid gap-6">
                {[
                  { name: 'ATM', desc: 'Coins obtained via cryptocurrency ATMs' },
                  { name: 'High-Risk Exchange', desc: 'Exchanges flagged for lack of KYC requirements, criminal charges, high exposure to darknet markets, operating in weak AML jurisdictions, or lack of appropriate licensing' },
                  { name: 'Liquidity Pools', desc: 'Smart contracts where tokens are locked to provide liquidity for trading' },
                  { name: 'High-Risk P2P Exchange', desc: 'Peer-to-peer platforms without appropriate licenses or KYC processes, making them attractive for money laundering' },
                  { name: 'Unnamed Service', desc: 'Clusters of unidentified addresses behaving like services with a significant number of transactions' }
                ].map((item, index) => (
                  <motion.div
                    key={item.name}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.5, delay: 0.7 + index * 0.05 }}
                    className="flex items-start space-x-4 p-4 rounded-xl hover:bg-gray-50 transition-colors duration-200"
                  >
                    <div className="w-2 h-2 bg-yellow-500 rounded-full mt-3 flex-shrink-0"></div>
                    <div>
                      <h3 className="font-semibold text-gray-900 mb-1">{item.name}</h3>
                      <p className="text-gray-600 text-sm leading-relaxed">{item.desc}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.div>

          {/* Trusted Sources */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.8 }}
            className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden"
          >
            <div className="bg-gradient-to-r from-green-50 to-green-100 px-8 py-6 border-b border-green-200">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-green-500 rounded-xl flex items-center justify-center">
                  <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-gray-900">Trusted Sources</h2>
                  <p className="text-gray-600 mt-1">Legitimate sources with proper compliance measures</p>
                </div>
              </div>
            </div>
            <div className="p-8">
              <div className="grid gap-6">
                {[
                  { name: 'Exchange', desc: 'Licensed cryptocurrency exchanges that comply with AML/CFT regulations, offering depository, brokerage, or trading services. Does not include exchanges operating in FATF non-cooperative jurisdictions. Trusted exchanges handle 90% of all cryptocurrency transactions' },
                  { name: 'ICO', desc: 'Legitimate projects crowdfunding by selling tokens in exchange for cryptocurrencies like Bitcoin or Ether. However, some ICOs may involve fraudulent activities' },
                  { name: 'Marketplace', desc: 'Coins used for legal transactions in online marketplaces' },
                  { name: 'Merchant Services', desc: 'Payment gateways that enable businesses to accept cryptocurrency payments, often converting them to local fiat currency' },
                  { name: 'Miner', desc: 'Coins generated through mining but not yet forwarded to other addresses' },
                  { name: 'Other', desc: 'Coins obtained through airdrops, token sales, or similar means' },
                  { name: 'P2P Exchange', desc: 'Licensed peer-to-peer exchanges that allow participants to trade cryptocurrencies directly with each other' }
                ].map((item, index) => (
                  <motion.div
                    key={item.name}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.5, delay: 0.9 + index * 0.05 }}
                    className="flex items-start space-x-4 p-4 rounded-xl hover:bg-gray-50 transition-colors duration-200"
                  >
                    <div className="w-2 h-2 bg-green-500 rounded-full mt-3 flex-shrink-0"></div>
                    <div>
                      <h3 className="font-semibold text-gray-900 mb-1">{item.name}</h3>
                      <p className="text-gray-600 text-sm leading-relaxed">{item.desc}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.div>
        </div>

        {/* CTA Section */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 1.0 }}
          className="text-center mt-20"
        >
          <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-2xl p-12 border border-blue-100">
            <h3 className="text-3xl font-bold text-gray-900 mb-6">Ready to Analyze Your Wallet?</h3>
            <p className="text-gray-600 mb-8 text-lg leading-relaxed max-w-2xl mx-auto">
              Get comprehensive insights into your cryptocurrency transactions and identify potential risks with our advanced AML scanning technology.
            </p>
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="button text-lg px-8 py-4 inline-block"
              onClick={() => window.location.href = '/connect'}
            >
              Check Your Wallet Now
            </motion.button>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default AnalyticsPage;
