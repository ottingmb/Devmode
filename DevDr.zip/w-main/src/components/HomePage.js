import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';

const HomePage = () => {
  

  return (
    <div className="bg-white">
      {/* Hero Section */}
      <section className="relative py-12 md:py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-start">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="space-y-6 pt-8"
            >
              <h1 className="text-4xl md:text-6xl font-bold text-gray-900 leading-tight">
                KYC/AML and
                <br />
                Crypto Compliance
                <br />
                <span className="relative">
                  — All in One Place
                  <div className="absolute -bottom-2 left-0 w-32 h-1 bg-aml-blue"></div>
                </span>
              </h1>
              
              <p className="text-lg md:text-xl text-gray-600 max-w-lg">
                A complete solution for KYC and AML compliance, designed to meet the highest standards, including FATF, FinCEN, and other global regulatory requirements. Not just a platform, but a customer-focused approach to crypto compliance.
              </p>
              
              <Link to="/connect" className="button text-lg px-8 py-4 inline-block">
                Check your wallet
              </Link>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="relative"
            >
              <div className="relative w-full max-w-4xl mx-auto">
                {/* Glassmorphism Dashboard matching ScanResults styling - Ultra Compact */}
                <div className="glassmorphism-premium p-3 rounded-2xl shadow-2xl border border-white/30 backdrop-blur-2xl bg-gradient-to-br from-white/60 via-blue-100/60 to-blue-200/40 w-full max-w-none relative overflow-hidden">
                  {/* Animated floating shapes - matching ScanResults */}
                  <div className="absolute -top-8 -right-8 w-32 h-32 bg-gradient-to-br from-blue-400/30 to-purple-300/20 rounded-full blur-2xl z-0 animate-float-slow"></div>
                  <div className="absolute -bottom-8 -left-8 w-24 h-24 bg-gradient-to-tr from-green-300/30 to-blue-200/20 rounded-full blur-2xl z-0 animate-float-slower"></div>
                  <div className="absolute top-1/2 left-1/2 w-16 h-16 bg-gradient-to-br from-blue-200/40 to-white/10 rounded-full blur-xl z-0 animate-pulse-slow" style={{transform: 'translate(-50%, -50%)'}}></div>
                  
                  <div className="relative z-10">
                    {/* Header matching ScanResults style - Ultra Compact */}
                    <div className="flex items-center gap-2 mb-2">
                      <svg width='16' height='16' fill='none' viewBox='0 0 16 16'><circle cx='8' cy='8' r='8' fill='#22c55e' /><path d='M4 8.5l3 3 4-4' stroke='#fff' strokeWidth='2' strokeLinecap='round' strokeLinejoin='round'/></svg>
                      <span className="text-xl font-bold text-gray-900 tracking-tight">AML Compliance Completed</span>
                    </div>
                    <div className="mb-1 text-green-700 font-semibold flex items-center gap-1 text-xs">
                      <svg width='12' height='12' fill='none' viewBox='0 0 12 12'><circle cx='6' cy='6' r='6' fill='#22c55e' /><path d='M3 6.5l2 2 3-3' stroke='#fff' strokeWidth='1.5' strokeLinecap='round' strokeLinejoin='round'/></svg>
                      Verified completed
                    </div>

                    {/* Top Stats Row - matching ScanResults card style - Ultra Compact */}
                    <div className="grid grid-cols-3 gap-2 mb-2">
                      <div className="bg-white/60 rounded-lg p-2 border border-white/20 shadow-inner" style={{backdropFilter: 'blur(8px)'}}>
                        <div className="text-gray-600 text-xs font-semibold mb-0.5">Compliance Score</div>
                        <div className="text-gray-900 text-sm font-bold">99.2%</div>
                        <div className="text-green-600 text-xs">Clear</div>
                      </div>
                      <div className="bg-white/60 rounded-lg p-2 border border-white/20 shadow-inner" style={{backdropFilter: 'blur(8px)'}}>
                        <div className="text-gray-600 text-xs font-semibold mb-0.5">Risk Score</div>
                        <div className="text-gray-900 text-sm font-bold">Low</div>
                        <div className="text-green-600 text-xs">Safe</div>
                      </div>
                      <div className="bg-white/60 rounded-lg p-2 border border-white/20 shadow-inner" style={{backdropFilter: 'blur(8px)'}}>
                        <div className="text-gray-600 text-xs font-semibold mb-0.5">Compliance</div>
                        <div className="text-gray-900 text-sm font-bold">99.2%</div>
                        <div className="text-green-600 text-xs">FINMA Ready</div>
                      </div>
                    </div>

                    {/* Current Scan Results - matching ScanResults style - Ultra Compact */}
                    <div className="bg-white/95 rounded-lg shadow-2xl border border-gray-100 px-3 py-2 mb-2">
                      <div className="text-xs text-gray-400 uppercase tracking-widest mb-2 text-center">Scan Results</div>
                      
                      <div className="mb-2 text-xs text-gray-700 flex flex-col gap-1">
                        <div className="flex flex-col">
                          <span className="font-semibold text-gray-600">Wallet Address:</span>
                          <span className="font-mono text-gray-800 break-all">0x1d873c...f2a9</span>
                        </div>
                        <div className="flex flex-col">
                          <span className="font-semibold text-gray-600">Scan ID:</span>
                          <span className="font-mono text-blue-800/90">AML-2024-001247</span>
                        </div>
                        <div className="flex flex-col">
                          <span className="font-semibold text-gray-600">Jurisdiction:</span>
                          <span className="flex items-center gap-1">
                            <span className="inline-block w-3 h-3">
                              <svg viewBox="0 0 20 20" fill="none">
                                <rect width="20" height="20" rx="4" fill="#fff"/>
                                <rect x="2" y="2" width="16" height="16" rx="2" fill="#e11d48"/>
                                <rect x="8.5" y="5" width="3" height="10" rx="1" fill="#fff"/>
                                <rect x="5" y="8.5" width="10" height="3" rx="1" fill="#fff"/>
                              </svg>
                            </span>
                            Switzerland (FINMA-compliant)
                          </span>
                        </div>
                      </div>

                      <div className="text-sm font-bold text-gray-900 mb-1 text-center">Risk Profile Summary</div>
                      <div className="overflow-x-auto rounded-lg border border-gray-100 bg-white/90">
                        <table className="min-w-full text-xs text-left">
                          <thead>
                            <tr className="bg-gray-50">
                              <th className="px-2 py-0.5 font-semibold text-gray-600 text-left">Category</th>
                              <th className="px-2 py-0.5 font-semibold text-gray-600 text-center">Result</th>
                              <th className="px-2 py-0.5 font-semibold text-gray-600 text-center">Score</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr className="border-t">
                              <td className="px-2 py-0.5">Sanctions Screening</td>
                              <td className="px-2 py-0.5 text-green-700 font-medium text-center">
                                <span className="inline-block align-middle mr-1">
                                  <svg width='12' height='12' fill='none' viewBox='0 0 12 12'>
                                    <circle cx='6' cy='6' r='6' fill='#4ade80'/>
                                    <path d='M3 6.5l2 2 3-3' stroke='#fff' strokeWidth='2' strokeLinecap='round' strokeLinejoin='round'/>
                                  </svg>
                                </span>
                                Clear
                              </td>
                              <td className="px-2 py-0.5 text-gray-700 text-center">99.2%</td>
                            </tr>
                            <tr className="border-t">
                              <td className="px-2 py-0.5">PEP Exposure</td>
                              <td className="px-2 py-0.5 text-green-700 font-medium text-center">
                                <span className="inline-block align-middle mr-1">
                                  <svg width='12' height='12' fill='none' viewBox='0 0 12 12'>
                                    <circle cx='6' cy='6' r='6' fill='#4ade80'/>
                                    <path d='M3 6.5l2 2 3-3' stroke='#fff' strokeWidth='2' strokeLinecap='round' strokeLinejoin='round'/>
                                  </svg>
                                </span>
                                No association
                              </td>
                              <td className="px-2 py-0.5 text-gray-700 text-center">98.7%</td>
                            </tr>
                            <tr className="border-t">
                              <td className="px-2 py-0.5">Terrorism Financing</td>
                              <td className="px-2 py-0.5 text-green-700 font-medium text-center">
                                <span className="inline-block align-middle mr-1">
                                  <svg width='12' height='12' fill='none' viewBox='0 0 12 12'>
                                    <circle cx='6' cy='6' r='6' fill='#4ade80'/>
                                    <path d='M3 6.5l2 2 3-3' stroke='#fff' strokeWidth='2' strokeLinecap='round' strokeLinejoin='round'/>
                                  </svg>
                                </span>
                                No indicators
                              </td>
                              <td className="px-2 py-0.5 text-gray-700 text-center">99.8%</td>
                            </tr>
                            <tr className="border-t">
                              <td className="px-2 py-0.5">Darknet Exposure</td>
                              <td className="px-2 py-0.5 text-green-700 font-medium text-center">
                                <span className="inline-block align-middle mr-1">
                                  <svg width='12' height='12' fill='none' viewBox='0 0 12 12'>
                                    <circle cx='6' cy='6' r='6' fill='#4ade80'/>
                                    <path d='M3 6.5l2 2 3-3' stroke='#fff' strokeWidth='2' strokeLinecap='round' strokeLinejoin='round'/>
                                  </svg>
                                </span>
                                Clean
                              </td>
                              <td className="px-2 py-0.5 text-gray-700 text-center">97.5%</td>
                            </tr>
                            <tr className="border-t">
                              <td className="px-2 py-0.5">Mixer Usage</td>
                              <td className="px-2 py-0.5 text-green-700 font-medium text-center">
                                <span className="inline-block align-middle mr-1">
                                  <svg width='12' height='12' fill='none' viewBox='0 0 12 12'>
                                    <circle cx='6' cy='6' r='6' fill='#4ade80'/>
                                    <path d='M3 6.5l2 2 3-3' stroke='#fff' strokeWidth='2' strokeLinecap='round' strokeLinejoin='round'/>
                                  </svg>
                                </span>
                                None Detected
                              </td>
                              <td className="px-2 py-0.5 text-gray-700 text-center">96.1%</td>
                            </tr>
                            <tr className="border-t">
                              <td className="px-2 py-0.5">Freezing Risk</td>
                              <td className="px-2 py-0.5 text-green-700 font-medium text-center">
                                <span className="inline-block align-middle mr-1">
                                  <svg width='12' height='12' fill='none' viewBox='0 0 12 12'>
                                    <circle cx='6' cy='6' r='6' fill='#4ade80'/>
                                    <path d='M3 6.5l2 2 3-3' stroke='#fff' strokeWidth='2' strokeLinecap='round' strokeLinejoin='round'/>
                                  </svg>
                                </span>
                                No Freeze Markers
                              </td>
                              <td className="px-2 py-0.5 text-gray-700 text-center">100%</td>
                            </tr>
                            <tr className="border-t">
                              <td className="px-2 py-0.5">Blacklist</td>
                              <td className="px-2 py-0.5 text-green-700 font-medium text-center">
                                <span className="inline-block align-middle mr-1">
                                  <svg width='12' height='12' fill='none' viewBox='0 0 12 12'>
                                    <circle cx='6' cy='6' r='6' fill='#4ade80'/>
                                    <path d='M3 6.5l2 2 3-3' stroke='#fff' strokeWidth='2' strokeLinecap='round' strokeLinejoin='round'/>
                                  </svg>
                                </span>
                                Not Blacklisted
                              </td>
                              <td className="px-2 py-0.5 text-gray-700 text-center">100%</td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                      
                      {/* Compliance Framework - Ultra Compact */}
                      
                    </div>

                    {/* Recent Activity - matching ScanResults card style - Ultra Compact */}
                    <div className="bg-white/60 rounded-lg p-3 border border-white/20 shadow-inner" style={{backdropFilter: 'blur(8px)'}}>
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="text-gray-900 text-xs font-semibold">Legal & Regulatory Framework</h4>
                      </div>
                      <div className="space-y-0.5">
                        <div className="flex items-center space-x-2 text-xs">
                          <div className="w-1.5 h-1.5 bg-green-500 rounded-full"></div>
                          <span className="text-gray-700">FATF Guidance on Virtual Assets</span>
                        </div>
                        <div className="flex items-center space-x-2 text-xs">
                          <div className="w-1.5 h-1.5 bg-green-500 rounded-full"></div>
                          <span className="text-gray-700">GDPR • AMLA • FINMA • nFADPs</span>
                        </div>
                        <div className="flex items-center space-x-2 text-xs">
                          <div className="w-1.5 h-1.5 bg-green-500 rounded-full"></div>
                          <span className="text-gray-700">Sanctions screening completed</span>
                          </div>
                        <div className="flex items-center space-x-2 text-xs">
                          <div className="w-1.5 h-1.5 bg-green-500 rounded-full"></div>
                          <span className="text-gray-700">PEP check completed</span>
                          </div>
                        <div className="flex items-center space-x-2 text-xs">
                          <div className="w-1.5 h-1.5 bg-green-500 rounded-full"></div>
                          <span className="text-gray-700">Compliance report generated</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* All-in-One Platform Section */}
      <section className="py-8 bg-white">
        <div className="max-w-6xl mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-center"
          >
            <div className="mb-12">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                All-in-One <span className="text-aml-blue">Global Compliance</span> Platform
            </h2>
              <p className="text-lg text-gray-600 max-w-3xl mx-auto">
                Complete KYC, AML, tax compliance, and regulatory reporting in one unified platform. 
                Compatible with <span className="font-semibold text-aml-blue">25+ jurisdictions</span> worldwide.
              </p>
            </div>
            
            {/* Platform Capabilities */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.1 }}
                viewport={{ once: true }}
                className="bg-white rounded-lg border border-gray-200 shadow-sm hover:shadow-md transition-shadow duration-300 p-6"
              >
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                  <svg className="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                  </svg>
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">KYC & AML Screening</h3>
                <p className="text-sm text-gray-600 leading-relaxed">Real-time identity verification and comprehensive risk assessment with advanced analytics</p>
              </motion.div>
              
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
                viewport={{ once: true }}
                className="bg-white rounded-lg border border-gray-200 shadow-sm hover:shadow-md transition-shadow duration-300 p-6"
              >
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
                  <svg className="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                  </svg>
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Tax Compliance</h3>
                <p className="text-sm text-gray-600 leading-relaxed">Automated tax reporting and comprehensive documentation for regulatory compliance</p>
              </motion.div>
              
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.3 }}
                viewport={{ once: true }}
                className="bg-white rounded-lg border border-gray-200 shadow-sm hover:shadow-md transition-shadow duration-300 p-6"
              >
                <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4">
                  <svg className="w-6 h-6 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                  </svg>
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Regulatory Reporting</h3>
                <p className="text-sm text-gray-600 leading-relaxed">Generate compliant reports for authorities with built-in validation and audit trails</p>
              </motion.div>
              
                <motion.div
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.4 }}
                  viewport={{ once: true }}
                className="bg-white rounded-lg border border-gray-200 shadow-sm hover:shadow-md transition-shadow duration-300 p-6"
              >
                <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center mb-4">
                  <svg className="w-6 h-6 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Global Jurisdictions</h3>
                <p className="text-sm text-gray-600 leading-relaxed">25+ jurisdictions supported worldwide with localized compliance frameworks</p>
                </motion.div>
            </div>

            {/* Global Compliance Badges */}
            <div className="flex flex-wrap justify-center gap-6 mb-16">
              {[
                { name: 'GDPR Compliant', icon: '🇪🇺', color: 'green' },
                { name: 'FINMA Standards', icon: '🇨🇭', color: 'red' },
                { name: 'FinCEN Requirements', icon: '🇺🇸', color: 'indigo' },
                { name: 'MAS Framework', icon: '🇸🇬', color: 'purple' },
                { name: 'FATF Guidelines', icon: '🌍', color: 'blue' }
              ].map((badge, index) => (
                <motion.div
                  key={badge.name}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  viewport={{ once: true }}
                  className="group relative"
                >
                  <div className="flex items-center px-6 py-3 rounded-xl bg-white border border-gray-100 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
                    <div className="text-2xl mr-3 group-hover:scale-110 transition-transform duration-300">
                      {badge.icon}
                    </div>
                    <div className="text-center">
                      <div className="text-sm font-semibold text-gray-800 leading-tight">
                        {badge.name}
                      </div>
                      <div className="text-xs text-gray-500 mt-1">
                        Compliant
                      </div>
                    </div>
                  </div>
                  <div className="absolute inset-0 rounded-xl bg-gradient-to-r from-blue-500/5 to-indigo-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                </motion.div>
              ))}
            </div>

          </motion.div>
        </div>
      </section>

      {/* Networks & Partners Section */}
      <section className="py-20 bg-gradient-to-br from-slate-50 via-blue-50/20 to-indigo-50/30">
        <div className="max-w-7xl mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              Supported <span className="text-aml-blue">Networks</span> & <span className="text-aml-blue">Partners</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Comprehensive compliance monitoring across major blockchain networks and trusted by industry leaders
            </p>
          </motion.div>

          {/* All Networks and Partners in One Grid */}
          <div className="flex flex-wrap justify-center gap-6">
            {[
              // Blockchain Networks
              { name: 'Ethereum', logo: 'https://s2.coinmarketcap.com/static/img/coins/64x64/1027.png', type: 'network' },
              { name: 'Tron', logo: 'https://s2.coinmarketcap.com/static/img/coins/64x64/1958.png', type: 'network' },
              { name: 'Arbitrum', logo: 'https://s2.coinmarketcap.com/static/img/coins/64x64/11841.png', type: 'network' },
              { name: 'Polygon', logo: 'https://s2.coinmarketcap.com/static/img/coins/64x64/3890.png', type: 'network' },
              { name: 'BSC', logo: 'https://s2.coinmarketcap.com/static/img/coins/64x64/1839.png', type: 'network' },
              { name: 'Solana', logo: 'https://s2.coinmarketcap.com/static/img/coins/64x64/5426.png', type: 'network' },
              { name: 'Avalanche', logo: 'https://s2.coinmarketcap.com/static/img/coins/64x64/5805.png', type: 'network' },
              // Industry Partners
              { name: 'AAVE', logo: 'https://s2.coinmarketcap.com/static/img/coins/64x64/7278.png', type: 'partner' },
              { name: '1inch', logo: 'https://s2.coinmarketcap.com/static/img/coins/64x64/8104.png', type: 'partner' },
              { name: 'Credits', logo: 'https://s2.coinmarketcap.com/static/img/coins/64x64/2556.png', type: 'partner' },
              { name: 'Slowmist', logo: 'https://pbs.twimg.com/profile_images/1635467425788616705/f0L6oae__400x400.png', type: 'partner' },
              { name: 'AMLBot', logo: 'https://misttrack.io/images/p-logo-amlbot.png', type: 'partner' },
              { name: 'Chainbase', logo: 'https://misttrack.io/images/p-logo-chainbase.png', type: 'partner' },
              { name: 'Chainlink', logo: 'https://s2.coinmarketcap.com/static/img/coins/64x64/1975.png', type: 'partner' },
              { name: 'CELER', logo: 'https://misttrack.io/images/p-logo-celer.png', type: 'partner' },
              { name: 'ackee', logo: 'https://pbs.twimg.com/profile_images/1770505126467248128/4YUTxS95_400x400.jpg', type: 'partner' },
              { name: 'TokenLon', logo: 'https://pbs.twimg.com/profile_images/1847182674949238784/XaJ9hnEu_400x400.jpg', type: 'partner' },
              { name: 'Crypto.com', logo: 'https://mkt-site-asset.crypto.com/assets/sports/crypto-logo.webp', type: 'partner' }
            ].map((item, index) => (
              <motion.div
                key={item.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.05 }}
                viewport={{ once: true }}
                className="network-item"
              >
                <div 
                  className={`network-card${['AMLBot','TokenLon','Chainbase','Slowmist'].includes(item.name) ? ' network-card-large-logo' : ''}`}
                  style={item.name === 'Ackee' ? { background: '#000000' } : {}}
                >
                  <img 
                    src={item.logo} 
                    alt={item.name}
                    className={`network-logo-img${['AMLBot','TokenLon','Chainbase','Slowmist'].includes(item.name) ? ' network-logo-img-large' : ''}`}
                    onError={(e) => {
                      e.target.style.display = 'none';
                      e.target.nextSibling.style.display = 'block';
                    }}
                  />
                  <div className="text-xl font-bold text-gray-400 network-logo-img hidden">
                    {item.name.charAt(0)}
                  </div>
                </div>
                <div className="network-name">{item.name}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              Why <span className="text-aml-blue">Compliance</span> Matters
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              In today's digital economy, regulatory compliance isn't just a legal requirement—it's a business imperative that protects your assets and reputation
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                title: 'Asset Protection',
                description: 'Prevent your funds from being frozen or seized due to compliance violations. Our screening helps identify high-risk transactions before they affect your portfolio.',
                icon: (
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                  </svg>
                ),
                stats: 'Compliance violations can lead to frozen assets'
              },
              {
                title: 'Regulatory Requirements',
                description: 'Financial institutions and crypto businesses face increasing regulatory scrutiny. Stay compliant with FATF, FinCEN, and local regulations to avoid penalties.',
                icon: (
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                  </svg>
                ),
                stats: 'Multiple jurisdictions require AML screening'
              },
              {
                title: 'Reputation Management',
                description: 'One compliance violation can damage your business reputation permanently. Proactive screening demonstrates your commitment to ethical business practices.',
                icon: (
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                  </svg>
                ),
                stats: 'Customers trust compliant businesses more'
              },
              {
                title: 'Risk Mitigation',
                description: 'Identify and avoid high-risk transactions, sanctioned entities, and suspicious patterns before they become legal or financial liabilities.',
                icon: (
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z" />
                  </svg>
                ),
                stats: 'Proactive screening prevents costly violations'
              },
              {
                title: 'Business Continuity',
                description: 'Compliance violations can result in business shutdowns, license revocations, and operational disruptions. Stay operational with proactive compliance.',
                icon: (
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                  </svg>
                ),
                stats: 'Compliance violations can result in business shutdowns'
              },
              {
                title: 'Competitive Advantage',
                description: 'Demonstrate your commitment to security and compliance to gain trust from partners, investors, and customers in the competitive crypto market.',
                icon: (
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                  </svg>
                ),
                stats: 'Compliance builds trust with stakeholders'
              },
              {
                title: 'Tax Reporting & Documentation',
                description: 'Generate comprehensive transaction reports and audit trails for tax purposes. Our detailed screening records provide the documentation needed for tax compliance and regulatory audits.',
                icon: (
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
                  </svg>
                ),
                stats: 'Detailed records required for tax compliance'
              },
              {
                title: 'International Compliance',
                description: 'Meet global regulatory standards including FATF recommendations, EU 5AMLD, and international sanctions lists. Ensure cross-border transaction compliance.',
                icon: (
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                ),
                stats: 'Global standards including FATF recommendations'
              },
              {
                title: 'Transaction Monitoring',
                description: 'Implement real-time transaction monitoring systems as required by regulators. Detect and report unusual patterns and suspicious activities.',
                icon: (
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                  </svg>
                ),
                stats: 'Real-time monitoring required by regulators'
              }
            ].map((reason, index) => (
              <motion.div
                key={reason.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="group bg-gradient-to-br from-gray-50 to-white border border-gray-100 rounded-xl p-6 hover:shadow-lg hover:border-aml-blue/20 transition-all duration-300"
              >
                {/* Icon */}
                <div className="w-12 h-12 bg-aml-blue/10 rounded-xl flex items-center justify-center mb-4 group-hover:bg-aml-blue/20 transition-colors duration-300">
                  <div className="text-aml-blue">
                    {reason.icon}
                  </div>
                </div>
                
                {/* Title */}
                <h3 className="text-lg font-semibold text-gray-900 mb-3 group-hover:text-aml-blue transition-colors duration-300">
                  {reason.title}
                </h3>
                
                {/* Description */}
                <p className="text-sm text-gray-600 leading-relaxed mb-4">
                  {reason.description}
                </p>
                
                {/* Stats */}
                <div className="text-xs font-semibold text-aml-blue bg-aml-blue/5 px-3 py-1 rounded-full inline-block">
                  {reason.stats}
                </div>
              </motion.div>
            ))}
          </div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            viewport={{ once: true }}
            className="text-center mt-12"
          >
            <div className="bg-gradient-to-r from-aml-blue/5 to-blue-50 rounded-2xl p-8 border border-aml-blue/10">
              <h3 className="text-2xl font-bold text-gray-900 mb-4">
                Don't Wait Until It's Too Late
              </h3>
              <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
                Regulatory compliance is not optional in today's financial landscape. Start protecting your assets and reputation today with our comprehensive AML/KYC solution.
              </p>
              <Link to="/connect" className="button text-lg px-8 py-4 inline-block">
                Start Your Compliance Check
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Features Section */}
      <section id="pricing" className="py-20 bg-gradient-to-br from-white via-blue-50/20 to-indigo-50/10">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-20">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
              className="inline-flex items-center px-4 py-2 rounded-full bg-aml-blue/10 text-aml-blue text-sm font-semibold mb-6"
            >
              <span className="w-2 h-2 bg-aml-blue rounded-full mr-2"></span>
              Worldwide Compliance Solution
            </motion.div>
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Complete AML & KYC Compliance Solution
            </h2>
            <p className="text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed mb-8">
              Comprehensive AML and KYC solution designed for financial institutions and crypto businesses. 
              Supporting <span className="font-semibold text-aml-blue">Global jurisdictions</span> with real-time screening capabilities.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                title: 'Real-Time Risk Assessment',
                description: 'Advanced screening technology for instant wallet risk evaluation across multiple blockchain networks.',
                icon: (
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                  </svg>
                ),
                features: ['Multi-network support', 'Instant results', 'Advanced analytics']
              },
              {
                title: 'Regulatory Compliance',
                description: 'Built-in compliance tools designed to meet international regulatory requirements.',
                icon: (
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                ),
                features: ['25+ jurisdictions', 'Auto-updating', 'Custom solutions', 'Regulatory mapping']
              },
              {
                title: 'Transaction Monitoring',
                description: 'Real-time monitoring and analysis of blockchain transactions for suspicious activity detection.',
                icon: (
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                  </svg>
                ),
                features: ['Pattern detection', 'Risk alerts', 'Transaction tracking', 'Suspicious activity reports']
              },
              {
                title: 'Multi-Blockchain Support',
                description: 'Comprehensive coverage for major blockchain networks and emerging protocols.',
                icon: (
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M13 10V3L4 14h7v7l9-11h-7z" />
                  </svg>
                ),
                features: ['Ethereum', 'Tron', 'Other major networks']
              },
              {
                title: 'International Standards',
                description: 'Alignment with FATF recommendations and global regulatory frameworks.',
                icon: (
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                  </svg>
                ),
                features: ['FATF guidelines', 'International standards', 'Best practices']
              },
              {
                title: 'Professional Support',
                description: 'Dedicated support team available for enterprise clients and compliance queries.',
                icon: (
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M18.364 5.636l-3.536 3.536m0 5.656l3.536 3.536M9.172 9.172L5.636 5.636m3.536 9.192L5.636 18.364M12 2.25a9.75 9.75 0 100 19.5 9.75 9.75 0 000-19.5z" />
                  </svg>
                ),
                features: ['Technical support', 'Compliance guidance', 'Documentation']
              }
            ].map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="group bg-white border border-gray-100 rounded-xl p-6 hover:shadow-md hover:border-gray-200 transition-all duration-300"
              >
                {/* Icon */}
                <div className="w-8 h-8 bg-gray-50 rounded-lg flex items-center justify-center mb-4 group-hover:bg-gray-100 transition-colors duration-300">
                  <div className="text-gray-600">
                    {feature.icon}
                  </div>
                </div>
                
                {/* Title */}
                <h3 className="text-lg font-semibold text-gray-900 mb-2 group-hover:text-gray-800 transition-colors duration-300">
                  {feature.title}
                </h3>
                
                {/* Description */}
                <p className="text-sm text-gray-600 leading-relaxed mb-4">
                  {feature.description}
                </p>
                
                {/* Feature List */}
                <div className="space-y-1.5">
                  {feature.features.map((item, idx) => (
                    <div key={idx} className="flex items-center text-xs text-gray-500">
                      <div className="w-1 h-1 bg-gray-400 rounded-full mr-2"></div>
                      {item}
                    </div>
                  ))}
                </div>
              </motion.div>
            ))}
          </div>
          

        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-aml-blue">
        <div className="max-w-4xl mx-auto text-center px-4">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
              Ready to ensure compliance?
            </h2>
            <p className="text-xl text-blue-100 mb-8">
            Start screening your wallet today — and meet your regulatory compliance requirements in minutes.
            </p>
            <Link to="/connect" className="bg-white text-aml-blue px-8 py-4 rounded-lg font-semibold text-lg hover:bg-gray-100 transition-colors inline-block">
              Check Your Wallet Now
            </Link>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;
