import React, { useState } from 'react';
import { motion } from 'framer-motion';

const ScanResults = ({ scanResult, onBack }) => {
  // Certification form state
  const [certificate, setCertificate] = useState({
    companyName: '',
    companyAddress: '',
    fullName: '',
    title: '',
    date: '',
    purpose: '',
  });
  const [disclaimerAgreed, setDisclaimerAgreed] = useState(false);
  const [showDisclaimer, setShowDisclaimer] = useState(false);
  const [certificateComplete, setCertificateComplete] = useState(false);

  const isFormComplete = Object.values(certificate).every(Boolean) && disclaimerAgreed;

  const handleCertInput = (e) => {
    const { name, value } = e.target;
    setCertificate((prev) => ({ ...prev, [name]: value }));
  };

  const handleAgree = (e) => {
    e.preventDefault();
    if (isFormComplete) {
      setCertificateComplete(true);
      setShowDisclaimer(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="w-full max-w-none mx-auto px-1 sm:px-4 lg:px-12"
    >
      <h1 className="text-3xl font-bold text-center mb-8">
        AML Verification & Certification
      </h1>
      <div className="mt-10 flex justify-center animate-fade-in">
        <div className="glassmorphism-premium p-12 rounded-3xl shadow-2xl border border-white/30 backdrop-blur-2xl bg-gradient-to-br from-white/60 via-blue-100/60 to-blue-200/40 w-full max-w-none relative overflow-hidden">
          {/* Animated floating shapes */}
          <div className="absolute -top-16 -right-16 w-56 h-56 bg-gradient-to-br from-blue-400/30 to-purple-300/20 rounded-full blur-3xl z-0 animate-float-slow"></div>
          <div className="absolute -bottom-16 -left-16 w-44 h-44 bg-gradient-to-tr from-green-300/30 to-blue-200/20 rounded-full blur-3xl z-0 animate-float-slower"></div>
          <div className="absolute top-1/2 left-1/2 w-24 h-24 bg-gradient-to-br from-blue-200/40 to-white/10 rounded-full blur-2xl z-0 animate-pulse-slow" style={{transform: 'translate(-50%, -50%)'}}></div>
          <div className="relative z-10">
            {!certificateComplete && (
              <div className="flex items-center mb-8">
                <div className="w-6 h-6 rounded-full bg-gradient-to-br from-green-400 to-blue-400 shadow-lg mr-4 border-2 border-white animate-pulse"></div>
                <span className="text-3xl font-extrabold text-gray-900 drop-shadow-xl tracking-tight">AML Verification</span>
              </div>
            )}
            <div className="mb-2 text-green-700 font-semibold flex items-center gap-2">
              <svg width='16' height='16' fill='none' viewBox='0 0 16 16'><circle cx='8' cy='8' r='8' fill='#22c55e' /><path d='M5 8.5l2 2 4-4' stroke='#fff' strokeWidth='1.5' strokeLinecap='round' strokeLinejoin='round'/></svg>
              Scan completed
            </div>
            {/* User Details Form */}
            {!certificateComplete ? (
              <form className="mb-8 grid grid-cols-1 md:grid-cols-2 gap-6 bg-white/60 rounded-2xl p-6 border border-white/20 shadow-inner" style={{backdropFilter: 'blur(8px)'}}>
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">Company Name</label>
                  <input type="text" name="companyName" value={certificate.companyName} onChange={handleCertInput} className="w-full rounded-lg border border-gray-300 px-3 py-2 bg-white/80 focus:outline-none focus:ring-2 focus:ring-blue-200" placeholder="Enter company name" />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">Company Address</label>
                  <input type="text" name="companyAddress" value={certificate.companyAddress} onChange={handleCertInput} className="w-full rounded-lg border border-gray-300 px-3 py-2 bg-white/80 focus:outline-none focus:ring-2 focus:ring-blue-200" placeholder="Enter company address" />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">Full Name</label>
                  <input type="text" name="fullName" value={certificate.fullName} onChange={handleCertInput} className="w-full rounded-lg border border-gray-300 px-3 py-2 bg-white/80 focus:outline-none focus:ring-2 focus:ring-blue-200" placeholder="Enter full name" />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">Title/Position</label>
                  <input type="text" name="title" value={certificate.title} onChange={handleCertInput} className="w-full rounded-lg border border-gray-300 px-3 py-2 bg-white/80 focus:outline-none focus:ring-2 focus:ring-blue-200" placeholder="Enter title or position" />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">Date</label>
                  <input type="date" name="date" value={certificate.date} onChange={handleCertInput} className="w-full rounded-lg border border-gray-300 px-3 py-2 bg-white/80 focus:outline-none focus:ring-2 focus:ring-blue-200" />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">Purpose</label>
                  <select
                    name="purpose"
                    value={certificate.purpose}
                    onChange={handleCertInput}
                    className="w-full rounded-lg border border-gray-300 px-3 py-2 bg-white/80 focus:outline-none focus:ring-2 focus:ring-blue-200"
                    required
                  >
                    <option value="" disabled>Select purpose...</option>
                    <optgroup label="Service Fee">
                      <option value="Financial Advisory">Financial Advisory</option>
                      <option value="Investment Facilitation">Investment Facilitation</option>
                      <option value="Real Estate Management">Real Estate Management</option>
                      <option value="Securities Management">Securities Management</option>
                      <option value="Capital Network Introductions">Capital Network Introductions</option>
                      <option value="Crypto Advisory">Crypto Advisory</option>
                      <option value="Deal Origination Support">Deal Origination Support</option>
                    </optgroup>
                    <optgroup label="Consulting Fee">
                      <option value="Strategic Business Planning">Strategic Business Planning</option>
                      <option value="International Market Entry Advisory">International Market Entry Advisory</option>
                      <option value="Investor Materials Preparation">Investor Materials Preparation</option>
                    </optgroup>
                  </select>
                </div>
                <div className="md:col-span-2 flex flex-col gap-2 mt-2">
                  <button type="button" className="text-blue-700 underline text-xs text-left" onClick={() => setShowDisclaimer(true)}>
                    View Compliance Disclaimer
                  </button>
                  <label className="flex items-center gap-2 text-xs font-medium text-gray-700">
                    <input type="checkbox" checked={disclaimerAgreed} onChange={e => setDisclaimerAgreed(e.target.checked)} />
                    I agree to the compliance disclaimer
                  </label>
                </div>
                <div className="md:col-span-2 flex justify-end mt-4">
                  <button
                    className={`button bg-green-500 hover:bg-green-600 text-white font-bold py-2 px-6 rounded-lg shadow-lg transition-all duration-200 ${!isFormComplete ? 'opacity-50 cursor-not-allowed' : ''}`}
                    disabled={!isFormComplete}
                    onClick={handleAgree}
                  >
                    <span className="flex items-center gap-2">
                      <svg width="24" height="24" fill="none" viewBox="0 0 24 24"><circle cx="12" cy="12" r="11" stroke="#fff" strokeWidth="2"/><path d="M7 13l3 3 7-7" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
                      Complete Verification
                    </span>
                  </button>
                </div>
              </form>
            ) : (
              <div className="mb-8 text-center animate-fade-in">
                <div className="text-2xl font-bold text-green-700 mb-2 flex items-center justify-center gap-2">
                  <svg width='28' height='28' fill='none' viewBox='0 0 28 28'><circle cx='14' cy='14' r='14' fill='#22c55e' /><path d='M9 15l3 3 7-7' stroke='#fff' strokeWidth='2' strokeLinecap='round' strokeLinejoin='round'/></svg>
                  Verification Complete
                </div>
                <div className="text-gray-700 text-base mb-4">This AML verification is now complete and ready for compliance use.</div>
                <div className="text-xs text-gray-500 italic">Disclaimer: This verification is for compliance demonstration purposes only and does not constitute legal or financial advice. Use of this report is subject to applicable laws and due diligence obligations.</div>
              </div>
            )}
            <div className="text-xs text-gray-500 uppercase tracking-widest text-center mt-6 mb-1">Session</div>
            <div className="text-sm font-mono text-blue-800/90 text-center mb-8 select-all cursor-pointer hover:underline transition" title="Click to copy" onClick={() => {navigator.clipboard && navigator.clipboard.writeText(scanResult?.scanId)}}>
              {scanResult?.scanId}
            </div>
            <div className="flex justify-center w-full mt-2">
              <div className="bg-white/95 rounded-2xl shadow-2xl border border-gray-100 px-2 sm:px-6 py-10 w-full max-w-3xl mx-auto">
                <div className="text-xs text-gray-400 uppercase tracking-widest mb-4 text-center">Scan Results</div>
                <div className="mb-6 text-sm text-gray-700 flex flex-col gap-2">
                  <div className="flex flex-col">
                    <span className="font-semibold text-gray-600">Wallet Address:</span>
                    <span className="font-mono text-gray-800 break-all">{scanResult?.address || '—'}</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="font-semibold text-gray-600">Scan ID:</span>
                    <span className="font-mono text-blue-800/90 select-all cursor-pointer hover:underline transition" title="Click to copy" onClick={() => {navigator.clipboard && navigator.clipboard.writeText(scanResult?.scanId)}}>{scanResult?.scanId}</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="font-semibold text-gray-600">Date of Screening:</span>
                    <span>{scanResult?.timestamp ? new Date(scanResult.timestamp).toLocaleDateString('en-GB', { day: '2-digit', month: 'long', year: 'numeric' }) : ''}</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="font-semibold text-gray-600">Jurisdiction:</span>
                    <span className="flex items-center gap-1"><span className="inline-block w-5 h-5"><svg viewBox="0 0 20 20" fill="none"><rect width="20" height="20" rx="4" fill="#fff"/><rect x="2" y="2" width="16" height="16" rx="2" fill="#e11d48"/><rect x="8.5" y="5" width="3" height="10" rx="1" fill="#fff"/><rect x="5" y="8.5" width="10" height="3" rx="1" fill="#fff"/></svg></span>Switzerland (FINMA-compliant)</span>
                  </div>
                </div>
                <div className="text-lg font-bold text-gray-900 mb-2 mt-6 text-center">Risk Profile Summary</div>
                <div className="overflow-x-auto rounded-xl border border-gray-100 bg-white/90">
                  <table className="min-w-full text-sm text-left">
                    <thead>
                      <tr className="bg-gray-50">
                        <th className="px-4 py-2 font-semibold text-gray-600 text-left">Category</th>
                        <th className="px-4 py-2 font-semibold text-gray-600 text-center">Result</th>
                        <th className="px-4 py-2 font-semibold text-gray-600 text-center">Confidence Score</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr className="border-t">
                        <td className="px-4 py-2">Sanctions Screening</td>
                        <td className="px-4 py-2 text-green-700 font-medium text-center"><span className="inline-block align-middle mr-1"><svg width='18' height='18' fill='none' viewBox='0 0 18 18'><circle cx='9' cy='9' r='9' fill='#4ade80'/><path d='M5 9.5l3 3 5-5' stroke='#fff' strokeWidth='2' strokeLinecap='round' strokeLinejoin='round'/></svg></span>Clear</td>
                        <td className="px-4 py-2 text-gray-700 text-center">99.2%</td>
                      </tr>
                      <tr className="border-t">
                        <td className="px-4 py-2">PEP Exposure</td>
                        <td className="px-4 py-2 text-green-700 font-medium text-center"><span className="inline-block align-middle mr-1"><svg width='18' height='18' fill='none' viewBox='0 0 18 18'><circle cx='9' cy='9' r='9' fill='#4ade80'/><path d='M5 9.5l3 3 5-5' stroke='#fff' strokeWidth='2' strokeLinecap='round' strokeLinejoin='round'/></svg></span>No association</td>
                        <td className="px-4 py-2 text-gray-700 text-center">98.7%</td>
                      </tr>
                      <tr className="border-t">
                        <td className="px-4 py-2">Terrorism Financing</td>
                        <td className="px-4 py-2 text-green-700 font-medium text-center"><span className="inline-block align-middle mr-1"><svg width='18' height='18' fill='none' viewBox='0 0 18 18'><circle cx='9' cy='9' r='9' fill='#4ade80'/><path d='M5 9.5l3 3 5-5' stroke='#fff' strokeWidth='2' strokeLinecap='round' strokeLinejoin='round'/></svg></span>No indicators</td>
                        <td className="px-4 py-2 text-gray-700 text-center">99.8%</td>
                      </tr>
                      <tr className="border-t">
                        <td className="px-4 py-2">Darknet Exposure</td>
                        <td className="px-4 py-2 text-green-700 font-medium text-center"><span className="inline-block align-middle mr-1"><svg width='18' height='18' fill='none' viewBox='0 0 18 18'><circle cx='9' cy='9' r='9' fill='#4ade80'/><path d='M5 9.5l3 3 5-5' stroke='#fff' strokeWidth='2' strokeLinecap='round' strokeLinejoin='round'/></svg></span>Clean</td>
                        <td className="px-4 py-2 text-gray-700 text-center">97.5%</td>
                      </tr>
                      <tr className="border-t">
                        <td className="px-4 py-2">Mixer Usage</td>
                        <td className="px-4 py-2 text-green-700 font-medium text-center"><span className="inline-block align-middle mr-1"><svg width='18' height='18' fill='none' viewBox='0 0 18 18'><circle cx='9' cy='9' r='9' fill='#4ade80'/><path d='M5 9.5l3 3 5-5' stroke='#fff' strokeWidth='2' strokeLinecap='round' strokeLinejoin='round'/></svg></span>None Detected</td>
                        <td className="px-4 py-2 text-gray-700 text-center">96.1%</td>
                      </tr>
                      <tr className="border-t">
                        <td className="px-4 py-2">Freezing Risk</td>
                        <td className="px-4 py-2 text-green-700 font-medium text-center"><span className="inline-block align-middle mr-1"><svg width='18' height='18' fill='none' viewBox='0 0 18 18'><circle cx='9' cy='9' r='9' fill='#4ade80'/><path d='M5 9.5l3 3 5-5' stroke='#fff' strokeWidth='2' strokeLinecap='round' strokeLinejoin='round'/></svg></span>No Freeze Markers</td>
                        <td className="px-4 py-2 text-gray-700 text-center">100%</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
                <div className="mt-8 text-center">
                  <div className="text-base font-bold text-gray-900 mb-1">Legal & Regulatory Screening Base</div>
                  <div className="text-sm text-gray-700 mb-2">This wallet address has been screened using industry-compliant AML frameworks and standards, including:</div>
                  <div className="flex items-center gap-2 text-sm font-semibold text-red-700 justify-center mb-1">
                    <span className="text-lg">🇨🇭</span>
                    <a href="https://www.fedlex.admin.ch/eli/cc/1998/892_892_892/en" target="_blank" rel="noopener noreferrer" className="hover:underline transition">Swiss Anti-Money Laundering Act (AMLA)</a>
                  </div>
                  <div className="text-xs italic text-gray-600 mb-3">Relevant provisions: Article 2 (Scope), Article 3 (Due Diligence), Article 7 (Monitoring Obligations)</div>
                  <div className="flex items-center gap-2 text-sm font-semibold text-red-700 justify-center mb-1">
                    <span className="text-lg">🇨🇭</span>
                    <a href="https://www.finma.ch/en/documentation/finma-guidance/" target="_blank" rel="noopener noreferrer" className="hover:underline transition">Swiss Financial Market Supervisory Authority (FINMA)</a>
                  </div>
                  <div className="text-xs italic text-gray-600 mb-3">Guidance applicable to Virtual Asset Service Providers (VASPs) and financial intermediaries accepting crypto assets.</div>
                  <div className="flex items-center gap-2 text-sm font-semibold text-red-700 justify-center mb-1">
                    <span className="text-lg">🇨🇭</span>
                    <a href="https://www.kmu.admin.ch/kmu/en/home/facts-and-trends/digitization/data-protection/new-federal-act-on-data-protection-nfadp.html" target="_blank" rel="noopener noreferrer" className="hover:underline transition">Swiss Federal Act on Data Protection (nFADP, 2023)</a>
                  </div>
                  <div className="text-xs italic text-gray-600 mb-2">Relevant provisions: Data minimization, lawful processing, privacy by design/default, and processing record maintenance.</div>
                  <div className="flex items-center gap-2 justify-center text-sm font-semibold text-gray-900 mb-1 mt-4">
                    <span className="text-lg">🔐</span>
                    <span>Data Protection Compliance</span>
                  </div>
                  <div className="text-xs italic text-gray-600 mb-2">This AML scan report is processed in full compliance with the Swiss Federal Act on Data Protection (nFADP), effective 1 September 2023. Key measures include:</div>
                  <ul className="list-disc text-xs text-gray-600 mb-2 inline-block text-left mx-auto" style={{display:'inline-block'}}>
                    <li>Privacy by Design and Default</li>
                    <li>Maintenance of a Processing Register</li>
                    <li>Timely breach notification to the Federal Data Protection and Information Commissioner (FDPIC)</li>
                    <li>Enforcement provisions, including fines up to CHF 250,000 for intentional non-compliance</li>
                  </ul>
                  <div className="flex items-center gap-2 justify-center text-sm font-semibold text-gray-900 mb-1 mt-4">
                    <span className="text-lg">🌍</span>
                    <span>International Standards Alignment</span>
                  </div>
                  <div className="text-xs italic text-gray-600 mb-1">FATF Guidance on Virtual Assets and VASPs (2021)<br/>This screening aligns with the Financial Action Task Force (FATF) standards, including wallet risk scoring, sanctions screening, and source-of-funds tracing.</div>
                  <div>
                    <a href="https://www.fatf-gafi.org/en/publications/fatfrecommendations/documents/guidance-rba-virtual-assets-2021.html?utm_source=chatgpt.com" target="_blank" rel="noopener noreferrer" className="text-xs font-semibold text-blue-700 hover:underline transition">Link to FATF Guidance</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="text-center mt-8">
        <button onClick={onBack} className="button-outline">
          Back to Wallet Selection
        </button>
      </div>
    </motion.div>
  );
};

export default ScanResults;