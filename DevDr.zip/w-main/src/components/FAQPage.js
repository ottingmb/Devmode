import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ChevronDown, ChevronUp } from 'lucide-react';

const FAQPage = () => {
  const [openItem, setOpenItem] = useState(null);

  const faqs = [
    {
      question: "What is AML Scanner and how does it work?",
      answer: "AML Scanner is a comprehensive Anti-Money Laundering compliance solution that analyzes cryptocurrency wallet addresses in real-time. Our platform checks transaction history against global sanctions lists, blacklists, and risk databases to provide instant risk assessments and ensure regulatory compliance for businesses and individuals."
    },
    {
      question: "Why is compliance and wallet screening important?",
      answer: "Compliance and wallet screening are essential for protecting your business and assets. Here are the key reasons:\n\n**Legal Protection** - Avoid criminal charges and severe penalties for non-compliance with global AML regulations.\n\n**Asset Security** - Prevent your assets from being frozen due to connections to sanctioned entities.\n\n**Business Continuity** - Maintain operational stability and avoid license revocations.\n\n**Reputation Management** - Protect your business reputation and maintain trust with partners and customers.\n\n**Regulatory Requirements** - Meet mandatory government requirements including international AML/KYC obligations.\n\n**Risk Mitigation** - Identify and avoid high-risk transactions before they become legal liabilities.\n\n**International Compliance** - Ensure cross-border transaction compliance with global regulations.\n\n**Tax Documentation** - Generate proper records for tax compliance and regulatory audits.\n\n**Transaction Monitoring** - Implement required real-time monitoring systems for suspicious activities."
    },
    {
      question: "How much does it cost to scan a wallet?",
      answer: "Each wallet scan costs $0.10 and provides comprehensive results within seconds. This includes detailed risk analysis, transaction history review, compliance reporting, and regulatory guidance. Enterprise customers can access volume discounts and custom pricing plans."
    },
    {
      question: "Which blockchain networks do you support?",
      answer: "We currently support Ethereum (ERC20 tokens including USDT) and Tron (TRC20 tokens including USDT). Our platform is designed to expand to additional major blockchain networks based on market demand and regulatory requirements."
    },
    {
      question: "What compliance standards does your service meet?",
      answer: "Our platform meets comprehensive international compliance standards:\n\n**Global Standards** - FATF (Financial Action Task Force) guidelines, UN Security Council sanctions, and international banking regulations.\n\n**Regional Standards** - EU 5AMLD and 6AMLD directives, US FinCEN requirements, UK Money Laundering Regulations, and APAC regional compliance frameworks.\n\n**Industry Standards** - ISO 27001 information security, SOC 2 Type II compliance, and GDPR data protection.\n\nWe continuously update our compliance framework to match evolving global regulations and maintain regulatory alignment across all jurisdictions."
    },
    {
      question: "How secure is my data during the scanning process?",
      answer: "Security is our highest priority. We use industry-standard encryption, never store private keys, and only analyze publicly available blockchain data. All wallet connections are secured through WalletConnect protocol, and we maintain strict data protection standards in compliance with international privacy regulations."
    },
    {
      question: "What types of risks do you detect?",
      answer: "Our platform detects various risk factors including connections to sanctioned entities, involvement in suspicious transactions, links to known money laundering activities, high-risk geographic locations, and patterns consistent with illicit financial activities. Each risk is categorized and explained in detail."
    },
    {
      question: "Can businesses integrate AML Scanner into their operations?",
      answer: "Yes! We offer comprehensive API integration for businesses of all sizes. Our enterprise solution includes custom integration, dedicated support, bulk processing capabilities, automated compliance reporting, and tailored solutions to meet specific business requirements and regulatory needs."
    },
    {
      question: "How accurate are your risk assessments?",
      answer: "Our risk assessment engine uses advanced algorithms and machine learning models trained on extensive datasets. We maintain high accuracy rates by continuously updating our risk models, incorporating regulatory feedback, and staying current with emerging compliance requirements and threat patterns."
    },
    {
      question: "What happens if a high-risk address is detected?",
      answer: "When a high-risk address is identified, you receive a detailed report including specific risk factors, transaction analysis, recommended actions, and compliance guidance. Our support team is available to help interpret results and provide expert guidance on regulatory compliance and next steps."
    },
    {
      question: "Do you provide compliance documentation for audits?",
      answer: "Yes, we provide comprehensive compliance documentation including detailed audit trails, risk assessment reports, and regulatory compliance certificates. These documents can be used for regulatory audits, due diligence processes, and maintaining compliance records as required by law."
    },
    {
      question: "What customer support do you offer?",
      answer: "We offer 24/7 customer support through multiple channels including email, chat, and phone. Our team includes compliance experts and technical specialists who can assist with integration, regulatory questions, and any technical issues you may encounter."
    },
    {
      question: "How do I get started with AML Scanner?",
      answer: "Getting started is simple! Click 'Check your wallet' to begin scanning immediately. For enterprise solutions or API integration, contact our sales team for a personalized demonstration and to discuss your specific compliance requirements and integration needs."
    }
  ];

  const toggleItem = (index) => {
    setOpenItem(openItem === index ? null : index);
  };

  return (
    <div className="min-h-screen bg-gray-50 py-16">
      <div className="max-w-4xl mx-auto px-4">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Frequently Asked Questions
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Find answers to common questions about our AML compliance solutions and regulatory services
          </p>
        </motion.div>

        {/* FAQ Items */}
        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="bg-white rounded-xl shadow-lg overflow-hidden"
            >
              <button
                onClick={() => toggleItem(index)}
                className="w-full px-6 py-6 text-left flex items-center justify-between hover:bg-gray-50 transition-colors"
              >
                <h3 className="text-lg font-semibold text-gray-900 pr-4">
                  {faq.question}
                </h3>
                {openItem === index ? (
                  <ChevronUp className="w-6 h-6 text-aml-blue flex-shrink-0" />
                ) : (
                  <ChevronDown className="w-6 h-6 text-aml-blue flex-shrink-0" />
                )}
              </button>
              
              {openItem === index && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: 0.3 }}
                  className="px-6 pb-6"
                >
                  <div className="text-gray-600 leading-relaxed space-y-3">
                    {faq.answer.split('\n\n').map((paragraph, idx) => (
                      <p key={idx} className="mb-3">
                        {paragraph}
                      </p>
                    ))}
                  </div>
                </motion.div>
              )}
            </motion.div>
          ))}
        </div>

        {/* Contact Section */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.8 }}
          className="mt-16 text-center bg-aml-blue rounded-2xl p-10 shadow-2xl"
        >
          <div className="max-w-2xl mx-auto">
            <div className="mb-6">
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
                Still have questions?
              </h2>
              <p className="text-blue-100 text-lg leading-relaxed">
                Our compliance experts are here to help. Contact us for personalized support and regulatory guidance.
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <a 
                href="https://t.me/marko_amlscan" 
                target="_blank" 
                rel="noopener noreferrer"
                className="bg-white text-aml-blue hover:bg-gray-100 font-semibold py-3 px-8 rounded-xl shadow-lg transition-all duration-300 transform hover:scale-105 hover:shadow-xl flex items-center gap-2 min-w-[180px] justify-center"
              >
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.894 8.221l-1.97 9.28c-.145.658-.537.818-1.084.508l-3-2.21-1.446 1.394c-.14.18-.357.295-.6.295-.002 0-.003 0-.005 0l.213-3.054 5.56-5.022c.24-.213-.054-.334-.373-.121l-6.869 4.326-2.96-.924c-.64-.203-.658-.64.135-.954l11.566-4.458c.538-.196 1.006.128.832.941z"/>
                </svg>
                Contact Support
              </a>
              <a 
                href="mailto:support@amlscanner.org" 
                className="border-2 border-white text-white hover:bg-white hover:text-aml-blue font-semibold py-3 px-8 rounded-xl transition-all duration-300 transform hover:scale-105 flex items-center gap-2 min-w-[180px] justify-center"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 4.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                </svg>
                Email Us
              </a>
            </div>
            
            <div className="mt-6 text-blue-200 text-sm">
              <p>Available 24/7 for urgent compliance matters</p>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default FAQPage;
