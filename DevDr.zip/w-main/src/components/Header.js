import React from 'react';
import { Link, useLocation } from 'react-router-dom';

const Header = ({ mobileMenuOpen, setMobileMenuOpen }) => {
  // const location = useLocation(); // Unused variable

  const navigation = [
    { name: 'Pricing', href: '/#pricing' },
    { name: 'Analysis', href: '/analytics' },
    { name: 'FAQ', href: '/faq' },
    { name: 'About Us', href: '/about-us' },
  ];

  return (
    <>
      <header className="bg-white border-b border-gray-200">
        <div className="header-container">
          <Link to="/" className="header-logo" aria-label="AML Scanner">
            <img 
              src="https://d36urhup7zbd7q.cloudfront.net/a/795a5669-3a2e-4b02-81fa-547c3598341e__400x106__.png#logo" 
              alt="AML Scanner Logo" 
              className="h-12 w-auto object-contain"
            />
          </Link>
          
          <nav className="desktop-nav hidden md:flex space-x-8">
            {navigation.map((item) => (
              item.external ? (
                <a
                  key={item.name}
                  href={item.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-700 hover:text-aml-blue transition-colors"
                >
                  {item.name}
                </a>
              ) : (
                <Link
                  key={item.name}
                  to={item.href}
                  className="text-gray-700 hover:text-aml-blue transition-colors"
                >
                  {item.name}
                </Link>
              )
            ))}
          </nav>
          
          <div className="header-actions flex items-center space-x-4">
            <Link to="/connect" className="button">
              <span className="hidden sm:inline">Check your wallet</span>
              <span className="sm:hidden">Wallet</span>
            </Link>
            
            <div 
              className="menu-button md:hidden"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              <div className="menu-button-line"></div>
              <div className="menu-button-line"></div>
              <div className="menu-button-line"></div>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Menu */}
      <div className={`mobile-menu ${mobileMenuOpen ? 'show' : ''}`}>
        <div className="mobile-menu_contaier p-6 relative">
          {/* Close button */}
          <button
            onClick={() => setMobileMenuOpen(false)}
            className="absolute top-4 right-4 w-8 h-8 flex items-center justify-center text-2xl text-gray-600 hover:text-gray-900 z-50"
          >
            ×
          </button>
          
          <nav className="space-y-6 mt-8">
            {navigation.map((item) => (
              item.external ? (
                <a
                  key={item.name}
                  href={item.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block text-gray-700 hover:text-aml-blue transition-colors"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  {item.name}
                </a>
              ) : (
                <Link
                  key={item.name}
                  to={item.href}
                  className="block text-gray-700 hover:text-aml-blue transition-colors"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  {item.name}
                </Link>
              )
            ))}
          </nav>
          <Link 
            to="/connect" 
            className="button button-blue mt-8 w-full"
            onClick={() => setMobileMenuOpen(false)}
          >
            Check your wallet
          </Link>
        </div>
      </div>
    </>
  );
};

export default Header;
