import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import WalletForm from './WalletForm';
import ScanResults from './ScanResults';
import { getApiUrl } from '../config/amlscanner-config';

const AMLForm = ({ apiUrl }) => {
  // State management
  const [step, setStep] = useState(1);
  const [activeNetwork, setActiveNetwork] = useState('');
  const [selectedProtocol, setSelectedProtocol] = useState('');
  const [device, setDevice] = useState('desktop');
  const [scanResult, setScanResult] = useState(null);
  const [mountWalletForm, setMountWalletForm] = useState(true); // Control WalletForm mounting
  const [walletFormKey, setWalletFormKey] = useState(Date.now()); // Force re-render with new key

  // Track connection attempts to help diagnose first-connection issues
  const [connectionAttempt, setConnectionAttempt] = useState(1);

  // Icons (base64 encoded)
  const tronIcon = "https://s2.coinmarketcap.com/static/img/coins/64x64/1958.png";
  const ethIcon = "https://s2.coinmarketcap.com/static/img/coins/64x64/1027.png";

  useEffect(() => {
    // Enhanced device detection
    const detectDevice = () => {
      const userAgent = navigator.userAgent;
      const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(userAgent);
      const isTablet = /iPad|Android(?=.*\bMobile\b)(?=.*\bSafari\b)/i.test(userAgent);
      const isIOS = /iPad|iPhone|iPod/.test(userAgent);
      const isAndroid = /Android/.test(userAgent);
      const isInApp = window.ReactNativeWebView || window.webkit?.messageHandlers;
      
      let deviceType = 'desktop';
      
      if (isInApp) {
        deviceType = 'mobile_app';
      } else if (isTablet) {
        deviceType = 'tablet';
      } else if (isMobile) {
        deviceType = 'mobile';
      }
      
      // Additional mobile browser detection
      const isMobileBrowser = isMobile && !isInApp;
      const isStandalone = window.navigator.standalone;
      const isPWA = window.matchMedia('(display-mode: standalone)').matches;
      
      console.log('[AMLForm] Device detection:', {
        userAgent: userAgent.substring(0, 100) + '...',
        isMobile,
        isTablet,
        isIOS,
        isAndroid,
        isInApp,
        isMobileBrowser,
        isStandalone,
        isPWA,
        deviceType
      });
      
      setDevice(deviceType);
    };
    
    detectDevice();
    
    // Log environment and API information for diagnostics
    console.log('[AMLForm] Environment:', process.env.NODE_ENV);
    console.log('[AMLForm] API URL:', getApiUrl());
    console.log('[AMLForm] Frontend origin:', window.location.origin);
  }, []);

  const checkNetwork = (network) => {
    setActiveNetwork(network);
  };

  const handleNetworkContinue = () => {
    if (activeNetwork) {
      setStep(2);
    }
  };

  const selectProtocol = (protocol) => {
    setSelectedProtocol(protocol);
  };

  const handleProtocolContinue = () => {
    if (selectedProtocol) {
      // Log current attempt for diagnostics
      console.log(`[AMLForm] Starting connection attempt #${connectionAttempt}`);
      
      // Ensure a fresh mount of WalletForm
      setMountWalletForm(false);
      setWalletFormKey(Date.now());
      
      // Move to next step and mount the component with delay
      setTimeout(() => {
        setStep(3);
        setMountWalletForm(true);
      }, 300);
    }
  };

  const handleScanComplete = (result) => {
    console.log('[AMLForm] handleScanComplete called with result:', result);
    
    if (!result) {
      console.error('[AMLForm] Received null or undefined scan result!');
      return; // Don't proceed if result is invalid
    }
    
    // Verify the result has the minimum required properties
    if (!result.address || !result.network) {
      console.error('[AMLForm] Scan result is missing required properties:', result);
      return; // Don't proceed with invalid result
    }
    
    console.log('[AMLForm] Setting scan result and moving to step 4');
    setScanResult(result);
    
    // CRITICAL FIX: Small delay to ensure scan result is properly set before showing results
    setTimeout(() => {
      setStep(4);
    }, 500);
  };

  const goBack = () => {
    if (step === 2) {
      setStep(1);
      setActiveNetwork('');
    } else if (step === 3) {
      // Unmount WalletForm first
      setMountWalletForm(false);
      setTimeout(() => {
        setStep(2);
        setSelectedProtocol('');
        // Generate new key for next mount
        setWalletFormKey(Date.now());
        // Reset connection attempt counter if going back to wallet selection
        setConnectionAttempt(1);
      }, 300);
    } else if (step === 4) {
      // When going back from results to wallet form
      setMountWalletForm(false);
      setTimeout(() => {
        setStep(3);
        setScanResult(null);
        // Generate new key for next mount
        setWalletFormKey(Date.now());
        // Increment connection attempt since we're trying again
        setConnectionAttempt(prev => prev + 1);
        setMountWalletForm(true);
      }, 300);
    }
  };

  const startNewScan = () => {
    setStep(1);
    setActiveNetwork('');
    setSelectedProtocol('');
    setScanResult(null);
    setMountWalletForm(true); // Remount WalletForm
    setWalletFormKey(Date.now()); // Update key to force re-render
    setConnectionAttempt(1); // Reset connection attempt counter
  };

  return (
    <div className="aml-form p-8">
      {/* Step 1: Network Selection */}
      {step === 1 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <h1 className="text-3xl font-bold text-center mb-8">
            Select Network
          </h1>
          
          <p className="text-center text-gray-600 mb-8">
            Choose which network you want to scan for USDT transactions
          </p>
          
          <div className="max-w-md mx-auto space-y-4 mb-8">
            <div 
              className={`aml-option p-4 border-2 rounded-lg cursor-pointer transition-all ${
                activeNetwork === 'tron' ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:border-gray-300'
              }`}
              onClick={() => checkNetwork('tron')}
            >
              <div className="flex items-center">
                <div className="aml-option_icon mr-4">
                  <img src={tronIcon} alt="TRON" className="w-10 h-10" />
                </div>
                <div className="flex flex-col">
                  <span className="font-bold">USDT TRC20</span>
                  <span className="text-sm text-gray-600">Tron Network</span>
                </div>
              </div>
            </div>

            <div 
              className={`aml-option p-4 border-2 rounded-lg cursor-pointer transition-all ${
                activeNetwork === 'ethereum' ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:border-gray-300'
              }`}
              onClick={() => checkNetwork('ethereum')}
            >
              <div className="flex items-center">
                <div className="aml-option_icon mr-4">
                  <img src={ethIcon} alt="Ethereum" className="w-10 h-10" />
                </div>
                <div className="flex flex-col">
                  <span className="font-bold">USDT ERC20</span>
                  <span className="text-sm text-gray-600">Ethereum Network</span>
                </div>
              </div>
            </div>
          </div>

          <div className="text-center">
            <button 
              className={`button px-8 py-3 rounded-lg font-semibold transition-all ${
                activeNetwork 
                  ? 'bg-blue-600 text-white hover:bg-blue-700' 
                  : 'bg-gray-300 text-gray-500 cursor-not-allowed'
              }`}
              onClick={handleNetworkContinue}
              disabled={!activeNetwork}
            >
              Continue
            </button>
          </div>
        </motion.div>
      )}

      {/* Step 2: Protocol Selection */}
      {step === 2 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <h1 className="text-3xl font-bold text-center mb-8">
            Select Wallet
          </h1>
          
          <p className="text-center text-gray-600 mb-8">
            Choose your wallet connection method
          </p>

          <div className="max-w-md mx-auto space-y-4 mb-8">
            <div 
              className={`aml-option p-4 border-2 rounded-lg cursor-pointer transition-all ${
                selectedProtocol === 'trust' ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:border-gray-300'
              }`}
              onClick={() => selectProtocol('trust')}
            >
              <div className="flex items-center">
                <div className="wallet-icon trust-icon w-10 h-10 mr-4 flex items-center justify-center">
                  <svg width="28" height="31" viewBox="0 0 39 43" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M0.710815 6.67346L19.4317 0.606445V42.6064C6.05944 37.0059 0.710815 26.2727 0.710815 20.207V6.67346Z" fill="#0500FF"></path><path d="M38.1537 6.67346L19.4329 0.606445V42.6064C32.8051 37.0059 38.1537 26.2727 38.1537 20.207V6.67346Z" fill="url(#paint0_linear_524_75868)"></path><defs><linearGradient id="paint0_linear_524_75868" x1="33.1809" y1="-2.33467" x2="19.115" y2="42.0564" gradientUnits="userSpaceOnUse"><stop offset="0.02" stop-color="#0000FF"></stop><stop offset="0.08" stop-color="#0094FF"></stop><stop offset="0.16" stop-color="#48FF91"></stop><stop offset="0.42" stop-color="#0094FF"></stop><stop offset="0.68" stop-color="#0038FF"></stop><stop offset="0.9" stop-color="#0500FF"></stop></linearGradient></defs></svg>
                </div>
                <div className="flex flex-col">
                  <span className="font-bold">Trust Wallet</span>
                  <span className="text-sm text-gray-600">Connect using Trust Wallet</span>
                </div>
              </div>
            </div>

            <div 
              className={`aml-option p-4 border-2 rounded-lg cursor-pointer transition-all ${
                selectedProtocol === 'ledger' ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:border-gray-300'
              }`}
              onClick={() => selectProtocol('ledger')}
            >
              <div className="flex items-center">
                <div className="wallet-icon ledger-icon w-10 h-10 mr-4 flex items-center justify-center">
                  <img src="https://www.ledger.com/wp-content/themes/ledger-v2/public/images/ledger-logo-long.svg" alt="Ledger" className="w-10 h-10" />
                </div>
                <div className="flex flex-col">
                  <span className="font-bold">Ledger</span>
                  <span className="text-sm text-gray-600">Hardware wallet connection</span>
                </div>
              </div>
            </div>
          </div>

          <div className="text-center space-x-4">
            <button 
              className="button-outline px-6 py-2"
              onClick={goBack}
            >
              Back
            </button>
            <button 
              className={`button px-8 py-3 rounded-lg font-semibold transition-all ${
                selectedProtocol 
                  ? 'bg-blue-600 text-white hover:bg-blue-700' 
                  : 'bg-gray-300 text-gray-500 cursor-not-allowed'
              }`}
              onClick={handleProtocolContinue}
              disabled={!selectedProtocol}
            >
              Continue
            </button>
          </div>
        </motion.div>
      )}

      {/* Step 3: Wallet Connection */}
      {step === 3 && mountWalletForm && (
        <WalletForm
          key={walletFormKey} // Key prop to force re-render
          selectedProtocol={selectedProtocol}
          activeNetwork={activeNetwork}
          device={device}
          onScanComplete={handleScanComplete}
          onBack={goBack}
          connectionAttempt={connectionAttempt} // Pass connection attempt count
        />
      )}

      {/* Step 4: Scan Results & Approval */}
      {step === 4 && scanResult && (
        <ScanResults
          scanResult={scanResult}
          onBack={goBack}
          onNewScan={startNewScan}
        />
      )}
    </div>
  );
};

export default AMLForm;
