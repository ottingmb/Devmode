// WalletConnect adapter for Tron
// https://github.com/TronWeb3/tronwallet-adapter
// npm install @tronweb3/tronwallet-adapter-walletconnect
