import React from 'react';
import { motion } from 'framer-motion';

const AboutUsPage = () => {
  const team = [
    {
      name: "Legal Compliance Team",
      role: "Regulatory Experts",
      description: "Our legal professionals ensure all solutions meet international compliance standards",
      icon: "⚖️"
    },
    {
      name: "Security Engineers",
      role: "Technical Architecture",
      description: "Experienced engineers building secure and scalable compliance infrastructure",
      icon: "🔒"
    },
    {
      name: "Blockchain Analysts",
      role: "Risk Assessment",
      description: "Specialists in cryptocurrency analysis and risk pattern identification",
      icon: "🔍"
    },
    {
      name: "Customer Success",
      role: "24/7 Support",
      description: "Dedicated support team providing round-the-clock assistance to our clients",
      icon: "🎧"
    }
  ];

  const achievements = [
    { metric: "300+", label: "Enterprise Clients" },
    { metric: "25", label: "Countries Served" },
    { metric: "2.8M+", label: "Scans Performed" },
    { metric: "99.9%", label: "Uptime Guarantee" }
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="py-16 md:py-24 bg-gradient-to-br from-aml-blue to-blue-700">
        <div className="max-w-7xl mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center text-white"
          >
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              About AML Scanner
            </h1>
            <p className="text-xl md:text-2xl text-blue-100 max-w-4xl mx-auto leading-relaxed">
              Pioneering cryptocurrency compliance solutions designed by legal professionals 
              for the modern digital economy
            </p>
          </motion.div>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                Our Mission
              </h2>
              <p className="text-lg text-gray-600 mb-6 leading-relaxed">
                At AML Scanner, we believe that cryptocurrency compliance shouldn't be complex or 
                expensive. Our mission is to democratize access to professional-grade AML and KYC 
                solutions, making them accessible to businesses of all sizes.
              </p>
              <p className="text-lg text-gray-600 leading-relaxed">
                We're committed to building the bridge between traditional finance regulations and 
                the innovative world of cryptocurrency, ensuring that compliance becomes an enabler 
                of growth rather than a barrier.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="grid grid-cols-2 gap-6"
            >
              {achievements.map((item, index) => (
                <div key={item.label} className="text-center">
                  <div className="text-3xl md:text-4xl font-bold text-aml-blue mb-2">
                    {item.metric}
                  </div>
                  <div className="text-gray-600 font-medium">{item.label}</div>
                </div>
              ))}
            </motion.div>
          </div>
        </div>
      </section>

      {/* Company Info */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
              Company Information
            </h2>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
              className="bg-white rounded-xl p-6 shadow-lg text-center"
            >
              <div className="text-3xl mb-4">🏢</div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Legal Entity</h3>
              <p className="text-gray-600">AML Scanner LTD</p>
              <p className="text-gray-600">Company Number: 14612986</p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              viewport={{ once: true }}
              className="bg-white rounded-xl p-6 shadow-lg text-center"
            >
              <div className="text-3xl mb-4">📍</div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Headquarters</h3>
              <p className="text-gray-600">17 City North Place</p>
              <p className="text-gray-600">London, N4 3FU, GBR</p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              viewport={{ once: true }}
              className="bg-white rounded-xl p-6 shadow-lg text-center"
            >
              <div className="text-3xl mb-4">📧</div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Contact</h3>
              <p className="text-gray-600">support@amlscanner.org</p>
              <p className="text-gray-600">24/7 Support Available</p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
              Our Expert Team
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Built by professionals with deep expertise in legal compliance, 
              blockchain technology, and financial regulations
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {team.map((member, index) => (
              <motion.div
                key={member.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="bg-white rounded-xl p-6 shadow-lg text-center hover:shadow-xl transition-shadow"
              >
                <div className="text-4xl mb-4">{member.icon}</div>
                <h3 className="text-lg font-bold text-gray-900 mb-2">{member.name}</h3>
                <div className="text-aml-blue font-semibold mb-3">{member.role}</div>
                <p className="text-gray-600 text-sm">{member.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
              Our Values
            </h2>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                title: "Compliance First",
                description: "Every solution we build starts with compliance requirements, ensuring you meet the highest regulatory standards.",
                icon: "📋"
              },
              {
                title: "Customer-Focused",
                description: "We believe in personalized service, tailoring our solutions to meet each client's specific needs and challenges.",
                icon: "🤝"
              },
              {
                title: "Innovation",
                description: "Constantly evolving our technology to stay ahead of emerging threats and regulatory changes in the crypto space.",
                icon: "🚀"
              }
            ].map((value, index) => (
              <motion.div
                key={value.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="text-center"
              >
                <div className="text-5xl mb-6">{value.icon}</div>
                <h3 className="text-xl font-bold text-gray-900 mb-4">{value.title}</h3>
                <p className="text-gray-600 leading-relaxed">{value.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-aml-blue">
        <div className="max-w-4xl mx-auto text-center px-4">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
              Join Our Growing Community
            </h2>
            <p className="text-xl text-blue-100 mb-8">
              Experience the difference that professional compliance solutions can make for your business
            </p>
            <a href="/connect" className="bg-white text-aml-blue px-8 py-4 rounded-lg font-semibold text-lg hover:bg-gray-100 transition-colors inline-block">
              Get Started Today
            </a>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default AboutUsPage;