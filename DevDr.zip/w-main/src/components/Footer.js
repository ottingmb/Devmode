import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  const rewards = [
    { 
      name: 'nFADP', 
      icon: 'https://www.kmu.admin.ch/kmu/en/_jcr_content/logo/image.imagespooler.png/1581426075676/logo.png',
      width: 85, 
      height: 49 
    },
    { 
      name: 'FATF', 
      icon: 'https://www.fatf-gafi.org/content/experience-fragments/fatf-gafi/en/site/header/master/_jcr_content/root/image.coreimg.png/1682926673735/fatf-logo-en.png',
      width: 76, 
      height: 34 
    },
    { 
      name: 'European Commission', 
      icon: 'https://finance.ec.europa.eu/themes/contrib/oe_theme/dist/ec/images/logo/positive/logo-ec--en.svg',
      width: 65, 
      height: 48 
    },
    { 
      name: 'GDPR', 
      icon: 'https://amlscanner.org/_astro/reward-6.G54bjpRE_1v9Yjc.svg',
      width: 61, 
      height: 48 
    },
    { 
      name: 'FINMA', 
      icon: 'https://upload.wikimedia.org/wikipedia/fr/a/a9/FINMA_logo.svg',
      width: 95, 
      height: 48 
    },
  ];

  return (
    <footer className="text-gray-800" style={{ 
      background: `
        linear-gradient(135deg, 
          #c0c0c0 0%, 
          #e8e8e8 25%, 
          #f5f5f5 50%, 
          #e8e8e8 75%, 
          #c0c0c0 100%
        ),
        repeating-linear-gradient(
          45deg,
          transparent,
          transparent 10px,
          rgba(0, 0, 0, 0.1) 10px,
          rgba(0, 0, 0, 0.1) 20px
        ),
        repeating-linear-gradient(
          -45deg,
          transparent,
          transparent 10px,
          rgba(0, 0, 0, 0.05) 10px,
          rgba(0, 0, 0, 0.05) 20px
        )
      `,
      backgroundBlendMode: 'overlay',
      backdropFilter: 'blur(100px)',
      WebkitBackdropFilter: 'blur(100px)',
      position: 'relative',
      isolation: 'isolate'
    }}>
      {/* Blur overlay for enhanced effect */}
      <div style={{
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        background: 'rgba(255, 255, 255, 0.1)',
        backdropFilter: 'blur(20px)',
        WebkitBackdropFilter: 'blur(20px)',
        zIndex: -1
      }} />
      
      <div className="max-w-7xl mx-auto px-4 pt-4 pb-4 relative z-10">
        {/* Main Footer Content */}
        <div className="grid lg:grid-cols-4 gap-8 mb-12">
          {/* Company Info */}
          <div className="lg:col-span-2 mb-2">
            <Link to="/" className="block mb-4" style={{margin: 0, padding: 0}}>
              <img 
                src="https://ott-investments.com/wp-content/uploads/2024/08/Ott-Investments-Logo-Original-5000x5000-1-1-e1720481687438-2048x576-1.png" 
                alt="AML Scanner Logo" 
                className="w-40 h-20 object-contain m-0 p-0"
                style={{minWidth: '160px'}}
                onError={(e) => {
                  e.target.style.display = 'none';
                  e.target.nextSibling.style.display = 'flex';
                }}
              />
            </Link>
            
            {/* Premium tagline below logo */}
            <div className="mb-6">
              <p className="text-gray-600 font-light text-sm tracking-wide" style={{
                fontFamily: 'Inter, sans-serif',
                letterSpacing: '0.02em',
                lineHeight: '1.4',
                fontStyle: 'italic'
              }}>
                Advanced blockchain Analytics and Compliance solutions
              </p>
              <p className="text-gray-500 font-light text-xs tracking-wide mt-2" style={{
                fontFamily: 'Inter, sans-serif',
                letterSpacing: '0.01em',
                lineHeight: '1.3'
              }}>
                OTT Investments GmbH, CHE-150.098.993<br />
                Pk. Höchi Allee 6, 6353 Weggis, Switzerland<br />
                support@ott-investments.com
              </p>
            </div>
            
          </div>

          {/* Navigation Links */}
          <div className="lg:col-span-2" style={{marginTop: '2rem'}}>
            <h3 className="text-base font-medium mb-4 text-gray-700 tracking-wide" style={{fontFamily: 'Inter, sans-serif', letterSpacing: '0.04em'}}>Quick Links</h3>
            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-2">
                <Link to="/#pricing" className="block text-gray-500 hover:text-aml-blue transition-colors underline-offset-4 hover:underline text-base font-light">
                  Pricing
                </Link>
                <Link to="/analytics" className="block text-gray-500 hover:text-aml-blue transition-colors underline-offset-4 hover:underline text-base font-light">
                  Analysis
                </Link>
                <Link to="/faq" className="block text-gray-500 hover:text-aml-blue transition-colors underline-offset-4 hover:underline text-base font-light">
                  FAQ
                </Link>
              </div>
              <div className="space-y-2">
                <Link to="/about-us" className="block text-gray-500 hover:text-aml-blue transition-colors underline-offset-4 hover:underline text-base font-light">
                  About Us
                </Link>
                <a 
                  href="https://aml.ott-investme.gitbook.io/aml-scanner-docs" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="block text-gray-500 hover:text-aml-blue transition-colors underline-offset-4 hover:underline text-base font-light"
                >
                  Docs
                </a>
                <Link to="/connect" className="block text-aml-blue hover:text-blue-700 transition-colors font-semibold underline-offset-4 hover:underline text-base">
                  Check Wallet
                </Link>
              </div>
            </div>
          </div>
        </div>

        <hr className="border-gray-400 mb-2" />

        {/* Legal Links and Rewards */}
        <div className="grid lg:grid-cols-2 gap-8 items-center mb-2">
          <div className="flex flex-wrap gap-4 font-light text-sm text-gray-500">
            <a 
              href="https://t.me/ID" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-gray-600 hover:text-gray-900 transition-colors"
            >
              Support
            </a>
            <Link to="/user-agreement" className="text-gray-600 hover:text-gray-900 transition-colors">
              User Agreement
            </Link>
            <Link to="/privacy-policy" className="text-gray-600 hover:text-gray-900 transition-colors">
              Privacy Policy
            </Link>
          </div>

          {/* Certification Badges */}
          <div className="flex flex-wrap items-center gap-4 justify-start lg:justify-end px-4 py-2 rounded-xl shadow-lg border border-gray-200 bg-white/30 backdrop-blur-md" style={{boxShadow: '0 4px 24px 0 rgba(160,160,160,0.10), 0 1.5px 8px 0 rgba(180,180,180,0.10) inset', border: '1.5px solid #e0e0e0', background: 'linear-gradient(90deg,rgba(255,255,255,0.25) 0%,rgba(240,240,240,0.15) 100%)'}}>
            {rewards.map((reward, index) => (
              <div 
                key={index}
                className="flex items-center justify-center"
                style={{ 
                  minWidth: `${reward.width}px`, 
                  height: `${Math.round(reward.height * 0.9)}px`,
                  maxWidth: `${reward.width}px`
                }}
              >
                <img 
                  src={reward.icon} 
                  alt={reward.name}
                  className="max-w-full max-h-full object-contain"
                  onError={(e) => {
                    e.target.style.display = 'none';
                    e.target.nextSibling.style.display = 'flex';
                  }}
                />
                <div className="text-xs font-medium text-gray-800 hidden items-center justify-center">
                  {reward.name}
                </div>
              </div>
            ))}
          </div>
        </div>

        <hr className="border-gray-400 mb-8" />

        {/* Copyright */}
        <div className="text-center">
          <span className="text-gray-400 text-sm">
            © {currentYear} Ott Investment. All rights reserved.
          </span>
        </div>
      </div>
    </footer>
  );
};

export default Footer;