import React from 'react';
import AMLForm from './AMLForm';
import { AML_CONFIG } from '../config/amlscanner-config';

const ConnectPage = () => {
  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4">
        <div className="bg-white rounded-xl shadow-lg">
          {/* Using local mock implementation instead of original API */}
          <AMLForm apiUrl={AML_CONFIG.API_URL} />
        </div>
      </div>
    </div>
  );
};

export default ConnectPage;